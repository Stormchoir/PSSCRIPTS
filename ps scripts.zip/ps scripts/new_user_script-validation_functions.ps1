$GetOffice = 
{
Switch (Read-Host 'Which office will the user be at?')
	{
		'Austin'
		'Birmingham'
		'Chantilly'
		'Cleveland'
		'Columbus'
		'Dallas'
		'Fayetteville'
		'Greenwich'
		'Houston'
		'Indianapolis'
		'Las Vegas'
		'Louisville'
		'Madison'
		'Miramar'
		'Mobile'
		'Naperville'
		'Okemos'
		'Richmond'
		'Springfield'
		'Tampa'
		'Washington DC'
		
		default{
				Write-Host "Invalid input.  Please enter a valid office location." -foregroundcolor - Blue
				.$Getoffice
				}
	}
}

$GetDepartment
{
Switch (Read-Host 'What department will the user be in?'
	{
		'Accounting'
		'Actuary'
		'Administration'
		'Agency'
		'Audit'
		'Claims'
		'Claims Operations'
		'Communications'
		'Company Services'
		'Human Resources'
		'Information Systems'
		'Investments'
		'Legal'
		'OBGYN Risk Alliance'
		'Reception'
		'Red Mountain'
		'Risk Resource'
		'Sales and Marketing'
		'Service Center - Underwriting'
		'Service Center - Claims'
		'Tech Support'
		'Underwriting'
		'Underwriting Operations'
		default {
				Write-Host "Invalid Input.  Please enter a valid department for the new user or ctrl+c to exit."  -foregroundcolor Blue
				.$GetDepartment
				}
	)
)
