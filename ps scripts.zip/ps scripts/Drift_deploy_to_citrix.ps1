#Drift update
#version - 1.0
#Author: Greg Bromley
 
ForEach ($server in get-content "citrix_servers.txt")
{
#clear contents of drift folder
remove-item "\\$server\c$\program files\proassurance corporation\drift" -recurse

#create Drift folder
new-item -path "\\$server\c$\program files\proassurance corporation\drift" -type directory -Force

#copy new files
copy-item "\\corporate.local\applications\appdev\drift\Production\*" -destination "\\$server\c$\program files\proassurance corporation\drift" -recurse
}