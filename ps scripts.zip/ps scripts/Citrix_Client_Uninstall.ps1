#*FileName: Citrix_Client_Uninstall_and_Install.ps1 
#*=========================================
#*Created 10/05/2013
#*Author: Shaun Ritchie
#*www.shaunritchie.co.uk
#*=========================================
#*
#*
#*=========================================
#* SCRIPT BODY#*========================================= 

##Kill Citrix Client Processses that prevent uninstall 

Stop-Process -ProcessName wfcrun32 -force
Stop-Process -ProcessName ssonsvr -force 

##Uninstall old clients that use GUIDs, 11.000 and below 

$Guids="DAA13EB6-C53F-4038-9880-C310500B49E9","3049E69E-74F2-48C0-B9A1-9CD8125588E9","956F3E9A-3AED-40F8-8522-5F6A524CFC3E",`       "8F5F8B07-50AC-401F-A441-A37740851A5C","2C42ED1E-6315-4E63-89E6-057EA114EBB8","76E4A642-BC3E-438A-8450-0C15A36B5B18l",`
"4E21223F-8D6C-446E-9CD3-587D206A8400","E92B7A19-5FD5-4AEE-9FEF-7AD5DD3A675E","DF1D5FEC-D67C-43C8-9230-41F5DF350196",`       
"D989BCC0-757C-4FB6-893C-512DF4382656","7A1FB67F-A340-472A-97C3-A6AFFE078AAE","B2AE44CB-2AAB-4C08-A54B-D264BD604DA8",`       
"E89956F9-5B89-470E-818D-BD46102D0A01","42ACCB45-3363-47E0-94E9-F0074CC8BC56","2624B680-02BC-4CBC-839C-DA20DF6EF6EC",`       
"331741EC-DD63-4DA8-957E-D0C70412EF54","388C130B-0079-46B4-A0D5-DC2DD7A89A7B" "13E306E6-D691-4D41-8485-C43945C2CEEC"'`


ForEach ($Guid in $Guids)     
	{       $ArgumentList = "/x" + "{" + $Guid + "}" + " /qn REBOOT=ReallySuppress /quiet"
        	Start-Process -FilePath msiexec.exe -ArgumentList $ArgumentList   -wait
    	} 

##Get the correct location of install directory 

$OSVersionNo = [System.Environment]::OSVersion.Version 

##Windows XP and Windows Server 2003
If (($OSVersionNo.Build -eq 2600) -or ($OSVersionNo.Build -eq 3790))     
	{        
		$InstallLocation=$env:AllUsersProfile + "\Application Data"     
	} 
Else     
	{        
		$InstallLocaton=$env:ProgramData    
	} 

##Uninstall clients 11.2 and above 

$InstallDirs = "`"$InstallLocation\Citrix\Citrix online plug-in\TrolleyExpress.exe`"", "`"$InstallLocation\Citrix\Citrix online plug-in - web\TrolleyExpress.exe`"" 

foreach ($InstallDir in $InstallDirs)         
	{        
		Start-Process -FilePath $InstallDir -ArgumentList "/uninstall /cleanup /silent"  -wait
        }     

##Uninstall all versions of Receiver 

$InstallDir = $InstallLocation + "\Citrix\Citrix Receiver (Enterprise)\TrolleyExpress.exe" 

Start-Process -FilePath $InstallDir -ArgumentList "/uninstall /cleanup /silent"  -wait 

##Install Receiver 

$InstallFiles = ""
$ArgumentList = '/noreboot /silent /includeSSON ADDLOCAL="ReceiverInside,ICA_Client,PN_Agent,SSON,USB,DesktopViewer,Flash,Vd3d" Enable_SSON="Yes" Enable_KERBEROS="No" LEGACYFTAICONS="True" Enable_DYNAMIC_CLIENT_NAME="Yes" ENABLEPRELAUNCH="True" SERVER_LOCATION=""'

 Start-Process -FilePath $InstallFiles -ArgumentList $ArgumentList -wait 

##Make sure Single Sign is in Provider Order Key 

$Path = "HKLM:\system\CurrentControlSet\Control\NetworkProvider\Order" 

$ProviderOrder = (Get-ItemProperty -path $path).ProviderOrder
If ($ProviderOrder -NotLike "*PnSson*")
         {        
		Set-ItemProperty -path $path -Name ProviderOrder -value ($ProviderOrder + ",PnSson")
	        $NewProviderOrder = (Get-ItemProperty -path $path).ProviderOrder
	        Write-Host Provider Order key now has the following values   $NewProviderOrder
	    }
Else          
	{
	        Write-Host "PnSson already present in Provider Order"    
	}