$header = "server"
 
$servers = import-csv c:\temp\serverlist.csv -header $header
 
foreach($i in $servers) {
     Write-Host "Attempting to reboot:" $i.server "..."
 
     $serverObj = gwmi Win32_operatingsystem -computer $i.server
	 $serverObj = gwmi Win64_operatingsystem -computer $i.server
 
     $status = $serverObj.reboot()
 
     if ($status.ReturnValue = "0") {
          Write-Host "Reboot successful."
     } else {
          Write-Host "Reboot failed. Check permissions."
     }
}