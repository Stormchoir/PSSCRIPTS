            
$gsource = "Track-It! Technicians"            
$gtarget = "Cherwell Users"            
Get-ADGroupMember -Identity $gsource |            
foreach {            
 Add-ADGroupMember -Identity $gtarget -Members $($_.DistinguishedName)            
}            
            
