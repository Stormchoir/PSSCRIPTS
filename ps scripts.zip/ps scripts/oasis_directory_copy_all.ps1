$when = Get-Date
$hostname = c:\windows\system32\hostname.exe
write-output Script is running on $hostname

# powershell &'\\pro-file\Application Development\OASIS\OasisRelease\run_oasis_directory_copy.ps1' DEV > c:\temp\run_oasis_directory_copy.log 2>&1
# powershell &'\\pro-file\Application Development\OASIS\OasisRelease\Test_run_oasis_directory_copy.ps1'  "MODEL"  "*TXT" > c:\batch\Test_run_oasis_directory_copy.txt 2>&1

## $smtpServer = "PRO-EMAIL.corporate.local" 
$smtpServer = "CAS.corporate.local" 
$smtp = new-object Net.Mail.SmtpClient($smtpServer)


##$email1 = "mheim"
##$email2 = "mheim"
##$email3 = "mheim"


$anyinput = $args.length
write-output "Number of input parms is $anyinput"

if ($anyinput -eq 0) {Write-Output "Failed, No input parms" | Out-File c:\batch\pbd_copy.log;break}
elseif ($anyinput -eq 1) 
       {$hname = $args[0]}
else 
   {$hname = $args[0]
    $extention = $args[1]}

write-output "hosts are $hname"
write-output "extention is $extention"

$dbname = $hname      #  save the input value
#
# Set Host Server array and source, target directories
#
 If ($hname -eq "MODEL")
	{
 	$hname_list = @("PRO-XEN64-M01","PRO-XEN64-M02")
 ###### ######      $hname_list = @("PRO-XEN-MODEL1")
    	$source = "\\pro-file\oasis distribution\Current_Model\pbexe\*"
	$subdir = "\\Oasis Distribution\model\*"
###### 	$subdir = "\c$\Oasis32\*"
	
#######	$email1 = "dbagroup"
#######	$email2 = "OasisBuildTeam"
#######	$email3 = "cmuellersmith"

#######	$email1 = "mheim"
#######	$email2 = "mheim"
#######	$email3 = "mheim"

$email1 = "rballard"
$email2 = "mheim"
$email3 = "rballard"
	}
#end if

ElseIf ($hname -eq "PRO")
	{
####  $hname_list=@("PRO-XEN64-A13","PRO-XEN64-A06")
$hname_list=@("PRO-XEN64-A03","PRO-XEN64-A04","PRO-XEN64-A05","PRO-XEN64-A06","PRO-XEN64-A07","PRO-XEN64-A08","PRO-XEN64-A09","PRO-XEN64-A10","PRO-XEN64-A11","PRO-XEN64-A12","PRO-XEN64-A13","PRO-XEN64-A14","PRO-XEN64-A15","PRO-XEN64-A16","PRO-XEN64-A17","PRO-XEN64-A18","PRO-XEN64-A19","PRO-XEN64-A20","PRO-XEN64-A21","PRO-XEN64-A22","PRO-XEN64-A23","DR-XEN64-A01","DR-XEN64-A02")

        $source = "\\pro-file\oasis distribution\Current_Production\pbexe\*"
	$subdir = "\\\Oasis Distribution\Oasis\*"
	$email1 = "dbagroup"
	$email2 = "OasisBuildTeam"
	$email3 = "Admin"

	}
ElseIf ($hname -eq "PRO2")
	{
        $hname_list=@("PRO-XEN64-A01","PRO-XEN64-A02")
 ##        $hname_list=@("PRO-XEN64-A12")
 
        $source = "\\pro-file\oasis distribution\Current_Production\pbexe\*"
	$subdir = "\\\Oasis Distribution\Oasis\*"

	$email1 = "dbagroup"
	$email2 = "OasisBuildTeam"
	$email3 = "Admin"

	}
ElseIf ($hname -eq "DEV")
	{
	$hname_list=@("PRO-XEN-M01","PRO-XEN-M02")
	$source = "\\pro-file\oasis distribution\Current_Model\pbexe\*"
	$subdir = "\\Oasis Distribution\Oasis_Dev\*"
	
	$email1 = "dbagroup"
	$email2 = "dbagroup"
	$email3 = "dbagroup"
	}
ElseIf ($hname -eq "POC")
	{
	$hname_list=@("pro-tri2k8")
    	$source = "\\pro-file\oasis distribution\Current_Model\pbexe\*"
	$subdir = "\\Oasis Distribution\model\*"
	
	$email1 = "dbagroup"
	$email2 = "ajesser"
	$email3 = "kmalin"
	}
ElseIf ($hname -eq "IS_API")
	{
	$hname_list=@("PRO-XEN-M01")
        $source = "\\pro-file\oasis distribution\Current_Production\pbexe\*"
	$subdir = "\\Oasis Distribution\IT_API\API Conversion\*"
	
	$email1 = "dbagroup"
	$email2 = "dbagroup"
	$email3 = "dbagroup"
	}
ElseIf ($hname -eq "DR")
	{
	$hname_list=@("DR-XEN64-A01","DR-XEN64-A02")

        $source = "\\pro-file\oasis distribution\Current_Production\pbexe\*"
	$subdir = "\\\Oasis Distribution\Oasis\*"
	$email1 = "dbagroup"
	$email2 = "dbagroup"
	$email3 = "dbagroup"
	}
Else
 {Write-output "what kind of input is this?  $hname $extention"
 exit}
#end if


#Kill Oasis Processes
#$oasisProcess=get-process | where {($_.Name -eq "oasis")}
#If ($oasisProcess) 
#{
#	"List of Oasis processes to kill "
#	$oasisProcess 
#	$oasisProcess | foreach { $_.Kill() }
#} 
#  Else 
#{	
#	"No Oasis Processes found" 
#} 

$cnt = 0
$max = $hname_list.count
$sourceB = $source

#  Loop through hname_list Array
do
{
 $hname = $hname_list[$cnt]      #  get the first array var
 $stamp = Get-Date �f "yyyy-MM-dd_HH_mm_ss"

 $LogFile = "c:\batch\log\"+$dbname+"_"+$hname+"_oasis_directory_copy_"+$stamp+".txt"
 if ($extention)
  {
	 $LogFile = "c:\batch\log\"+$dbname+"_"+$hname+"_oasis_file_copy_"+$stamp+".txt"
  }

 write-output "Script is running on $hostname"| Out-File $LogFile
 Write-Output "$hname  at  $when" | Out-File $LogFile -append
 Write-Output " " | Out-File $LogFile -append

 $msg = new-object Net.Mail.MailMessage

#   List of E-Mail contacts
 $msg.To.Add("$email1@proassurance.com")
 $msg.To.Add("$email2@proassurance.com")
 $msg.To.Add("$email3@proassurance.com")

#
 $msg.From = "$hname@proassurance.com" 
 
##if ($dbname -eq "API....")
##{
##     $subdir = "\Oasis Distribution\api conversion\*"
##}


 $target = "\\$hname$subdir"     #  assign host server name as prefix to target subdirectory
 $targetB = $target		 #  targetB is used if extention (input parameter) is used
 $inifile = $target.Replace("\*", "\oasis.ini")   # remove the the chars at end of subdir with ini filename

 Write-Output "Copy files from $source  to  $target  " | Out-File $LogFile -append

#  if an file extention was passed via parameter then append to targetB and sourceB


if ($extention)
{
	Write-Output "Only copy files with extention of  $extention " | Out-File $LogFile -append
	$targetB = $target+$extention
	Write-Output "-----------------------------------------------------------------------------------------------------------------------------" | Out-File $LogFile -append
	Write-Output "List of Files to be deleted in " | Out-File $LogFile -append
	Get-ChildItem $targetB | Out-File $LogFile -append
	Write-Output "-----------------------------------------------------------------------------------------------------------------------------" | Out-File $LogFile -append
	$sourceB = $source+$extention
	Write-Output "List of Files to be copied from " | Out-File $LogFile -append
	Get-ChildItem $sourceB | Out-File $LogFile -append
} 
#  end if

  


Write-Output "-----------------------------------------------------------------------------------------------------------------------------" | Out-File $LogFile -append

Write-Output " " | Out-File $LogFile -append

Remove-Item $targetB -recurse -Force -ErrorVariable "RemoveErr"
If ($RemoveErr) 
{
 	 Write-Output "Failed to remove files from $target" | Out-File $LogFile -append
	 $RemoveErr >> $LogFile 
	 Write-Output "-----------------------------------------------------------------------------------------------------------------------------" | Out-File $LogFile -append
	 Write-Output " " | Out-File $LogFile -append
 	 Write-Output "-----------------------------------------------------------------------------------------------------------------------------" | Out-File $LogFile -append
	 Write-Output " " | Out-File $LogFile -append
 	 Write-Output "-----------------------------------------------------------------------------------------------------------------------------" | Out-File $LogFile -append

	 $msg.subject = "$hname : Copy Failed $source to $target"
	 $msg.body = "Rerun copy"  
	 $attach=new-object System.Net.Mail.Attachment($LogFile)
	 $msg.Attachments.Add($attach)

	 $smtp.Send($msg)
	 $attach.Dispose()
} 
 else 
{
 "Successfully Removed  $targetB" >> $LogFile
}
#end if

Write-Output "-----------------------------------------------------------------------------------------------------------------------------" | Out-File $LogFile -append
Write-Output " " | Out-File $LogFile -append

$target = $target.Replace("\*", "")   # remove the the chars at end so copy-item cmd will work
Copy-Item $sourceB $target �recurse -ErrorVariable "CopyErr"

# if ($cnt -eq 0){


####   check if real DR Site to copy local INI, this ini has the oasisdr database name
#
$is_it_oasis = $source.Contains("Current_Production")       
$hname_pref = $hname.StartsWith("DR") 					
if (($is_it_oasis) -and ($hname_pref))						
{ 								               
  Copy-Item \\$hname\ini\Oasis.ini $target �recurse -ErrorVariable "CopyErr2"
  Write-Output "copying \\$hname\ini\Oasis.ini to $target" | Out-File $LogFile -append
}

##$is_it_api = $hname.Contains("M01")
##if ($is_it_api) 
##{								               
##  Copy-Item '\\pro-xen-m01\Oasis Distribution\api_ini\Oasis.ini' '\\pro-xen-m01\Oasis Distribution\API Conversion' �recurse  -ErrorVariable "CopyErr2"
##  Write-Output "copying \\PRO-XEN-M01\Oasis Distribution\api_ini\Oasis.ini to $target" | Out-File $LogFile -append
##}

If ($dbname -eq "DEV")
{								               
  Copy-Item '\\pro-xen-m01\Oasis Distribution\dev_ini\Oasis.ini' '\\pro-xen-m01\Oasis Distribution\Oasis_Dev' �recurse  -ErrorVariable "CopyErr2"
  Write-Output "copying \\PRO-XEN-M01\Oasis Distribution\dev_ini\Oasis.ini to '\\pro-xen-m01\Oasis Distribution\Oasis_Dev'" | Out-File $LogFile -append

  Copy-Item '\\pro-xen-m01\Oasis Distribution\dev_ini\Oasis.ini' '\\pro-xen-m02\Oasis Distribution\Oasis_Dev' �recurse  -ErrorVariable "CopyErr2"
  Write-Output "copying \\PRO-XEN-M01\Oasis Distribution\dev_ini\Oasis.ini to '\\pro-xen-m02\Oasis Distribution\Oasis_Dev'" | Out-File $LogFile -append
}

If ($dbname -eq "QA")
{								               
  Copy-Item '\\pro-xen-m01\Oasis Distribution\qa_ini\Oasis.ini' '\\pro-xen-m01\Oasis Distribution\oasis_qa' �recurse  -ErrorVariable "CopyErr2"
  Write-Output "copying \\PRO-XEN-M01\Oasis Distribution\qa_ini\Oasis.ini to '\\pro-xen-m01\Oasis Distribution\Oasis_qa'" | Out-File $LogFile -append

  Copy-Item '\\pro-xen-m01\Oasis Distribution\qa_ini\Oasis.ini' '\\pro-xen-m02\Oasis Distribution\Oasis_qa' �recurse  -ErrorVariable "CopyErr2"
  Write-Output "copying \\PRO-XEN-M01\Oasis Distribution\qa_ini\Oasis.ini to '\\pro-xen-m02\Oasis Distribution\Oasis_qa'" | Out-File $LogFile -append

  Copy-Item '\\pro-xen-m01\Oasis Distribution\qa_ini\Oasis.ini' '\\pro-xen-m03\Oasis Distribution\Oasis_qa' �recurse  -ErrorVariable "CopyErr2"
  Write-Output "copying \\PRO-XEN-M01\Oasis Distribution\qa_ini\Oasis.ini to '\\pro-xen-m03\Oasis Distribution\Oasis_qa'" | Out-File $LogFile -append

}

If ($dbname -eq "IS_API")
{								               
  Copy-Item '\\pro-xen-m01\Oasis Distribution\it_api_ini\Oasis.ini' '\\pro-xen-m01\Oasis Distribution\IT_API\API Conversion' �recurse  -ErrorVariable "CopyErr2"
  Write-Output "copying \\PRO-XEN-M01\Oasis Distribution\it_api_ini\Oasis.ini to '\\pro-xen-m01\Oasis Distribution\IT_API\API_Conversion'" | Out-File $LogFile -append

  Copy-Item '\\pro-xen-m01\Oasis Distribution\it_api_ini\oasis.exe.config' '\\pro-xen-m01\Oasis Distribution\IT_API\API Conversion' �recurse  -ErrorVariable "CopyErr2"
  Write-Output "copying \\PRO-XEN-M01\Oasis Distribution\it_api_ini\oasis.exe.config to '\\pro-xen-m01\Oasis Distribution\IT_API\API_Conversion'" | Out-File $LogFile -append

}


If ($CopyErr2)
{ 
Write-Output "Failed to Copy local (ini or config) files to $target" | Out-File $LogFile -append
}
#
###   end of check


$release_check="Skipped Version Check"
####   skipping version check   $is_it_a = $hname.Contains("PRO-XEN64-A")
$is_it_a = $hname.Contains("SKIPPING")

If (($is_it_oasis) -and ($is_it_a))
{
$release_check = @(&'\\pro-file\Application Development\OASIS\OasisRelease\oasis_release_info.ps1' $inifile)
$bad_versions = ($release_check -contains "ERROR: Versions DO NOT MATCH")
if ($bad_versions)
{ $msg.subject = "$hname Error: Oasis DB Release and INI do not match"
  $result = $release_check | format-table -autosize | out-string
  $msg.body = "$result"  
  $smtp.Send($msg)
}
}

If ($CopyErr) 
	{Write-Output "Failed Copy $source to $target" | Out-File $LogFile -append
	 $CopyErr >> $LogFile
	 Write-Output "-----------------------------------------------------------------------------------------------------------------------------" | Out-File $LogFile -append
	 Write-Output " " | Out-File $LogFile -append
 	 Write-Output "-----------------------------------------------------------------------------------------------------------------------------" | Out-File $LogFile -append
	 Write-Output " " | Out-File $LogFile -append
	 Write-Output "---------------- Verify release from database and INI -------------------" | Out-File $LogFile -append
	 $release_check | Out-File $LogFile -append 
 	 Write-Output "-----------------------------------------------------------------------------------------------------------------------------" | Out-File $LogFile -append

	 $msg.subject = "$hname : Copy Failed $source to $target"
	 $msg.body = "Rerun copy"  
	 $attach=new-object System.Net.Mail.Attachment($LogFile)
	 $msg.Attachments.Add($attach)

	 $smtp.Send($msg)
	 $attach.Dispose()


#	If ($dbname -eq "MODEL")
#	{		
#		$msg.subject = "PowerBuilder Distribution to Model Directory" 
#		$msg.body = "ReRunning Task"  
#		$smtp.Send($msg)
#               start powershell '\\pro-file1\Application Development\OASIS\OasisRelease\run_oasis_directory_copy.ps1'  MODEL  > c:\batch\log\MODEL_run_oasis_directory_copy_rerun.txt 2>&1
#	}
#

        }
  else 
	{
	 Write-Output "Successfully copied  $sourceB  " | Out-File $LogFile -append
	 Write-Output "-----------------------------------------------------------------------------------------------------------------------------" | Out-File $LogFile -append
	 Write-Output " " | Out-File $LogFile -append
	 Write-Output "---------------- Verify release from database and INI -------------------" | Out-File $LogFile -append
	 $release_check | Out-File $LogFile -append 
	 Write-Output "-----------------------------------------------------------------------------------------------------------------------------" | Out-File $LogFile -append
	 Get-ChildItem $target | Out-File $LogFile -append

	 $hname_pref = $hname.StartsWith("PRO-XEN64-A03")     #  if prod, always email  
         if ($hname_pref)
          {
		$msg.subject = "PowerBuilder Copy to Production Folders Submitted" 
		$msg.body = "\\pro-sql-ops\log"  
		$smtp.Send($msg)
          }

#	If ($dbname -eq "MODEL")
#	{		
#		$msg.subject = "PowerBuilder Distribution to Model Directory" 
#		$msg.body = " "  
#		$attach=new-object System.Net.Mail.Attachment($LogFile)
#	 	$msg.Attachments.Add($attach)
#		$smtp.Send($msg)
#		$attach.Dispose()
#	}
#
	If ($dbname -eq "POC")
	{		
		$msg.subject = "Oasis PowerBuilder Distribution to POC Directory" 
		$msg.body = " "  
		$attach=new-object System.Net.Mail.Attachment($LogFile)
	 	$msg.Attachments.Add($attach)
		$smtp.Send($msg)
		$attach.Dispose()
	}

}
# end if

 $cnt++
}	while ($cnt -lt $max)


Copy-Item $LogFile $target


