# Bind to user object in AD.
$User =  [ADSI]:"LDAP://cn=Test, George,OU=Underwriting,OU=Houston,OU=Users Win7,OU=Offices Win7,OU=MAI,OU=Enterprise Admins,DC=corporate,DC=local"
# Expire password immediately.
$User.pwdLastSet = 0
# Save change in AD.
$User.SetInfo()
