﻿Import-Module activedirectory
$medmarcirusers = Import-Csv "C:\users\gbromley\desktop\medmarcIR.csv"
foreach ($user in $medmarcirusers){

Get-ADUser -identity $user.username | format-table Name, ObjectGUID  | out-file C:\users\gbromley\desktop\medmarcIRUsersGUID.csv
}