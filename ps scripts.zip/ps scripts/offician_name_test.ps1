﻿$Names_List = Import-Csv 'c:\Users\gbromley\Desktop\username_test.csv'
foreach ($entry in $Names_List){
$username = $($entry.User_Name)
$Fullname = $($entry.Full_Name)

#Echo values to verify results
Write-Host $username
Write-Host $Fullname
#Write changes to AD user accounts
Get-QADUser $username | Set-QADUser -objectAttributes @{extensionAttribute1=$Fullname}
}

