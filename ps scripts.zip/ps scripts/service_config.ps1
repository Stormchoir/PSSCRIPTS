$computers = get-content oasis_servers.txt
foreach ($server in $computers)
{
set-service snmptrap -startuptype automatic -status running
}