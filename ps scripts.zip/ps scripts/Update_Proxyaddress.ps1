Import-Module ActiveDirectory
$domainController = 'pro-oke-dc1.corporate.local'
$searchBase = 'ou=Information Systems,ou=Austin,ou=Users Win7,ou=Offices Win7,ou=MAI,ou=enterprise admins,dc=corporate,dc=local'

$users = Get-ADUser -SearchBase $searchBase -SearchScope Subtree -Filter { ObjectClass -eq "user" } -Properties ProxyAddresses

ForEach ($user in $users) {
	$newSip = 'SIP:' + $user.SamAccountName + '@proassurance.com'
	Write-Host "Adding $newSip to" $user.SamAccountName
	Set-ADUser -Identity $user.DistinguishedName -remove @{proxyAddresses = $newSip} 
}
