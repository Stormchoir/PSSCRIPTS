﻿# get a set of DateTime values from the pipeline
# filter out $nulls and produce the latest of them
# (c) Dmitry Sotnikov
function Measure-Latest {
    BEGIN { $latest = $null }
    PROCESS {
            if (($_ -ne $null) -and (($latest -eq $null) -or ($_ -gt $latest))) {
                $latest = $_ 
            }
    }
    END { $latest }
}
Get-QADComputer -ComputerRole DomainController | foreach {
(Get-QADUser -Service $_.Name -SamAccountName mas-admin).LastLogon
} | Measure-Latest

