$Collections = (Get-WmiObject -ComputerName pro-cm-2012  -Namespace root/SMS/site_sitecode -Query "SELECT SMS_Collection.* FROM SMS_FullCollectionMembership, SMS_Collection where name = 'bhm-ex1' and SMS_FullCollectionMembership.CollectionID = SMS_Collection.CollectionID").Name

Write-Host $Collections