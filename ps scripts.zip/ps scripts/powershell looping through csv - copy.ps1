﻿$cls
# we take data from 3 CSV files to build overall profile for users to import into AD

$OfficeLocationCSV = Import-Csv "\\corporate\birmingham\information systems\obdata\addresses.csv"
$ADOUCSV = Import-Csv "\\corporate\birmingham\Information Systems\OBData\ADOUCSV.csv"
#$ADGroupsCSV = Import-Csv "Path to CSV file"

$CSVData = Import-Csv "c:\users\gbromley\documents\poshtestcsv.csv"

#Start foreach loop
ForEach ( $Line in $CSVData ) {
    
    #Pull Office Info from refrence sheet
    $OfficeInfo = $OfficeLocationCSV | Where-Object { $_.office -eq $Line.office }
    #$OfficeInfo | GM
    $OfficeInfo
    #Enumarte query reponse
    $OfficeInfo.StreetAddress
    $OfficeInfo.City
    $OfficeInfo.StateorProvence
    $OfficeInfo.PostalCode
    $OfficeInfo.Country
    }



#Office	StreetAddress	City	StateorProvence	PostalCode	Country
#Birmingham	100 Brookwood Place	Birmingham	AL	35209	USA
