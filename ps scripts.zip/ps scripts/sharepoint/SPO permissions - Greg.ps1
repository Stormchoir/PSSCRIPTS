﻿#connect to msonline
Connect-MsolService
#connect to sharepoint online
Connect-SPOService
#enumerate sites
get-spouser -Site https://proassurance.sharepoint.com/sites/psrp | ft -wrap -auto | Out-String -Width 4096 | out-file "c:\temp\spo_permissions2.csv"