#Purpose: Create report of all permissions in a sharepoint site collection

$siteUrl="https://proassurance.sharepoint.com/sites/psrp"
$username = "gbromley@proassurance.com"
$password = ""

$XmlOutputFile= "$(Split-Path($($myInvocation.MyCommand.Definition)))\SPPermissionInfo_$(Get-Date -f %M%dyyyyhhmm).xml"
$csvOutputFile= "$(Split-Path($($myInvocation.MyCommand.Definition)))\SPPermissionInfo_$(Get-Date -f %M%dyyyyhhmm).csv"

#Connect to Source Site

$encpassword = convertto-securestring -String $password -AsPlainText -Force
$cred = new-object -typename System.Management.Automation.PSCredential -argumentlist $username, $encpassword
$Site= Connect-PnPOnline -Url $siteUrl -Credentials $cred 
$topWeb =Get-PnPWeb $Site -Includes RoleAssignments, HasUniqueRoleAssignments;
$rootwebContext=Get-PnPContext;



function getWebAndListPermissions($web){
    Enable-PnPFeature -Identity 41e1d4bf-b1a2-47f7-ab80-d5d6cbba3092
        $webUrl=$web.URL
        Write-Progress -activity "Getting permissions from web: $webUrl"
        
            $writer.WriteStartElement("WebPermissions")
    foreach ( $ra in $web.RoleAssignments){
        $rootwebContext.Load($ra.Member);
        $rootwebContext.Load($ra.RoleDefinitionBindings)
    }
        $rootwebContext.ExecuteQuery()
        $brokenInheritance="No"
        if($web.HasUniqueRoleAssignments -eq $true){$brokenInheritance="Yes"}
    foreach($ra in $web.RoleAssignments){   
        $roles=@()
            foreach($role in $ra.RoleDefinitionBindings){$roles+=$role.Name}
            $permlevel=$roles -join '; '     
        if($ra.Member.PrincipalType -eq "SharePointGroup"){            
            $grp=Get-PnPGroup -Identity $ra.Member.Title -Includes Users,OwnerTitle
            logCsvRow -web $web -member $ra.Member -IDType "SPGroup" -permLevel $permlevel -group $ra.Member.Title -uniqueRoles $brokenInheritance -owner $grp.OwnerTitle
            $Writer.WriteStartElement("Permission")
				Write-XMLAttribute -Name "PermissionLevel" -Value $permlevel -Writer $writer
                Write-XMLAttribute -Name "IdentityType" -Value "SPGroup" -Writer $writer
                Write-XMLAttribute -Name "Group" -Value $ra.Member.Title -Writer $writer
                Write-XMLAttribute -Name "Owner" -Value $grp.OwnerTitle -Writer $writer
                        
            foreach($user in $grp.Users){
                logCsvRow -web $web -member $user -IDType $user.PrincipalType -permLevel $permlevel -group $ra.Member.Title -uniqueRoles $brokenInheritance -owner $grp.OwnerTitle
                $Writer.WriteStartElement("Member")
                    $login=$user.LoginName.replace("i:0#.f|membership|","")
                    Write-XMLAttribute -Name "UserLogin" -Value $login -Writer $writer
                    Write-XMLAttribute -Name "DisplayName" -Value $user.Title -Writer $writer
                    Write-XMLAttribute -Name "IdentityType" -Value $user.PrincipalType -Writer $writer
                $Writer.WriteEndElement() #End User                    
            }
            $Writer.WriteEndElement() #End Group Permission
        }
        else {
            logCsvRow -web $web -member $ra.Member -IDType $ra.Member.PrincipalType -permLevel $permlevel -uniqueRoles $brokenInheritance
            $Writer.WriteStartElement("Permission")
                    Write-XMLAttribute -Name "PermissionLevel" -Value $permlevel -Writer $writer
                    Write-XMLAttribute -Name "IdentityType" -Value $ra.Member.PrincipalType -Writer $writer
                    $login=$ra.member.LoginName.replace("i:0#.f|membership|","")
                    Write-XMLAttribute -Name "UserLogin" -Value $login -Writer $writer
                    Write-XMLAttribute -Name "DisplayName" -Value $ra.Member.Title -Writer $writer                    
            $Writer.WriteEndElement() #End User Permission 
        }
    }
    $Writer.WriteEndElement() #End Web Permissions


    $lists=get-pnplist -Includes HasUniqueRoleAssignments, RoleAssignments
    $i=0;
    $visableLists=$lists|?{$_.Hidden -ne $true};
        $webCtx=Get-PnPContext
            $writer.WriteStartElement("Lists")
            foreach($list in $visableLists){ 
                $writer.WriteStartElement("List")
                    Write-XMLAttribute -Name "Title" -Value $list.Title -Writer $writer
                    Write-XMLAttribute -Name "URL" -Value $list.DefaultViewUrl -Writer $writer
                    Write-XMLAttribute -Name "BrokenInheritance" -Value $list.HasUniqueRoleAssignments -Writer $writer
                
                    $i++;                    
                    $listTitle=$list.Title;
                    $percentComplete=(($i/$visableLists.count)*100)
                    Write-Progress -activity "Getting permissions from web: $webUrl" -Status "Progress in web" -PercentComplete $percentComplete -CurrentOperation "Current List: $listTitle"

                    foreach ( $ra in $list.RoleAssignments){
                        $webCtx.Load($ra.Member);
                        $webCtx.Load($ra.RoleDefinitionBindings)
                    }
                        $webCtx.ExecuteQuery()
                        $brokenInheritance="No"
                        if($list.HasUniqueRoleAssignments -eq $true){$brokenInheritance="Yes"}
                    foreach($ra in $list.RoleAssignments){   
                        $roles=@()
                            foreach($role in $ra.RoleDefinitionBindings){$roles+=$role.Name}
                            $permlevel=$roles -join '; '     
                        if($ra.Member.PrincipalType -eq "SharePointGroup"){            
                            $grp=Get-PnPGroup -Identity $ra.Member.Title -Includes Users,OwnerTitle
                            logCsvRow -web $web -list $list -member $ra.Member -IDType "SPGroup" -permLevel $permlevel -group $ra.Member.Title -uniqueRoles $brokenInheritance -owner $grp.OwnerTitle
                            $Writer.WriteStartElement("Permission")
                                Write-XMLAttribute -Name "PermissionLevel" -Value $permlevel -Writer $writer
                                Write-XMLAttribute -Name "IdentityType" -Value "SPGroup" -Writer $writer
                                Write-XMLAttribute -Name "Group" -Value $ra.Member.Title -Writer $writer
                                Write-XMLAttribute -Name "Owner" -Value $grp.OwnerTitle -Writer $writer
                            
                            foreach($user in $grp.Users){
                                logCsvRow -web $web -list $list -member $user -IDType $user.PrincipalType -permLevel $permlevel -group $ra.Member.Title -uniqueRoles $brokenInheritance -owner $grp.OwnerTitle
                                $Writer.WriteStartElement("Member")
                                    $login=$user.LoginName.replace("i:0#.f|membership|","")
                                    Write-XMLAttribute -Name "UserLogin" -Value $login -Writer $writer
                                    Write-XMLAttribute -Name "DisplayName" -Value $user.Title -Writer $writer
                                    Write-XMLAttribute -Name "IdentityType" -Value $user.PrincipalType -Writer $writer
                                $Writer.WriteEndElement() #End User 
                            }
                            $Writer.WriteEndElement() #End Group Permission
                        }
                        else {
                            logCsvRow -web $web -list $list -member $ra.Member -IDType $ra.Member.PrincipalType -permLevel $permlevel -uniqueRoles $brokenInheritance
                            $Writer.WriteStartElement("Permission")
                                Write-XMLAttribute -Name "PermissionLevel" -Value $permlevel -Writer $writer
                                Write-XMLAttribute -Name "IdentityType" -Value $ra.Member.PrincipalType -Writer $writer
                                $login=$ra.member.LoginName.replace("i:0#.f|membership|","")
                                Write-XMLAttribute -Name "UserLogin" -Value $login -Writer $writer
                                Write-XMLAttribute -Name "DisplayName" -Value $ra.Member.Title -Writer $writer                    
                            $Writer.WriteEndElement() #End User Permission 
                        }
                    }
                    $Writer.WriteEndElement() #End List
                }
            $writer.WriteEndElement() #End Lists
                
                
}

#region Script Functions
function logCsvRow($web,$member,$IDType,$permLevel,$list,$group,$uniqueRoles,$owner){
    
    $ScriptsObject= New-Object PSObject
    $ScriptsObject | Add-Member -MemberType NoteProperty -Name "WebName" -Value $web.Title
    $ScriptsObject | Add-Member -MemberType NoteProperty -Name "WebUrl" -Value $web.Url
    $ScriptsObject | Add-Member -MemberType NoteProperty -Name "ListName" -Value $list.Title
    $ScriptsObject | Add-Member -MemberType NoteProperty -Name "ListUrl" -Value $list.DefaultViewUrl
    $ScriptsObject | Add-Member -MemberType NoteProperty -Name "PermissionsLevel" -Value $permLevel
    $ScriptsObject | Add-Member -MemberType NoteProperty -Name "Group" -Value $group
    $ScriptsObject | Add-Member -MemberType NoteProperty -Name "GroupOwner" -Value $owner
    $login=$member.LoginName.replace("i:0#.f|membership|","")
    $ScriptsObject | Add-Member -MemberType NoteProperty -Name "UserLogin" -Value $login
    $ScriptsObject | Add-Member -MemberType NoteProperty -Name "DisplayName" -Value $member.Title
    $ScriptsObject | Add-Member -MemberType NoteProperty -Name "IdentityType" -Value $IDType
    $ScriptsObject | Add-Member -MemberType NoteProperty -Name "BrokenInheritance" -Value $uniqueRoles
    $ScriptsObject | Export-Csv -Append $csvOutputFile -NoTypeInformation
}

function Write-XMLAttribute {
	param(
		[System.Xml.XmlWriter] $Writer,
		[String] $Name,
		[String] $Value		
	)
	$Writer.WriteAttributeString($Name,$Value)
}

#  function to loop through children webs
function GetSubwebsandLibs($ParentSite){
    $writer.WriteStartElement("Webs")
    $subwebs=Get-PnPSubWebs -Web $ParentSite -Includes RoleAssignments, HasUniqueRoleAssignments
    foreach ($w in $subwebs){
        Connect-PnPOnline -Url $w.Url -Credentials $cred
            $writer.WriteStartElement("Web")
                Write-XMLAttribute -Name "Title" -Value $w.Title -Writer $writer
                Write-XMLAttribute -Name "URL" -Value $w.URL -Writer $writer
                Write-XMLAttribute -Name "BrokenInheritance" -Value $w.HasUniqueRoleAssignments -Writer $writer
        getWebAndListPermissions -web $w
            
        GetSubwebsandLibs -ParentSite $w
            
            $Writer.WriteEndElement() #End Web
    }
    $Writer.WriteEndElement() #End Webs
}

# EndRegion

#  End Functions, begin logic

$begin=Get-Date
write-host Beginning permissions report creation $begin

# begin XML
$writer= New-Object System.Xml.XmlTextWriter($XmlOutputFile,[System.Text.Encoding]::UTF8)
$writer.WriteStartDocument()
    $writer.WriteStartElement("TopWeb")
            Write-XMLAttribute -Name "Title" -Value $topweb.Title -Writer $writer
            Write-XMLAttribute -Name "URL" -Value $topweb.URL -Writer $writer
            Write-XMLAttribute -Name "BrokenInheritance" -Value $topweb.HasUniqueRoleAssignments -Writer $writer
getWebAndListPermissions $topWeb

GetSubwebsandLibs -ParentSite $topWeb;

    $Writer.WriteEndElement() #End TopWeb
    $Writer.Close()
$End=Get-Date
write-host Ended permissions report successfully $End

