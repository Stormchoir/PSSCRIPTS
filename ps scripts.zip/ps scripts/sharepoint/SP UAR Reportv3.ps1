﻿#Add SharePoint PowerShell SnapIn if not already added
if ((Get-PSSnapin "Microsoft.SharePoint.PowerShell" -ErrorAction SilentlyContinue) -eq $null) {
    Add-PSSnapin "Microsoft.SharePoint.PowerShell"
}

import-module activedirectory

 #Change these variables as desired, If RemoveUsers is true then only user will get removed otherwise it will get only logged.
 $WebAppURL="http://employees.medmarc.com"

   
 #Get all Site Collections of the web application
 $WebApp = Get-SPWebApplication $WebAppURL
 $textout = ""
 $uarfile = ""
 #$textout > $uarfile

function OutputRoleAssignments()
{
    Param( [Parameter(Mandatory=$true)] $User )
    
    $RoleAssignment = $webp.RoleAssignments.GetAssignmentByPrincipal($User)
    $RoleDefinitionNames=""
    foreach ($RoleDefinition in $RoleAssignment.RoleDefinitionBindings)
    {  
        $RoleDefinitionNames+=$RoleDefinition.Name#+";"
    }

    
    if ($RoleDefinitionNames -ne "")
    {
        $textout = """$($User.Name)"",""$($RoleDefinitionNames)"","  
        $textout >> $uarfile 
    }

}

function OutputADGroupMembers()
{
    Param( [Parameter(Mandatory=$true)] $User )
    
    if ($user.name -ne "corporate\domain users")
    {
        $adgroup = get-adgroupmember -identity $user.loginname.replace("CORPORATE\", "") | select name

        foreach ($aduser in $adgroup)
        {
            $textout = """$($aduser.Name)"",,"
            $textout >> $uarfile
        }
    }

}

 #Iterate through all Site Collections
 foreach($site in $WebApp.Sites)  
 {
    if ($site -ne $null)
    {
        $web = $site.AllWebs
        foreach ($webp in $web)
        {
            if (($webp.permissions -ne $null) -and ($webp.hasuniqueroleassignments -eq "True"))
            {
                #Prep the output file
                $uarfile = ".\" + $site.name + "_" + $webp.name + "_" + $(((get-date).ToLocalTime()).ToString("yyyyMMddThhmmss")) +".csv"
                $textout = """User/Group"",""Role"",""Approval""" | Export-Csv -Path $uarfile #-Encoding utf-8 #-NoTypeInformation
                #$textout >> $uarfile

                #Iterate through the users collection
                foreach($User in $webp.Users)
                {
                    #Get Permission Levels Applied to the User   
                    OutputRoleAssignments($User)

                    if ($User.IsDomainGroup -eq $true )
                    {
                        OutputADGroupMembers($User)
                    }
    
                }
                
                #Iterate through the groups collection
                foreach ($Group in $webp.groups) 
                {
                    #Get Permission Levels Applied to the Group   
                    OutputRoleAssignments($Group)

                    #Iterate through Each User in the group
                    foreach ($User in $Group.users) 
                    {
                        $textout = """$($User.Name)"",,"
                        $textout >> $uarfile

                        if ($User.IsDomainGroup -eq $true )
                        {
                            OutputADGroupMembers($User)
                        } 
                        
                    }
                }
            }
        }
        $webp.Dispose()
    }
}

