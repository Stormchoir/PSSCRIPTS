$UserCredential = Get-Credential
Connect-SPOService -url https://proassurance.sharepoint.com/SitePages/Home.aspx -Credential $UserCredential