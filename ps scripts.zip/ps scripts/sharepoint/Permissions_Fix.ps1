$LoginName = "corporate\sbowman" #login name of user
$siteURL = "http://sharepoint/is/priv/tech/gregtest/default.aspx" #URL to any site in the web application.
$site = get-spsite $siteURL #get the site
$web = $site.openweb() #get the web
$user =  $web.SiteUsers[$LoginName] #grab the user off the site
$user.Groups|select Name #show all the groups that user is a member of
$group = $web.Groups["Owners"] #pick one of the groups
$group.RemoveUser($user) #deletes user from group
$groupUser.DisplayName #found it helps to add a fluff line
$group.AddUser($user) #add user back to group
$group.Update() #update group