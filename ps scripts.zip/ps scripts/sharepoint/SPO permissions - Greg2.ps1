﻿<#
Ce sript permet d'ajouter les droits à un groupe sur un dossier.
#>


$Username = "gbromley@proassurance.com"
$Site = "https://proassurance.sharepoint.com/sites/x/"
$Password = Read-Host -Prompt "Entrez votre mot de passe" -AsSecureString

$ListName = 'Your library'
$RootFolder = 'Your folder'


#Add references to SharePoint client assemblies and authenticate to Office 365 site
Add-Type -Path 'C:\Program Files\Common Files\microsoft shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.dll'
Add-Type -Path 'C:\Program Files\Common Files\microsoft shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.Runtime.dll'

# Connect to SharePoint Online and get Context object.
$Context = New-Object Microsoft.SharePoint.Client.ClientContext($Site)
$Creds = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($Username,$Password)
$Context.Credentials = $Creds
$Web = $Context.Web
$Context.Load($web)

#Retrieve Groups
$group = $Context.Web.SiteGroups.getByName("Group name");
$Context.Load($group)
$Context.ExecuteQuery()

#Retrieve Folder
$folderurl = $web.ServerRelativeUrl + "/" + $ListName + "/" + $RootFolder
$root = $web.GetFolderByServerRelativeUrl($folderurl)
$Context.Load($root.Folders)
$Context.ExecuteQuery()

Function GetRole
    {
        [CmdletBinding()]
        param
        (
            [Parameter(Mandatory = $true, Position = 1)]
            [Microsoft.SharePoint.Client.RoleType]$rType
        )

        $web = $Context.Web
        if ($web -ne $null)
        {
            $roleDefs = $web.RoleDefinitions
            $Context.Load($roleDefs)
            $Context.ExecuteQuery()
            $roleDef = $roleDefs | Where-Object { $_.RoleTypeKind -eq $rType }
            return $roleDef
        }
        return $null
    }


foreach($folder in $root.Folders){

    #Break inheritance and remove existing permissions
    $folder.ListItemAllFields.BreakRoleInheritance($false, $true)

    #Get the role required and load it 
    $roleType = "Editor"
    write-host  -ForegroundColor Green "Ajout des droits " $roleType "sur le dossier " $folder.Name "Pour le groupe " $group.LoginName
    $roleTypeObject = [Microsoft.SharePoint.Client.RoleType]$roleType
    $roleObj = GetRole $roleTypeObject

    #Bind Permission Level to Group
    $RoleDefBind = New-Object Microsoft.SharePoint.Client.RoleDefinitionBindingCollection($Context)
    $RoleDefBind.Add($roleObj)
    $Assignments = $Context.Web.RoleAssignments

    #Apply the permission roles to the list.
       $Context.Load($folder.ListItemAllFields.RoleAssignments.Add($group, $RoleDefBind))
       $folder.Update()
       $Context.ExecuteQuery()

} 