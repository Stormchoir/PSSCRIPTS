function Connect-SPOSite() {

    param (

        $user = "gbromley@proassurance.onmicrosoft.com",

        $site = "https://proassurance.sharepoint.com"

    ) 

    if ((Get-Module Microsoft.Online.SharePoint.PowerShell).Count -eq 0) {

        Import-Module Microsoft.Online.SharePoint.PowerShell -DisableNameChecking

    }

    $cred = Get-Credential $user

    Connect-SPOService -Url $site -Credential $cred

} 
