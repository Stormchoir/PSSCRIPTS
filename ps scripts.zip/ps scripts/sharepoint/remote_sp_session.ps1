New-PSSession -ComputerName SharePoint.corporate.local
Add-PSSnapin Microsoft.SharePoint.Powershell