$site = �https://proassurance.sharepoint.com/�
#connect-msolservice
Connect-SPOService -Url https://proassurance-admin.sharepoint.com -credential admin@proassurance.onmicrosoft.com
Get-SPOUser -Limit All -Site $site | select * | Format-table -Wrap -AutoSize | Out-File C:\Sharepoint\UsersReport.csv -Force -Width 360 -Append