#Exports full list of sharepoint sites and subsites.
#Must be run from the sharepoint server using sharepoint management shell.

Get-SPWebApplication http://sharepoint | Get-SPSite -Limit All | Get-SPWeb -Limit All | Select Title, URL, ID, ParentWebID | Export-CSV C:\InfoArch.csv -NoTypeInformation