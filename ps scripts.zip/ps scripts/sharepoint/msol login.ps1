﻿Write-Host "Importing Module MSOnline" -ForegroundColor Green
Import-Module MSOnline
$User = "gbromley@proassurance.com"
$Pass = "Sev3nJeans!"
$creds = New-Object System.Management.Automation.PSCredential($User,(ConvertTo-SecureString $Pass -AsPlainText -Force));
#$creds = Get-Credentials;
Write-Host "Connecting To Microsoft Online Service" -ForegroundColor Green
Connect-MsolService -Credential $creds
Write-Host "Connecting To SharePoint Online Service" -ForegroundColor Green
Connect-SPOService -Url https://proassurance-admin.sharepoint.com -Credential $creds