﻿<#
.SYNOPSIS
    This script will copy files from a network location to the local computer.
.DESCRIPTION
    Tasks performed by this script:
    1. Identify if computer is devolopment model or production
    2. Copy files from network shares by appliction
        2a. CFS
        2b. Claims Recommendation
        2c. Claims Letters
        2d. NPDB
    3. Run a batch file from a network share
    4. Write log file
.NOTES
    File Name      : Citrix_Startup_Script.ps1
    Author         : Mark Scott (mark.scott@siriuscom.com)
    Date           : 2019.07.02
    Version        : 1.0
    Log folder variable is required.
    The user of this script may change any varaible until line 67.
    Credit the great log to file fuction to wasserja and found: https://gallery.technet.microsoft.com/scriptcenter/Write-Log-PowerShell-999c32d0
.PARAMETER
    -None-
.OUTPUT
    A log file with the computer name will be saved in the folder defined in a variable within the script.
.EXAMPLE
    This script has no input parameters
    .\Citrix_Startup_Script.ps1
#>

# Clear all user variables
Remove-Variable * -ErrorAction SilentlyContinue

#-------------------Required User Script Variables-----------------------

# !Required! Log Folder path for the script.  This script will create log files by short computer name within the folder. Path can be network path as long as the computer account or service account running the script has write access.
[String]$LogFolder = "\\corporate\birmingham\AppDev\Citrix_Deployments\Logs"

# Source and destination changable variables
[String]$App1Source = "\\corporate\birmingham\AppDev\Citrix_Deployments\CFS"
[String]$App1Destination = "C:\PBNetControls\Oasis.Claims.CFS"

[String]$App2Source = "\\corporate\birmingham\AppDev\Citrix_Deployments\Claim_recommendation"
[String]$App2Destination = "C:\PBNetControls\Oasis.Claims.NpDb"

[String]$App3Source = "\\corporate\birmingham\AppDev\Citrix_Deployments\Claims letters"
[String]$App3Destination = "C:\PBNetControls\ClaimsLetters"

[String]$App4Source = "\\corporate\birmingham\AppDev\Citrix_Deployments\NPDB"
[String]$App4Destination = "C:\PBNetControls\ClaimsRecommendations"

# Application post copy scripts path.  Can be network path as long as the computer account or service account running the script has read access.
[String]$App1Script = "\\corporate\birmingham\AppDev\Citrix_Deployments\CFS\Script\script.bat"
[String]$App2Script = "\\corporate\birmingham\AppDev\Citrix_Deployments\Claim_recommendation\Script\script.bat"
[String]$App3Script = "\\corporate\birmingham\AppDev\Citrix_Deployments\Claims letters\Script\script.bat"
[String]$App4Script = "\\corporate\birmingham\AppDev\Citrix_Deployments\NPDB\Script\script.bat"

# Application devopment post-copy script working directory
[String]$ScriptWorkingFolder = "C:\PBNetControls"

# Folder name in each source folder defining Model or Production files
[String]$ModelFolder = "Model"
[String]$ProductionFolder = "Prod"

# Charectors found in a devopment model computer name
[String]$ModelComputer = "mod"

<#
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

-------------------DO NOT MODIFY BELOW THIS LINE-----------------------

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
#>

#-------------------Logging Function-----------------------
Function Write-Log 
{
    [CmdletBinding()] 
    Param 
    ( 
        [Parameter(Mandatory=$true, 
                   ValueFromPipelineByPropertyName=$true)] 
        [ValidateNotNullOrEmpty()] 
        [Alias("LogContent")] 
        [string]$Message, 
 
        [Parameter(Mandatory=$false)] 
        [Alias('LogPath')] 
        [string]$Path=$LogPath,
         
        [Parameter(Mandatory=$false)] 
        [ValidateSet("Error","Warn","Info")]
        [string]$Level="Info", 
         
        [Parameter(Mandatory=$false)] 
        [switch]$NoClobber 
    ) 
 
    Begin 
    { 
        # Set VerbosePreference to Continue so that verbose messages are displayed. 
        $VerbosePreference = 'Continue' 
    } 
    Process 
    { 
         
        # If the file already exists and NoClobber was specified, do not write to the log. 
        if ((Test-Path $Path) -AND $NoClobber) { 
            Write-Error "Log file $Path already exists, and you specified NoClobber. Either delete the file or specify a different name." 
            Return 
            } 
 
        # If attempting to write to a log file in a folder/path that doesn't exist create the file including the path. 
        elseif (!(Test-Path $Path)) { 
            Write-Verbose "Creating $Path." 
            $NewLogFile = New-Item $Path -Force -ItemType File 
            } 
 
        else { 
            # Nothing to see here yet. 
            } 
 
        # Format Date for our Log File 
        $FormattedDate = Get-Date -Format "yyyy-MM-dd HH:mm:ss" 
 
        # Write message to error, warning, or verbose pipeline and specify $LevelText 
        switch ($Level) { 
            'Error' { 
                Write-Error $Message 
                $LevelText = 'ERROR:' 
                } 
            'Warn' { 
                Write-Warning $Message 
                $LevelText = 'WARNING:' 
                } 
            'Info' { 
                Write-Verbose $Message 
                $LevelText = 'INFO:' 
                } 
            } 
         
        # Write log entry to $Path 
        "$FormattedDate $LevelText $Message" | Out-File -FilePath $Path -Append 
    } 
    End 
    { 
    } 
}

#-------------------Variable Manipulation-----------------------
# Inilize the variable
[Bool]$ProductionComputer = $True

# Create the log file path variable
$LogPath = (Join-Path -Path $LogFolder -ChildPath $env:computername) + '.log'

# Prepare for like evaluation
$ModelComputer = "*" + $ModelComputer.trim() + "*"

#-------------------Evaluate Script Environment-----------------------

# Evaluate if log folder does not exist
If (!(Test-Path $LogFolder)) {
    Write-Host "Script is not able to find the log folder defined in variable 'LogFolder'.  The variable currently contains the value: $LogFolder. The script will exit."
    Exit
    }

# Evaluate if any post copy scripts do not exist
If (!(Test-Path $App1Script)) {
    Write-Host "This script is not able to find the post execuation script file defined in variable 'App1Script'.  The current path is $App1Script."
    Write-Log -Message "This script is not able to find the post execuation script file defined in variable 'ScriptPath'.  The current path is $App1Script." -Level Warn -Path $LogPath
    }

If (!(Test-Path $App2Script)) {
    Write-Host "This script is not able to find the post execuation script file defined in variable 'App2Script'.  The current path is $App2Script."
    Write-Log -Message "This script is not able to find the post execuation script file defined in variable 'ScriptPath'.  The current path is $App2Script." -Level Warn -Path $LogPath
    }

If (!(Test-Path $App3Script)) {
    Write-Host "This script is not able to find the post execuation script file defined in variable 'App3Script'.  The current path is $App3Script."
    Write-Log -Message "This script is not able to find the post execuation script file defined in variable 'ScriptPath'.  The current path is $App3Script." -Level Warn -Path $LogPath
    }

If (!(Test-Path $App4Script)) {
    Write-Host "This script is not able to find the post execuation script file defined in variable 'App4Script'.  The current path is $App4Script."
    Write-Log -Message "This script is not able to find the post execuation script file defined in variable 'ScriptPath'.  The current path is $App4Script." -Level Warn -Path $LogPath
    }

# Evaluate if post copy working directory does not exist
If (!(Test-Path $ScriptWorkingFolder)) {
    Write-Host "This script is not able to find the post execuation script working directory in variable 'ScriptWorkingFolder'.  The variable contains the value: $ScriptWorkingFolder"
    Write-Log -Message "This script is not able to find the post execuation script working directory in variable 'ScriptWorkingFolder'.  The variable contains the value: $ScriptWorkingFolder" -Level Warn -Path $LogPath
    }

# Evaluate if computer is Model or Production, and set source paths
If ($env:computername -like $ModelComputer) {
    Write-Log -Message "The computer is as a Model computer" -Level Info -Path $LogPath
    $App1Source = Join-Path -Path $App1Source -ChildPath $ModelFolder
    $App2Source = Join-Path -Path $App2Source -ChildPath $ModelFolder
    $App3Source = Join-Path -Path $App3Source -ChildPath $ModelFolder
    $App4Source = Join-Path -Path $App4Source -ChildPath $ModelFolder
    }
Else {
    Write-Log -Message "The computer is as a Production computer" -Level Info -Path $LogPath
    $App1Source = Join-Path -Path $App1Source -ChildPath $ProductionFolder
    $App2Source = Join-Path -Path $App2Source -ChildPath $ProductionFolder
    $App3Source = Join-Path -Path $App3Source -ChildPath $ProductionFolder
    $App4Source = Join-Path -Path $App4Source -ChildPath $ProductionFolder
    }

# Evaluate if source paths do not exist
If (!(Test-Path -Path $App1Source)) {Write-Log -Message "Source folder not found: $App1Source" -Level Warn -Path $LogPath}
If (!(Test-Path -Path $App2Source)) {Write-Log -Message "Source folder not found: $App2Source" -Level Warn -Path $LogPath}
If (!(Test-Path -Path $App3Source)) {Write-Log -Message "Source folder not found: $App3Source" -Level Warn -Path $LogPath}
If (!(Test-Path -Path $App4Source)) {Write-Log -Message "Source folder not found: $App4Source" -Level Warn -Path $LogPath}

#-------------------Copy File & Log Section-----------------------

Write-Log -Message "Copied $App1Source to $App1Destination" -Level Info -Path $LogPath
RoboCopy $App1Source $App1Destination /MIR /V /NP | Select -Skip 14 | Select -SkipLast 13 | Out-File -FilePath $LogPath -Append

Write-Log -Message "Copied $App2Source to $App2Destination" -Level Info -Path $LogPath
RoboCopy $App2Source $App2Destination /MIR /V /NP | Select -Skip 14 | Select -SkipLast 13 | Out-File -FilePath $LogPath -Append

Write-Log -Message "Copied $App3Source to $App3Destination" -Level Info -Path $LogPath
RoboCopy $App3Source $App3Destination /MIR /V /NP | Select -Skip 14 | Select -SkipLast 13 | Out-File -FilePath $LogPath -Append

Write-Log -Message "Copied $App4Source to $App4Destination" -Level Info -Path $LogPath
RoboCopy $App4Source $App4Destination /MIR /V /NP | Select -Skip 14 | Select -SkipLast 13 | Out-File -FilePath $LogPath -Append

#-------------------Invoke and Log Post Copy Script-----------------------

# NOTE: this PowerShell script will wait indefintally until the batch files close.  Logging for the batch file should be self contained.
Write-Log -Message "Starting the post copy script $App1Script" -Level Info -Path $LogPath
Start-process -FilePath "C:\Windows\System32\cmd.exe" -ArgumentList '/c',$App1Script -WorkingDirectory $ScriptWorkingFolder -Wait

Write-Log -Message "Starting the post copy script $App2Script" -Level Info -Path $LogPath
Start-process -FilePath "C:\Windows\System32\cmd.exe" -ArgumentList '/c',$App2Script -WorkingDirectory $ScriptWorkingFolder -Wait

Write-Log -Message "Starting the post copy script $App3Script" -Level Info -Path $LogPath
Start-process -FilePath "C:\Windows\System32\cmd.exe" -ArgumentList '/c',$App3Script -WorkingDirectory $ScriptWorkingFolder -Wait

Write-Log -Message "Starting the post copy script $App4Script" -Level Info -Path $LogPath
Start-process -FilePath "C:\Windows\System32\cmd.exe" -ArgumentList '/c',$App4Script -WorkingDirectory $ScriptWorkingFolder -Wait

# And we are done! Yah!
Write-Log -Message "The PowerShell startup script is complete." -Level Info -Path $LogPath
Exit