﻿# Define Variables

$provscheme = "Xen App 7 B Servers"
$filename = "MasterImage_Snapshot_$(get-date -f MMM-d-yyyy-hh-mm)"
#New-HypVMSnapshot -AdminAddress $XDServername -LiteralPath 'XDHyp:\VMPATH\VMNAME.vm' -SnapshotName "$filename" -SnapshotDescription "$description" 
#create a new snapshot of the master image.
New-HypVMSnapshot -LiteralPath "XDHyp:\HostingUnits\VLAN_40\bhm-xenoff-prod.vm" -SnapshotName $filename -SnapshotDescription "PS Snapshot Test"

"XDHyp:\HostingUnits\VLAN_40\bhm-xenoff-prod.vm\VM Snapshot ‎11‎%252f‎2‎%252f‎2018‎ ‎10‎:‎40‎:‎09‎ ‎AM.snapshot"
$cursnap = Get-ChildItem -Path "XDHyp:\HostingUnits\VLAN_40\bhm-xenoff-prod.vm\VM Snapshot ‎11‎%252f‎2‎%252f‎2018‎ ‎10‎:‎40‎:‎09‎ ‎AM.snapshot"
$cursnap.FullPath
