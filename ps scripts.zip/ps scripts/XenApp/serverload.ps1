asnp *citrix*
Get-BrokerMachine | Select-Object dnsname,loadindex,windowsconnectionsetting,sessioncount | ft -autosize