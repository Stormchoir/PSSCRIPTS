﻿$xenservers = import-csv "\\corporate\proassurance\home\gbromley\scripts\powershell\xenapp\servers.csv"
foreach ($line in $xenservers) {
Get-CimInstance -ClassName win32_operatingsystem -ComputerName $line.server | select csname, lastbootuptime
}
