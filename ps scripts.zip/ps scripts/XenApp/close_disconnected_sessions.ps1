#Close disconnected sessions

add-pssnapin Citrix*
#Get-XASession -Farm -ComputerName pro-xen64-zdc | Where-Object { $_.State -eq "Disconnected" }
Get-XASession -Farm -ComputerName pro-xen64-zdc | Where-Object { $_.State -eq "Disconnected" } | Stop-XASession

#Get-XASession -Farm -ComputerName pro-xen64-zdc | where { ($_.BrowserName -eq "<Application name>") } | Stop-XASession 
