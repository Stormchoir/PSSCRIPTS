$object = Get-WmiObject -Namespace "root\citrix" -Class MetaFrame_Server_LoadLevel | Select-Object LoadLevel
if($object.LoadLevel -ge 9000) {
 Write-Host "Error: Extremly high load: "$object.LoadLevel
 exit 2
}

ElseIf ($object.LoadLevel -gt 7500) {
 Write-Host "Warning: High load: "$object.LoadLevel
 exit 1
}

ElseIf($object.LoadLevel -lt 1) {
 Write-Host "Unknown: Server not in production?"$object.LoadLevel
 exit 3
}

else {
 Write-Host "OK: Load "$object.LoadLevel
 exit 0
}
