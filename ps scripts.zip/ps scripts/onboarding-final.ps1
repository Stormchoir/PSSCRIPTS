﻿#Title: New user creation script
#Purpose: Creation of user accounts across all lines of business.
#
#Author: Greg Bromley
#
#
# Setup:
# You need to install Exchange 2016 Management Tools.
#
# Import the necessary modules
Import-Module ActiveDirectory
Add-PSSnapin *Exchange*

#This comment section can be removed.
#Establish a session with Exchange
#Note: Currently requires interaction from the user running the script.
#$Session = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri http://bhm-ex1.corporate.local/PowerShell/ -Authentication Kerberos -Credential $UserCredential

#Take data from user input to determine office and department.
cls
# we take data from 3 CSV files to build overall profile for users to import into AD

$OfficeLocationCSV = Import-Csv "\\corporate\birmingham\information systems\obdata\addresses.csv"
$ADOUCSV = Import-Csv "\\corporate\birmingham\Information Systems\OBData\ADOUCSV.csv"
$ADGroupsCSV = Import-Csv "\\corporate\birmingham\Information Systems\OBData\ADGROUPS.csv"
$ExchmailboxDB = Import-Csv "\\corporate\birmingham\Information Systems\OBData\mailboxdb.csv"

#change this path to where ever you plan to store user data.
$CSVData = Import-Csv "c:\users\gbromley\documents\poshtestcsv.csv"

#Start foreach loop
ForEach ( $Line in $CSVData ) {
    
    #Pull Office Info from refrence sheet
    $OfficeInfo = $OfficeLocationCSV | Where-Object { $_.office -eq $Line.office }
    
    #Pull OU Info from reference sheet
    $ouinfo = $adoucsv | Where-Object { ($_.office -eq $Line.Office) -and ($_.Department -eq $Line.Department)}
    

    #Pull group memberships from reference sheet
    $groupinfo = $adgroupscsv | Where-Object { ($_.Office -eq $Line.Office) -and ($_.department -eq $Line.Department) -and ($_.jobtitle -eq $Line.jobtitle) }

    #Pull mailbox database from reference sheet
    $maildatabase = $ExchmailboxDB | Where-Object { ($_.Office -eq $Line.Office) }

    #Define account attributes
    $Displayname = $Line.LastName+", "+$Line.FirstName
    $Name = $Line.LastName+", "+$Line.FirstName
    $username = $Line.FirstName+$Line.LastName.tolower()
    $upn=$Line.UserName+'@proassurance.com'
    $password= convertTo-SecureString $Line.Password -AsPlainText -Force

    #Create mailbox and user account
    New-Mailbox -name $Name -userprincipalname $upn -Alias $username -OrganizationalUnit $ouinfo.ou -FirstName $Line.FirstName -LastName $Line.LastName -Password $Password -ResetPasswordOnNextLogon $true -Database $maildatabase.MailDB -DisplayName $displayname
    Start-Sleep -s 10
    #Set user account properties
    Set-ADUser -identity $username -Street $officeinfo.StreetAddress -City $officeinfo.City -State $OfficeInfo.StateorProvence -Postalcode $officeinfo.PostalCode -Title $Line.JobTitle -Description $Line.Department -Office $Line.Office -Department ($Line.Department+" "+$Line.Company+" "+$Line.Office) -Company $Line.Company 
    Set-ADUser -identity $username -Add @{ProxyAddresses="SIP:"+$upn}
    Set-ADUser -identity $username -Add @{'msRTCSIP-PrimaryUserAddress' = "SIP:"+$upn}
    Set-ADUser -identity $username -Add @{'ExtensionAttribute1' = $Line.LastName+", "+$Line.LegalFirstName+" "+$Line.Middle}
    Set-ADUser -identity $username -ScriptPath "global_12.vbs"


    #Configure Mailbox Properties
    Set-CasMailbox -ActiveSyncEnabled $false -PopEnabled $false -ImapEnabled $false -Identity $username

#Create H: drive
$homefolder = $username
$path = "\\corporate\proassurance\home\"
$newFolderFull = $path + $homefolder
New-Item $newFolderFull -ItemType Directory

#Set home folder permissions

$Acl = (Get-Item $newFolderFull).GetAccessControl('Access')
$AccessRule = New-Object System.Security.AccessControl.FileSystemAccessRule($Username, 'Modify','ContainerInherit,ObjectInherit', 'None', 'Allow')
$Acl.SetAccessRule($AccessRule)
Set-Acl -path $newFolderFull -AclObject $Acl

###############################################
#Output Summary
###############################################
#Create the summary file for logging purposes.
$summaryfile = $username + "_Summary.txt"
$summaryreport | New-Item ("h:\scripts\powershell\onboarding\" + $summaryfile)
#
    #Enumarte query reponse
    $OfficeInfo.StreetAddress
    $OfficeInfo.City
    $OfficeInfo.StateorProvence
    $OfficeInfo.PostalCode
    $OfficeInfo.Country
    $ouinfo.ou
Write-Host ""
Write-Host -foregroundcolor Green "User Summary"

Write-Host ""
Write-Host "Username: " $username
Write-Host "Password: " $password
Write-Host "Mailbox Creation: yes"
Write-Host "Removed unnecessary mailbox features: yes"
Write-Host "Group Memberships: " Get-ADPrincipalGroupMembership $username | select Name
Write-Host "Alias: " $username
Write-Host "Profile Login Script: " (Get-ADUser -Identity $username | select ScriptPath)
Write-Host "Home Folder Creation:" $newFolderFull
Write-Host "ADM Group: " Get-ADPrincipalGroupMembership $username | where {$_.Name -like 'ADM_BHM*'} | select name | ft -HideTableHeaders
Write-Host "Display Name: " $displayname
Write-Host "UPN: " $upn
Write-Host "Title: " $line.JobTitle
Write-Host "Extension: "
Write-Host "Department: " $line.Department 
Write-Host "Mailbox Database: " $maildatabase.MailDB
Write-Host "OU = " $ouinfo.OU
Write-Host "Address: Yes"
Write-Host ""
Write-Host "Send email to new user group"
Write-Host "Send credentials to users supervisor.  "
write-host "Make sure company field is filled out correctly."
write-host "Make sure users SIP access is correctly configured.""  MSRTCSIP-PrimaryUserAddress"
Write-Host "Make sure Official Name on extensionAttribute1 is set correctly."
Write-Host "Make sure SIP address was added to Proxyaddresses."

##################################################################
#Send Summary to file
##################################################################
 "Username: " + $username | out-file $summaryreport -Append
 "Password: " + $password | out-file $summaryreport -Append
 "Mailbox Creation: yes" | out-file $summaryreport -Append
 "Removed unnecessary mailbox features: yes" | out-file $summaryreport -Append
 "Group Memberships: " | out-file $summaryreport -Append
 Get-ADPrincipalGroupMembership $username | select Name | out-file $summaryreport -Append
 "Alias: " + $username | out-file $summaryreport -Append
 "Profile Login Script: " | out-file $summaryreport -Append
 (Get-ADUser -Identity $username | select ScriptPath)  | out-file $summaryreport -Append
 "Home Folder Creation:" + $newFolderFull | out-file $summaryreport -Append
 #$adm = Get-ADMemberOf $upn | where {$_.Name -like 'ADM_BHM*'} | select name | fw
 #"ADM Group: "  | out-file $summaryreport -Append
 #Get-ADPrincipalGroupMembership $username | where {$_.Name -like 'ADM_BHM*'} | select name | ft -HideTableHeaders | out-file $summaryreport -Append
 "Display Name: " + $displayname | out-file $summaryreport -Append
 "UPN: " + $upn | out-file $summaryreport -Append
 "Title: " + $line.JobTitle | out-file $summaryreport -Append
 "Extension: " | out-file $summaryreport -Append
 "Department: " + $line.Department  | out-file $summaryreport -Append
 "Mailbox Database: " + $maildatabase.MailDB | out-file $summaryreport -Append
 "OU = " + $ouinfo.OU | out-file $summaryreport -Append
 "Address: Yes" | out-file $summaryreport -Append
 ""
 "Send email to new user group" | out-file $summaryreport -Append
 "Send credentials to users supervisor.  " | out-file $summaryreport -Append
 "Make sure company field is filled out correctly." | out-file $summaryreport -Append
 "Make sure users SIP access is correctly configured.""  MSRTCSIP-PrimaryUserAddress" | out-file $summaryreport -Append | out-file $summaryreport -Append
 "Make sure Official Name on extensionAttribute1 is set correctly." | out-file $summaryreport -Append
 "Make sure SIP address was added to Proxyaddresses." | out-file $summaryreport -Append

Start-Sleep -s 10
      

    }
