﻿$app = Get-WmiObject -Class Win32_Product | Where-Object { 
    $_.Name -match "Java" -and {$_.Name -ne "Java 8 Update 151" }
}

$app.Uninstall()