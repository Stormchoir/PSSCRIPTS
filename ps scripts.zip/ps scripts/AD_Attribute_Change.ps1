Import-Module ActiveDirectory 
$CSVPath = "c:\test.csv"
$csvData = Import-CSV $CSVPath -delimiter "," -Header ("sAMAccountName","IPPhone")

foreach ($line in $csvData ) 
{
$accountTable = @{ 
'sAMAccountName'= $line.sAMAccountName 
'IPPhone'= $line.ipPhone 
}
}

ForEach($line in $csvData) 
{ 
$sAMAccountName = $line.sAMAccountName 
$ipphone = $line.ipPhone 
$Blank = ""

if([string]::isNullOrEmpty($sAMAccountName.description))
{ "modifying $($sAMAccountName) and adding $ipphone number " 
$SETIPPHONE = GET-ADUSER $sAMAccountName -PROPERTIES ipphone
$SETIPPHONE.ipphone = $ipphone
Set-ADUser $sAMAccountName -Add @{ipPhone=$ipphone} }
}
