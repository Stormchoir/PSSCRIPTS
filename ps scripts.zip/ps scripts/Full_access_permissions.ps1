


Get-Mailbox | Get-MailboxPermission | ?{($_.AccessRights -eq "FullAccess") -and ($_.User -like 'corporate\mmaxbauer') -and ($_.IsInherited -eq $false)} | ft Id*