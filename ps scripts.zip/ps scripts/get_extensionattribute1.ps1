Import-Module ActiveDirectory

Get-ADUser -searchbase "DC=corporate,DC=local" -Properties extensionAttribute1 -Filter 'streetaddress -notlike "Not-a-user" -and extensionAttribute1 -like "*"' | select-object name, extensionAttribute1 | export-csv c:\temp\user_name_Official.csv