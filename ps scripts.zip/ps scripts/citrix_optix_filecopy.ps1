$computers = get-content "\\corporate\proassurance\Home\gbromley\scripts\powershell\citrix_imageright_servers.txt"
$source = "\\corporate.local\applications\appdev\Optix\Prod\Optix.exe.config"
$destination = "c$\Program Files\ProAssurance Corporation\Optix"
foreach ($computer in $computers) 
{
Copy-Item $source -Destination "\\$computer\$destination"
write-host "***************************************************************"
write-host "\\$computer\$destination"
write-host "***************************************************************"
}