$farm = Get-XAFarm  #Gets the farm information
$applications = Get-XAApplication  #Gets the published applications
$servers = Get-XAServer  #Gets the XA servers in the farm

#Prepares the output
$output = "Farm: "+$farm.FarmName + "`n"
$output += "`nServers `n"
foreach($server in $servers){
   $output+=$server.ServerName + " ("+$server.CitrixEdition+" "+$server.CitrixVersion+")`n"
}

$output += "`nApplications `n"
foreach($application in $applications){
   $output+=$application.DisplayName + " ("+$application.ApplicationType+")`n"
}

echo $output