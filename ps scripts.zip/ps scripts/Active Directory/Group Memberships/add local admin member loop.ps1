﻿$DomainUser = "corporate\svc-appdeploy"
$LocalGroup = "Administrators"
$Computers   = Get-Content "h:\servers.txt"
$Domain     = "corporate.local"

foreach ($computer in $computers){
Invoke-Command -Scriptblock {net localgroup Administrators /add "$DomainUser"} -Computer "$Computer" #| out-gridview -title "LocalAdmins"Add-LocalGroupMember -Group 'Administrators' -Member ('svc-appdeploy') –Verbose

#([ADSI]"WinNT://$Computer/$LocalGroup,group").psbase.Invoke("Add",([ADSI]"WinNT://$Domain/$DomainUser").path)
}