﻿##enterprise
get-aduser -filter * -searchbase 'OU=Enterprise,DC=corporate,DC=local' -Properties EmailAddress, sn | 
    Where {$_.givenname + $_.sn + '@picagroup.com' -replace " ", "" -replace "-", "" -replace "'", "" -ne $_.EmailAddress -and 
            $_.givenname + $_.sn + '@proassurance.com' -replace " ", "" -replace "-", "" -replace "'", "" -ne $_.EmailAddress -and
            $_.givenname + $_.sn + '@medmarc.com' -replace " ", "" -replace "-", "" -replace "'", "" -ne $_.EmailAddress -and
            $_.givenname + $_.sn + '@eains.com' -replace " ", "" -replace "-", "" -replace "'", "" -ne $_.EmailAddress -and
            $_.givenname -notlike '*test*' -and $_.sn -notlike '*test*' -and $_.name -notlike '*test*' -and
            $_.emailaddress -ne $null } | 
    select givenname,sn,name,samaccountname,userprincipalname,emailaddress

##pica
get-aduser -filter * -searchbase 'OU=Employees,OU=Users,OU=PICA,DC=corporate,DC=local' -Properties EmailAddress, sn | 
    Where {$_.givenname + $_.sn + '@picagroup.com' -replace " ", "" -replace "-", "" -replace "'", "" -ne $_.EmailAddress -and 
            $_.givenname + $_.sn + '@proassurance.com' -replace " ", "" -replace "-", "" -replace "'", "" -ne $_.EmailAddress -and
            $_.givenname + $_.sn + '@medmarc.com' -replace " ", "" -replace "-", "" -replace "'", "" -ne $_.EmailAddress -and
            $_.givenname + $_.sn + '@eains.com' -replace " ", "" -replace "-", "" -replace "'", "" -ne $_.EmailAddress -and
            $_.givenname -notlike '*test*' -and $_.sn -notlike '*test*' -and $_.name -notlike '*test*' -and
            $_.emailaddress -ne $null } | 
    select givenname,sn,name,samaccountname,userprincipalname,emailaddress

##hcpl/corp    
get-aduser -filter * -searchbase 'OU=Offices Win7,OU=MAI,OU=Enterprise Admins,DC=corporate,DC=local' -Properties EmailAddress, sn | 
    Where {$_.givenname + $_.sn + '@picagroup.com' -replace " ", "" -replace "-", "" -replace "'", "" -ne $_.EmailAddress -and 
            $_.givenname + $_.sn + '@proassurance.com' -replace " ", "" -replace "-", "" -replace "'", "" -ne $_.EmailAddress -and
            $_.givenname + $_.sn + '@medmarc.com' -replace " ", "" -replace "-", "" -replace "'", "" -ne $_.EmailAddress -and
            $_.givenname + $_.sn + '@eains.com' -replace " ", "" -replace "-", "" -replace "'", "" -ne $_.EmailAddress -and
            $_.givenname -notlike '*test*' -and $_.sn -notlike '*test*' -and $_.name -notlike '*test*' -and
            $_.emailaddress -ne $null } | 
    select givenname,sn,name,samaccountname,userprincipalname,emailaddress

##hcpl/corp remote
get-aduser -filter * -searchbase 'OU=Remote Win7,OU=MAI,OU=Enterprise Admins,DC=corporate,DC=local' -Properties EmailAddress, sn | 
    Where {$_.givenname + $_.sn + '@picagroup.com' -replace " ", "" -replace "-", "" -replace "'", "" -ne $_.EmailAddress -and 
            $_.givenname + $_.sn + '@proassurance.com' -replace " ", "" -replace "-", "" -replace "'", "" -ne $_.EmailAddress -and
            $_.givenname + $_.sn + '@medmarc.com' -replace " ", "" -replace "-", "" -replace "'", "" -ne $_.EmailAddress -and
            $_.givenname + $_.sn + '@eains.com' -replace " ", "" -replace "-", "" -replace "'", "" -ne $_.EmailAddress -and
            $_.givenname -notlike '*test*' -and $_.sn -notlike '*test*' -and $_.name -notlike '*test*' -and
            $_.emailaddress -ne $null } | 
    select givenname,sn,name,samaccountname,userprincipalname,emailaddress

##medmarc    
get-aduser -filter * -searchbase 'OU=User Accounts,OU=Medmarc,DC=corporate,DC=local' -Properties EmailAddress, sn | 
    Where {$_.givenname + $_.sn + '@picagroup.com' -replace " ", "" -replace "-", "" -replace "'", "" -ne $_.EmailAddress -and 
            $_.givenname + $_.sn + '@proassurance.com' -replace " ", "" -replace "-", "" -replace "'", "" -ne $_.EmailAddress -and
            $_.givenname + $_.sn + '@medmarc.com' -replace " ", "" -replace "-", "" -replace "'", "" -ne $_.EmailAddress -and
            $_.givenname + $_.sn + '@eains.com' -replace " ", "" -replace "-", "" -replace "'", "" -ne $_.EmailAddress -and
            $_.givenname -notlike '*test*' -and $_.sn -notlike '*test*' -and $_.name -notlike '*test*' -and
            $_.emailaddress -ne $null } | 
    select givenname,sn,name,samaccountname,userprincipalname,emailaddress
