﻿#Take data from user input to determine office and department.
cls
# we take data from 3 CSV files to build overall profile for users to import into AD

$OfficeLocationCSV = Import-Csv "\\corporate\birmingham\information systems\obdata\addresses.csv"
$ADOUCSV = Import-Csv "\\corporate\birmingham\Information Systems\OBData\ADOUCSV.csv"
$ADGroupsCSV = Import-Csv "\\corporate\birmingham\Information Systems\OBData\ADGROUPS.csv"

#change this to a location where you'll store user data.
$CSVData = Import-Csv "c:\users\gbromley\documents\poshtestcsv.csv"

#Start foreach loop
ForEach ( $Line in $CSVData ) {
    
    #Pull Office Info from refrence sheet
    $OfficeInfo = $OfficeLocationCSV | Where-Object { $_.office -eq $Line.office }
    #$OfficeInfo | GM
    #$OfficeInfo
    #Pull OU Info from reference sheet
    $ouinfo = $adoucsv | Where-Object { ($_.office -eq $Line.Office) -and ($_.Department -eq $Line.Department)}
    #Enumarte query reponse
    $OfficeInfo.StreetAddress
    $OfficeInfo.City
    $OfficeInfo.StateorProvence
    $OfficeInfo.PostalCode
    $OfficeInfo.Country
    $ouinfo.ou

    #Pull group memberships from reference sheet
    $groupinfo = $adgroupscsv | Where-Object { ($_.Office -eq $Line.Office) -and ($_.department -eq $Line.Department) -and ($_.jobtitle -eq $Line.jobtitle) }

    

    }


    #Add attributes to AD user account
#Set-ADUser -Identity $upn StreetAddress $officeinfo.StreetAddress
#Set-ADUser -Identity $upn City $OfficeInfo.city
#Set-ADUser -Identity $upn State $officeinfo.StateorProvence
#Set-ADUser -Identity $upn PostalCode $officeinfo.PostalCode
#Set-ADUser -Identity $upn Country $officeinfo.Country

