array$ = get-content "h:\scripts\powershell\xenservers.txt"
foreach ($computer in $array)
Get-WmiObject -ComputerName $computer win32_service -filter "name='proassurancefileupdate'" | format-table name, startname, startmode



