#*FileName: XenApp_Published_App_Report.ps1
#*=========================================
#*Created 07/06/2012
#*Author: Shaun Ritchie
#*www.shaunritchie.co.uk
#*
#*
#*
#*=========================================
#*
#*
#*
#*=========================================
#* SCRIPT BODY
#*=========================================
# Load XenApp cmdlets
 
add-pssnapin Citrix.* -erroraction silentlycontinue
# Create variables
 
$outpath = [environment]::getfolderpath("mydocuments") + "\XenApp_Published_App_Report.csv"
$xaapplist = get-xaapplication
$appreport=foreach ($application in $xaapplist) {
 
     get-xaapplicationreport -BrowserName $application.BrowserName
 
}
 
# pipe appreport variable and select required objects for output
$appreport |
select-object BrowserName,
applicationtype,
enabled,
@{n='accounts'; e={$_.accounts}},
@{n='servernames'; e={$_.servernames}},
@{n='workergroupnames'; e={$_.workergroupnames}},
folderpath,
commandlineexecutable,
clientfolder,
startmenufolder,
encryptionlevel,
encryptionrequired,
windowtype,
colordepth |
 
#Export results to a CSV
 
export-csv $outpath