$GetUserInput = 
{
Switch (Read-Host 'Enter One or Two')
 {
   'One' {Write-Output 'User entered One'}
   'Two' {Write-Output 'User entered Two'}
   default {
            Write-host "Invalid input.  Please enter only 'One' or 'Two'" -ForegroundColor Yellow
            .$GetUserInput
            }
 }
}