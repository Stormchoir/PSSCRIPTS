$server_names = get-content "citrix servers.txt"
foreach ($server in $server_names)
{copy-Item "\\pro-xen64-m01\c$\PBNetControls\ClaimsLetters\*" -Destination "\\$server\c$\PBNetControls\ClaimsLetters" -Recurse}