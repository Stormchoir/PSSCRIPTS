$Source_Group = "CN=ImageRight Users - Application Access, OU=Delete After Upgrade, OU=ImageRight Systems, OU=Applications,OU=MAI,OU=Enterprise Admins,DC=corporate,DC=local" 
$Destination_Group = "CN=ImageRight5,OU=ImageRight Systems, OU=Applications, OU=MAI, OU=Enterprise Admins,DC=corporate,DC=local" 
 
$Target = Get-ADGroupMember -Identity $Source_Group 
foreach ($Person in $Target) { 
    Add-ADGroupMember -Identity $Destination_Group -Members $Person.distinguishedname 
}