Import-Module ActiveDirectory
$SearchBase = "OU=Users Win7,OU=Offices Win7,OU=MAI,OU=Enterprise Admins,DC=Corporate,DC=local"

Get-ADUser -searchbase $searchbase -Filter * -Properties * |
 Select -Property samaccountname | 
 Export-CSV "C:\\AllADUsers.csv" -NoTypeInformation -Encoding UTF8
