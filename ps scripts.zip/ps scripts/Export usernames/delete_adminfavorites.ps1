ForEach ($user in Get-Content "usernames.txt")
{
remove-item -path "\\corporate\appdata\citrix\profiles_2013\$user\UPM_Profile\Favorites\Admin Favorites" -recurse 
}