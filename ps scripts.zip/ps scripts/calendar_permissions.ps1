

Set-MailboxFolderPermission boothbannerentity:\Calendar -User cmoseson -AccessRights Reviewer

