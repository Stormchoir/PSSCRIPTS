#Choose OU for AD account

Write-Host ""
Write-Host -foregroundcolor Green "Please Pick an OU for User Account"
Write-Host ""
Write-Host "1 - OU1"
Write-Host "2 - OU2"
Write-Host "3 - OU3"
Write-Host "4 - OU4"
Write-Host ""
$ounumber = read-host -prompt "Please Choose a number"