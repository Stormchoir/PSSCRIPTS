﻿#created by Mark Billington
#Script designed to easily create new mailboxes and user accounts. hurrah!
#NO VALIDATION IS CURRENTLY INCORPORATED, SCRIPT WILL FAIL IF USER ALREADY EXISTS

#Prompt for Username and Password
$firstname = read-host -prompt "Enter First Name"
$initial = read-host -prompt "Enter First Initial"
$lastname = read-host -prompt "Enter Last Name"
$trust =  read-host -prompt "proassurance.com"
$name=$lastname+", "+$firstname
$username= $initial+$lastname.tolower()
$displayname=$lastname+", "+$firstname
$password = read-host -assecurestring -prompt "Please enter a Password"
$logonscript = read-host "Enter the logon script to be used"


# Determine UPN suffix
if ($trust -eq "proassurance.com") { 
$domain = "@proassurance.com"
$attrib = " "
}


$upn=$username+$domain

#Pick Mailbox Databse and write mailbox databse vaule to variable
Write-Host ""
Write-Host -foregroundcolor Green "Please Pick a Mailbox Database"
Write-Host ""
Write-Host "0 - pradb01"
Write-Host ""
$mailnumber = read-host -prompt "Please Choose a number"

if ($mailnumber -eq "0") { 
$maildatabase = "pradb01"
}

#Choose OU for AD account

Write-Host ""
Write-Host -foregroundcolor Green "Select the proper Office/Department."
Write-Host ""
Write-Host "1 - Bham Underwriting"
Write-Host "2 - Bham Accounting"
Write-Host "3 - Bham Actuary"
Write-Host "4 - Bham Administration"
Write-Host ""
$ounumber = read-host -prompt "Please Choose a number"

if ($ounumber -eq "1") { 
$ou = "corporate.local/Enterprise Admins/MAI/Offices XP/Users XP/Birmingham/Underwriting"
}
if ($ounumber -eq "2") { 
$ou = "corporate.local/Enterprise Admins/MAI/Offices XP/Users XP/Birmingham/Accounting"
}
if ($ounumber -eq "3") { 
$ou = "corporate.local/Enterprise Admins/MAI/Offices XP/Users XP/Birmingham/Actuary"
}
if ($ounumber -eq "4") { 
$ou = "corporate.local/Enterprise Admins/MAI/Offices XP/Users XP/Birmingham/Administration"
}

#Create Mailbox and AD Account

New-Mailbox -name $name -userprincipalname $upn -Alias $username -OrganizationalUnit $ou -FirstName $firstname -LastName $LastName -Password $password -ResetPasswordOnNextLogon $true -Database $maildatabase -DisplayName $displayname
Write-Host ""
Write-Host -foregroundcolor Blue "Mailbox Created"
Write-Host ""
Start-Sleep -s 10
Connect-QADService -Service pro-bhm-dc1.corporate.local
Set-QADUser -Identity $upn -LogonScript $logonscript
Write-Host ""
Write-Host -foregroundcolor Blue "Logon Script set as: " $logonscript

#if ($ounumber -eq "1") { 
#Add-QADGroupMember -Identity "Domain1 Common Security Group" -Member $username
#}
#if ($ounumber -eq "1") { 
#Add-QADGroupMember -Identity "OU1 common security group" -Member $username
#}

#Configure Mailbox Properties
Set-CasMailbox -ActiveSyncEnabled $false -PopEnabled $false -ImapEnabled $false -Identity $username

#Output Summery
Write-Host ""
Write-Host -foregroundcolor Green "User Summery"
Write-Host ""
Write-Host "Username= " $username
Write-Host "Alias = " $username
Write-Host "Display Name = " $displayname
Write-Host "UPN = " $upn
Write-Host "Mailbox Database = " $maildatabase
Write-Host "OU = " $ou
Write-Host ""
Start-Sleep -s 60
