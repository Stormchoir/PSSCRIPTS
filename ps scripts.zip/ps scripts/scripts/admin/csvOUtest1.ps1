$ouFile = "\\corporate\birmingham\information systems\OBData\ou.csv"
$department = "Birmingham Claims"
Import-Csv $ouFile|? Departmentfull -eq $department | Where-Object {
    
    {
        #Write-Host $property.Name, $property.Value
		write-host $ouFile.departmentfull
		write-host $ouFile.ou
    } 
}