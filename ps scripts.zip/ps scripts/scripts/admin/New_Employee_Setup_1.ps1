Add-Pssnapin *Exchange
Import-Module ActiveDirectory

#Prompt for Username and Password
$firstname = read-host -prompt "Enter First Name"
$initial = $firstname.Substring(0,1).tolower()
$lastname = read-host -prompt "Enter Last Name"
$trust =  read-host -prompt "Will this user be in the corporate domain? Type yes."
$name=$lastname+", "+$firstname
$username= $initial+$lastname.tolower()
$displayname=$lastname+", "+$firstname
$officialname = read-host -prompt "What is the users official name?"
$title = read-host -prompt "What is the user's title?"
$password = read-host -assecurestring -prompt "Please enter a Password"
$logonscript = read-host "Enter the logon script to be used"
$startdate = read-host "Please enter the start date. (i.e. 04/18/2001)"
$department = read-host "Enter the full department name.  eg. Birmingham Claims"
$office = read-host "Please enter the office for the new user."
$laptop = read-host "Will this user be given a laptop?"

# Determine UPN suffix
if ($trust -eq "yes") { 
$domain = "@proassurance.com"
$attrib = " "
}

$upn=$username+$domain

#Pick Mailbox Databse and write mailbox databse vaule to variable
Write-Host ""
Write-Host -foregroundcolor Green "Please Pick a Mailbox Database"
Write-Host ""
Write-Host "1 - DB01 - Corporate/HCPL/PICA except Okemos"
Write-Host ""
Write-Host "2 - DB02 - Medmarc & Eastern"
Write-Host ""
Write-Host "3 - DB03 - Okemos"
Write-Host ""
Write-Host "4 - DB04 - Okemos"
Write-Host ""
$mailnumber = read-host -prompt "Please Choose a number"

if ($mailnumber -eq "1") { 
$maildatabase = "db01"
}

if ($mailnumber -eq "2") { 
$maildatabase = "db02"
}

if ($mailnumber -eq "3") { 
$maildatabase = "db03"
}

if ($mailnumber -eq "4") { 
$maildatabase = "db04"
}

#OU BLock
$ouFile = "\\corporate\birmingham\information systems\OBData\ou.csv"
Import-Csv $ouFile|? Departmentfull -eq $department | Where-Object {
    
    {
        #Write-Host $property.Name, $property.Value
		write-host -foregroundcolor Green $ouFile.departmentfull
		write-host -foregroundcolor Green $ouFile.ou
    } 
}



New-Mailbox -Name $name -UserPrincipalName $upn -Password (ConvertTo-SecureString -String $password -AsPlainText -Force) -FirstName $firstname -LastName $lastname -DisplayName $lastname+", "+$firstname -OrganizationalUnit $oufile.ou

#Address BLock
# we take data from 3 CSV files to build overall profile for users to import into AD

$OfficeLocationCSV = Import-Csv "\\corporate\birmingham\information systems\obdata\addresses.csv"
#$ADOUCSV = Import-Csv "Path to CSV file"
#$ADGroupsCSV = Import-Csv "Path to CSV file"

$CSVData = Import-Csv "c:\users\gbromley\documents\poshtestcsv.csv"

#Start foreach loop
ForEach ( $Line in $CSVData ) {
    
    #Pull Office Info from refrence sheet
    $OfficeInfo = $OfficeLocationCSV | Where-Object { $_.office -eq $Line.office }
    #$OfficeInfo | GM
    #$OfficeInfo
    #Enumarte query reponse
    $OfficeInfo.StreetAddress
    $OfficeInfo.City
    $OfficeInfo.StateorProvence
    $OfficeInfo.PostalCode
    $OfficeInfo.Country
    }

#Set AD Property Information
Set-ADUser -Identity $username -scriptpath $logonscript
Set-ADUser -Identity $username -replace @{"msRTCSIP-PrimaryUserAddress" = 'sip:' + $username + '@proassurance.com'}
Set-ADUser -Identity $username -add @{"proxyAddresses" = 'sip:' + $username + '@proassurance.com'}
Set-ADUser -Identity $username -replace @{"empDateOfHire"=get-date $startdate" 10:01:01 AM"}
Set-ADUser -Identity $username -replace @{"extensionAttribute1"=$officialname}
Write-Host ""
Write-Host -foregroundcolor Blue "Logon Script set as: " $logonscript
Write-Host -foregroundcolor Green "Official name set as: " $officialname