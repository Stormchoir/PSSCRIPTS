$addressFile = "\\corporate\birmingham\information systems\OBData\addresses.csv"
$sr = New-Object System.IO.StreamReader($addressFile)
$headerLine = $sr.ReadLine(); #skips the header line
#Write-Host($headerline)
$line
while (($line = $sr.ReadLine()) -ne $null) {
$row = $line.split(",")
if($row.Count -eq 0)
{
      break
}
$Office = $row[0]
Write-Host($Office)
$Address =  $row[1]
Write-Host($Address)
$City = $row[2]
Write-Host($City)
$State = $row[3]
Write-Host($State)
$zipcode = $row[4]
Write-Host($zipcode)
$Country = $row[5]
Write-Host($Country)
}
