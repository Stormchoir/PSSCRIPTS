﻿#created by Mark Billington
#Script designed to easily create new mailboxes and user accounts. hurrah!
#NO VALIDATION IS CURRENTLY INCORPORATED, SCRIPT WILL FAIL IF USER ALREADY EXISTS

#Prompt for Username and Password
$firstname = read-host -prompt "Enter First Name"
$initial = read-host -prompt "Enter First Initial"
$lastname = read-host -prompt "Enter Last Name"
$trust =  read-host -prompt "Will this user be in the corporate domain? Type yes."
$name=$lastname+", "+$firstname
$username= $initial+$lastname.tolower()
$displayname=$lastname+", "+$firstname
$title = read-host -prompt "What is the user's title?"
$password = read-host -assecurestring -prompt "Please enter a Password"
$logonscript = read-host "Enter the logon script to be used"
$department = read-host "Enter the department name."

# Determine UPN suffix
if ($trust -eq "yes") { 
$domain = "@proassurance.com"
$attrib = " "
}


$upn=$username+$domain

#Pick Mailbox Databse and write mailbox databse vaule to variable
Write-Host ""
Write-Host -foregroundcolor Green "Please Pick a Mailbox Database"
Write-Host ""
Write-Host "0 - pradb01"
Write-Host ""
$mailnumber = read-host -prompt "Please Choose a number"

if ($mailnumber -eq "0") { 
$maildatabase = "pradb01"
}

#Choose department for AD account

Write-Host ""
Write-Host -foregroundcolor Green "Select the proper department in Birmingham for the new user."
Write-Host ""
Write-Host "1  - Bham Accounting"
Write-Host "2  - Bham Actuary"
Write-Host "3  - Bham Administration"
Write-Host "4  - Bham Agency"
Write-Host "5  - Bham Claims"
Write-Host "6  - Bham Communications"
Write-Host "7  - Bham Company Services"
Write-Host "8  - Bham Human Resources"
Write-Host "9  - Bham Information Systems"
Write-Host "10 - Bham Information Systems - Developer"
Write-Host "11 - Bham Investments"
Write-Host "12 - Bham Legal"
Write-Host "13 - Bham OBGYN Risk Alliance"
Write-Host "14 - Bham Reception"
Write-Host "15 - Bham Red Mountain"
Write-Host "16 - Bham Risk Management"
Write-Host "17 - Bham Sales and Marketing"
Write-Host "18 - Bham Underwriting"
Write-Host "19 - Nonhuman account"
Write-Host ""
$ounumber = read-host -prompt "Please Choose a number"

if ($ounumber -eq "1") { 
$ou = "corporate.local/Enterprise Admins/MAI/Offices XP/Users XP/Birmingham/Accounting"
}
if ($ounumber -eq "2") { 
$ou = "corporate.local/Enterprise Admins/MAI/Offices XP/Users XP/Birmingham/Actuary"
}
if ($ounumber -eq "3") { 
$ou = "corporate.local/Enterprise Admins/MAI/Offices XP/Users XP/Birmingham/Administration"
}
if ($ounumber -eq "4") { 
$ou = "corporate.local/Enterprise Admins/MAI/Offices XP/Users XP/Birmingham/Agency"
}
if ($ounumber -eq "5") { 
$ou = "corporate.local/Enterprise Admins/MAI/Offices XP/Users XP/Birmingham/Claims"
}
if ($ounumber -eq "6") { 
$ou = "corporate.local/Enterprise Admins/MAI/Offices XP/Users XP/Birmingham/Communications"
}
if ($ounumber -eq "7") { 
$ou = "corporate.local/Enterprise Admins/MAI/Offices XP/Users XP/Birmingham/Company Services"
}
if ($ounumber -eq "8") { 
$ou = "corporate.local/Enterprise Admins/MAI/Offices XP/Users XP/Birmingham/Human Resources"
}
if ($ounumber -eq "9") { 
$ou = "corporate.local/Enterprise Admins/MAI/Offices XP/Users XP/Birmingham/Information Systems"
}
if ($ounumber -eq "10") { 
$ou = "corporate.local/Enterprise Admins/MAI/Offices XP/Users XP/Birmingham/Information Systems"
}
if ($ounumber -eq "11") { 
$ou = "corporate.local/Enterprise Admins/MAI/Offices XP/Users XP/Birmingham/Investments"
}
if ($ounumber -eq "12") { 
$ou = "corporate.local/Enterprise Admins/MAI/Offices XP/Users XP/Birmingham/Legal"
}
if ($ounumber -eq "13") { 
$ou = "corporate.local/Enterprise Admins/MAI/Offices XP/Users XP/Birmingham/OBGYN Risk Alliance"
}
if ($ounumber -eq "14") { 
$ou = "corporate.local/Enterprise Admins/MAI/Offices XP/Users XP/Birmingham/Reception"
}
if ($ounumber -eq "15") { 
$ou = "corporate.local/Enterprise Admins/MAI/Offices XP/Users XP/Birmingham/Red Mountain"
}
if ($ounumber -eq "16") { 
$ou = "corporate.local/Enterprise Admins/MAI/Offices XP/Users XP/Birmingham/Risk Management"
}
if ($ounumber -eq "17") { 
$ou = "corporate.local/Enterprise Admins/MAI/Offices XP/Users XP/Birmingham/Sales and Marketing"
}
if ($ounumber -eq "18") { 
$ou = "corporate.local/Enterprise Admins/MAI/Offices XP/Users XP/Birmingham/Underwriting"
}
if ($ounumber -eq "19") { 
$ou = "corporate.local/Recipients"
}

#Create Mailbox and AD Account

New-Mailbox -name $name -userprincipalname $upn -Alias $username -OrganizationalUnit $ou -FirstName $firstname -LastName $LastName -Password $password -ResetPasswordOnNextLogon $true -Database $maildatabase -DisplayName $displayname
Write-Host ""
Write-Host -foregroundcolor Blue "Mailbox Created"
Write-Host ""
Start-Sleep -s 10

#Set AD Property Information
Connect-QADService -Service pro-bhm-dc1.corporate.local
Set-QADUser -Identity $upn -LogonScript $logonscript
Write-Host ""
Write-Host -foregroundcolor Blue "Logon Script set as: " $logonscript
Set-QADUser -Identity $username -Add @{"msRTCSIP-PrimaryUserAddress" = 'sip:' + $username + '@proassurance.com'}
Set-QADUser -Identity $upn -StreetAddress "100 Brookwood Place, Suite 500
Birmingham, AL 35209"
Set-QADUser -Identity $upn -PostOfficeBox "P.O. Box 590009"
Set-QADUser -Identity $upn -City Birmingham
Set-QADUser -Identity $upn -StateOrProvince AL
Set-QADUser -Identity $upn -Office Birmingham
Set-QADUser -Identity $upn -co "United States"
Set-QADUser -Identity $upn -PostalCode 35209
Set-QADUser -Identity $upn -Title $title
Set-QADUser -Identity $upn -Company "ProAssurance Corporation"
Set-QADUser -Identity $upn -Department $department

if ($ounumber -eq "1") { 
Add-QADGroupMember -Identity ADM_BHM_ACCOUNTING -Member $username
Add-QADGroupMember -Identity "Finance Accounting" -Member $username
Add-QADGroupMember -Identity "FW - HTTP/HTTPS Access" -Member $username
}
if ($ounumber -eq "2") { 
Add-QADGroupMember -Identity ADM_BHM_ACTUARY -Member $username
Add-QADGroupMember -Identity Actuarial -Member $username
Add-QADGroupMember -Identity "FW - HTTP/HTTPS Access" -Member $username
}
if ($ounumber -eq "3") { 
Add-QADGroupMember -Identity ADM_BHM_ADMINISTRATION -Member $username
Add-QADGroupMember -Identity Administration -Member $username
Add-QADGroupMember -Identity "FW - HTTP/HTTPS Access" -Member $username
}
if ($ounumber -eq "4") { 
Add-QADGroupMember -Identity ADM_BHM_AGENCY -Member $username
Add-QADGroupMember -Identity Agency -Member $username
Add-QADGroupMember -Identity "FW - HTTP/HTTPS Access" -Member $username
}
if ($ounumber -eq "5") { 
Add-QADGroupMember -Identity ADM_BHM_CLAIMS -Member $username
Add-QADGroupMember -Identity "Birmingham Claims/Litigation" -Member $username
Add-QADGroupMember -Identity "FW - HTTP/HTTPS Access" -Member $username
}
if ($ounumber -eq "6") { 
Add-QADGroupMember -Identity ADM_BHM_COMMUNICATIONS -Member $username
Add-QADGroupMember -Identity "Loss Prevention Services" -Member $username
Add-QADGroupMember -Identity "FW - HTTP/HTTPS Access" -Member $username
Add-QADGroupMember -Identity "Corporate Communications" -Member $username
}
if ($ounumber -eq "7") { 
Add-QADGroupMember -Identity "ADM_BHM_COMPANYSERVICES" -Member $username
Add-QADGroupMember -Identity "Birmingham Company Services" -Member $username
Add-QADGroupMember -Identity "FW HTTP/HTTPS Access" -Member $username
Add-QADGroupMember -Identity "Company Services" -Member $username
}
if ($ounumber -eq "8") { 
Add-QADGroupMember -Identity ADM_BHM_PERSONNEL -Member $username
Add-QADGroupMember -Identity Personnel -Member $username
Add-QADGroupMember -Identity "FW - HTTP/HTTPS Access" -Member $username
}
if ($ounumber -eq "9") { 
Add-QADGroupMember -Identity ADM_BHM_INFORMATIONSYSTEMS -Member $username
Add-QADGroupMember -Identity "Information Systems" -Member $username
Add-QADGroupMember -Identity "FW - HTTP/HTTPS Access" -Member $username
}
if ($ounumber -eq "10") { 
Add-QADGroupMember -Identity ADM_BHM_INFORMATIONSYSTEMS -Member $username
Add-QADGroupMember -Identity "Information Systems" -Member $username
Add-QADGroupMember -Identity "FW - HTTP/HTTPS Access" -Member $username
Add-QADGroupMember -Identity "Oasis Pre-Production" -Member $username
Add-QADGroupMember -Identity "Oasis Model" -Member $username
Add-QADGroupMember -Identity "Track-It! Technicians" -Member $username
}
if ($ounumber -eq "11") { 
Add-QADGroupMember -Identity ADM_BHM_INVESTMENTS -Member $username
Add-QADGroupMember -Identity "FW - HTTP/HTTPS Access" -Member $username
Add-QADGroupMember -Identity Investments -Member $username
}
if ($ounumber -eq "12") { 
Add-QADGroupMember -Identity ADM_BHM_LEGAL -Member $username
Add-QADGroupMember -Identity Legal -Member $username
Add-QADGroupMember -Identity "FW - HTTP/HTTPS Access" -Member $username
}
if ($ounumber -eq "13") { 
Add-QADGroupMember -Identity ADM_BHM_OBGYNRISKALLIANCE -Member $username
Add-QADGroupMember -Identity "OBGYN Risk Alliance" -Member $username
Add-QADGroupMember -Identity "FW - HTTP/HTTPS Access" -Member $username
}
if ($ounumber -eq "14") { 
Add-QADGroupMember -Identity ADM_BHM_UNDERWRITING -Member $username
Add-QADGroupMember -Identity "Birmingham Underwriting" -Member $username
Add-QADGroupMember -Identity "FW - HTTP/HTTPS Access" -Member $username
Add-QADGroupMember -Identity "Receptionists - Company-Wide" -Member $username
Add-QADGroupMember -Identity Underwriting -Member $username
}
if ($ounumber -eq "15") { 
Add-QADGroupMember -Identity ADM_BHM_REDMOUNTAIN -Member $username
Add-QADGroupMember -Identity "Birmingham Underwriting" -Member $username
Add-QADGroupMember -Identity "FW - HTTP/HTTPS Access" -Member $username
}
if ($ounumber -eq "16") { 
Add-QADGroupMember -Identity ADM_BHM_RISKMANAGEMENT -Member $username
Add-QADGroupMember -Identity "Risk Management" -Member $username
Add-QADGroupMember -Identity "FW - HTTP/HTTPS Access" -Member $username
Add-QADGroupMember -Identity "Risk Management - Southern Region" -Member $username
}
if ($ounumber -eq "17") { 
Add-QADGroupMember -Identity ADM_BHM_BUSINESSDEVELOPMENT -Member $username
Add-QADGroupMember -Identity "Birmingham Office" -Member $username
Add-QADGroupMember -Identity "FW - HTTP/HTTPS Access" -Member $username
}
if ($ounumber -eq "18") { 
Add-QADGroupMember -Identity ADM_BHM_UNDERWRITING -Member $username
Add-QADGroupMember -Identity "Birmingham Underwriting" -Member $username
Add-QADGroupMember -Identity "FW - HTTP/HTTPS Access" -Member $username
Add-QADGroupMember -Identity Underwriting -Member $username
}







#Configure Mailbox Properties
Set-CasMailbox -ActiveSyncEnabled $false -PopEnabled $false -ImapEnabled $false -Identity $username

#Output Summery
Write-Host ""
Write-Host -foregroundcolor Green "User Summery"
Write-Host ""
Write-Host "Username= " $username
Write-Host "Alias = " $username
Write-Host "Display Name = " $displayname
Write-Host "UPN = " $upn
Write-Host "Title = " $title
Write-Host "Department = " $department 
Write-Host "Mailbox Database = " $maildatabase
Write-Host "OU = " $ou
Write-Host ""
Start-Sleep -s 60
