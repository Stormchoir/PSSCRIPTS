function manage-server {
    param ()
        if ($args.count -eq 0)  {
            do {
               $compname = Read-Host "Which server would you like to connect to?"
            } until ($compname -ne $null)
        } else {
        $Compname = $args[0]
        }
        if ($args[1] -eq $null) {
            do {
                $task = read-host "Which task would you like to perform? [Manage/Event/Services]"
            } until (($task -match "manage") -OR ($task -match "event") -OR ($task -match "services"))
        } else {
        $task = $args[1]
        }
 
    switch ($task) {
        Manage   {compmgmt.msc /computer:$compname}
        Event    {eventvwr.msc /computer:$compname}
        Services {services.msc /computer:$compname}
    }   
}