$Firstname="Greg"
$Lastname="Testing"
$Username="gtesting"
$LegalName=$LastName+", "+$FirstName
set-aduser -identity $username -Add @{extensionAttribute1 = $LegalName}
