$share = Get-WmiObject Win32_Share `
-List -ComputerName "pro-xen64-a03"
$share.create("C:\Oasis Distribution", `
"Oasis Distribution", 0)
