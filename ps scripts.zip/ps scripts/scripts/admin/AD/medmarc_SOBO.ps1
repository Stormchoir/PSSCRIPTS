Add-Pssnapin Microsoft.Exchange.Management.PowerShell.E2010
$user = read-host -prompt "Which user needs Send on Behalf Permission?"
$mailbox = read-host -prompt "Which mailbox would you like to grant this permission?"
Get-Mailbox $mailbox | set-mailbox -GrantSendOnBehalfto @{Add="$user"}
Write-Host ""
Write-Host $user "now has Send on Behalf Of access to the "$mailbox "mailbox." 
