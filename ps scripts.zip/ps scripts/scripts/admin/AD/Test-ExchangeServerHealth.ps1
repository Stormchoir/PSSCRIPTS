﻿#requires -version 2
<#
.SYNOPSIS
Test-ExchangeServerHealth.ps1 - Exchange Server 2010 Health Check Script.

.DESCRIPTION 
Performs a series of health checks on the specified Exchange servers
and outputs the results to screen, and optionally to log file, HTML report,
and HTML email.

Use the ignorelist.txt file to specify any servers you want the script to
ignore (eg test/dev servers).

.OUTPUTS
Results are output to screen, as well as optional log file, HTML report, and HTML email

.PARAMETER server
Perform a health check of a single server

.PARAMETER reportmode
Set to $true to generate a HTML report. A default file name is used if none is specified.

.PARAMETER reportfile
Allows you to specify a different HTML report file name than the default. Implies -reportmode:$true

.PARAMETER sendemail
Sends the HTML report via email using the SMTP configuration within the script. Implies -reportmode:$true

.EXAMPLE
.\Test-ExchangeServerHealth.ps1
Checks all servers in the organization and outputs the results to the shell window.

.EXAMPLE
.\Test-ExchangeServerHealth.ps1 -server HO-EX2010-MB1
Checks the server HO-EX2010-MB1 and outputs the results to the shell window.

.EXAMPLE
.\Test-ExchangeServerHealth.ps1 -reportmode $true -sendemail $true
Checks all servers in the organization, outputs the results to the shell window, a HTML report, and
emails the HTML report to the address configured in the script.

.LINK
http://exchangeserverpro.com/powershell-script-health-check-report-exchange-2010

.NOTES
Written By: Paul Cunningham
Website:	http://exchangeserverpro.com
Twitter:	http://twitter.com/exchservpro

Change Log
V1.0, 5/07/2012 - Initial version
V1.1, 5/08/2012 - Minor bug fixes and removed Edge Tranport checks
#>


param (
	[Parameter( Mandatory=$false)]
	[string]$server,
	
	[Parameter( Mandatory=$false)]
	[bool]$reportmode=$false,
	
	[Parameter( Mandatory=$false)]
	[string]$reportfile="exchangeserverhealth.html",
	
	[Parameter( Mandatory=$false)]
	[bool]$sendemail=$false
	)

#...................................
# Initialize
#...................................

Write-Host "Initializing..."

#Add Exchange 2010 snapin
Add-PSSnapin Microsoft.Exchange.Management.PowerShell.E2010 -ErrorAction SilentlyContinue
#. $env:ExchangeInstallPath\bin\RemoteExchange.ps1 | Out-Null
#Connect-ExchangeServer -auto | Out-Null


#Set recipient scope
if (!(Get-ADServerSettings).ViewEntireForest)
{
	Set-ADServerSettings -ViewEntireForest $true -WarningAction SilentlyContinue
}


#...................................
# Variables
#...................................

$now = Get-Date											#Used for timestamps
$date = $now.ToShortDateString()						#Short date format for email message subject
[array]$exchangeservers = @()							#Array for the Exchange server or servers to check
[int]$transportqueuehigh = 100							#Change this to set transport queue high threshold
[int]$transportqueuewarn = 80									#Change this to set transport queue warning threshold
$mapitimeout = 10										#Timeout for each MAPI connectivity test, in seconds
$pass = "Green"
$warn = "Yellow"
$fail = "Red"
$ip = $null
[array]$summaryreport = @()
[array]$report = @()


#...................................
# Email Settings
#...................................

$smtpServer = "mail.corporate.local"
$smtpTo = "jbevan@proassurance.com"
$smtpFrom = "exchangehealthcheck@proassurance.com"
$messagesubject = "Exchange Server Health Check - $date"


#...................................
# Error/Warning Strings
#...................................

$string0 = "Server is not an Exchange server. "
$string1 = "Server is not reachable by ping. "
$string3 = "------ Checking"
$string4 = "Could not test service health. "
$string5 = "Required services not running. "
$string6 = "Could not check queue. "
$string7 = "Public Folder database not mounted. "
$string8 = "Skipping Edge Transport server. "
$string9 = "Mailbox databases not mounted. "
$string10 = "MAPI tests failed. "
$string11 = "Mail flow test failed. "
$string12 = "No Exchange Server 2003 checks performed. "
$string13 = "Server not found in DNS. "


#...................................
# Script
#...................................

#Check if a single server was specified
if ($server)
{
	#Run for single specified server
	try
	{
		$exchangeservers = Get-ExchangeServer $server -ErrorAction Stop
	}
	catch
	{
		#Couldn't find Exchange server of that name
		Write-Warning $_.Exception.Message
		
		#Exit because single server was specified and couldn't be found in the organization
		EXIT
	}
}
else
{
	#This is the list of server names to never alert for
	$ignorelist = @(Get-Content C:\Users\jbevan\Downloads\Test-ExchangeServerHealth1\ignorelist.txt)

	$tmpservers = @(Get-ExchangeServer)
	
	#Remove the servers that are ignored from the list of servers to check
	foreach ($tmpserver in $tmpservers)
	{
		if (!($ignorelist -icontains $tmpserver.name))
		{
			$exchangeservers = $exchangeservers += $tmpserver
		}
	}
}

#Begin the health checks
foreach ($server in $exchangeservers)
{

	Write-Host -ForegroundColor White "$string3 $server"

	#Find out some details about the server
	try
	{
		$roles = Get-ExchangeServer $server -ErrorAction Stop
	}
	catch
	{
		Write-Warning $_.Exception.Message
		$roles = $null
	}

	if ($roles -eq $null )
	{
		#Server is not an Exchange server
		Write-Host -ForegroundColor $warn $string0
	}
	elseif ( $roles.IsEdgeServer )
	{
		Write-Host -ForegroundColor White $string8
	}
	else
	{
		#Server is an Exchange server, continue the health check

		#Custom object properties
		$serverObj = New-Object PSObject
		$serverObj | Add-Member NoteProperty -Name "Server" -Value $server
		$serverObj | Add-Member NoteProperty -Name "Site" -Value $server.site.name
		$serverObj | Add-Member NoteProperty -Name "DNS" -Value $null
		$serverObj | Add-Member NoteProperty -Name "Ping" -Value $null
		$serverObj | Add-Member NoteProperty -Name "Uptime (hrs)" -Value $null
		$serverObj | Add-Member NoteProperty -Name "Version" -Value $null
		$serverObj | Add-Member NoteProperty -Name "Roles" -Value $null
		$serverObj | Add-Member NoteProperty -Name "CA Services" -Value "n/a"
		$serverObj | Add-Member NoteProperty -Name "HT Services" -Value "n/a"
		$serverObj | Add-Member NoteProperty -Name "MB Services" -Value "n/a"
		$serverObj | Add-Member NoteProperty -Name "UM Services" -Value "n/a"
		$serverObj | Add-Member NoteProperty -Name "Transport Queue" -Value "n/a"
		$serverObj | Add-Member NoteProperty -Name "PF DBs Mounted" -Value "n/a"
		$serverObj | Add-Member NoteProperty -Name "MB DBs Mounted" -Value "n/a"
		$serverObj | Add-Member NoteProperty -Name "Mail Flow Test" -Value "n/a"
		$serverObj | Add-Member NoteProperty -Name "MAPI Test" -Value "n/a"
		$serverObj | Add-Member NoteProperty -Name "Error Details" -Value ""
		$serverObj | Add-Member NoteProperty -Name "Warning Details" -Value ""


		#Check server name resolves in DNS
		Write-Host "DNS Check: " -NoNewline;
		try 
		{
			$ip = [System.Net.Dns]::GetHostByName($server).AddressList | Select-Object IPAddressToString -ExpandProperty IPAddressToString
		}
		catch
		{
			Write-Host -ForegroundColor $warn $_.Exception.Message
			$ip = $null
		}
		finally	{}

		if ( $ip -ne $null )
		{

			Write-Host -ForegroundColor $pass "Pass"
			$serverObj | Add-Member NoteProperty -Name "DNS" -Value "Pass" -Force

			#Is server online
			Write-Host "Server up: " -NoNewline; 
			$ping = new-object System.Net.NetworkInformation.Ping
			$result = $ping.send($ip)
			if ($result.status.ToString() –eq "Success")
			{
				Write-Host -ForegroundColor $pass "Pass"
				$serverObj | Add-Member NoteProperty -Name "Ping" -Value "Pass" -Force
				
				#Uptime check
				$uptime = $null
				$laststart = $null
				
				try 
				{
					$laststart = [System.Management.ManagementDateTimeconverter]::ToDateTime((Get-WmiObject -Class Win32_OperatingSystem -computername $server -ErrorAction Stop).LastBootUpTime)
				}
				catch
				{
					Write-Host -ForegroundColor $warn $_.Exception.Message
				}
				finally	{}
				
				if ($laststart -eq $null)
				{
					[string]$uptime = "Unable to retrieve uptime"
				}
				else
				{
					[int]$uptime = (New-TimeSpan $laststart $now).TotalHours
					[int]$uptime = "{0:N0}" -f $uptime
				}
				
				Write-Host "Uptime (hrs): " -NoNewline;
				Switch ($uptime -gt 23) {
					$true { Write-Host -ForegroundColor $pass $uptime }
					$false { Write-Host -ForegroundColor $warn $uptime }
					default { Write-Host -ForegroundColor $warn $uptime }
					}
				$serverObj | Add-Member NoteProperty -Name "Uptime (hrs)" -Value $uptime -Force	
			
				#Determine the friendly version number
				$ExVer = $roles.AdminDisplayVersion
				Write-Host "Server version: " -NoNewline;
				
				if ($ExVer -like "Version 6.*")
				{
					$version = "Exchange 2003"
				}
				
				if ($ExVer -like "Version 8.*")
				{
					$version = "Exchange 2007"
				}
				
				if ($ExVer -like "Version 14.*")
				{
					$version = "Exchange 2010"
				}
				
				Write-Host $version				
				$serverObj | Add-Member NoteProperty -Name "Version" -Value $version -Force
			
				if ($version -eq "Exchange 2003")
				{
					Write-Host $string12
					$report = $report + $serverObj
				}
				if ($version -eq "Exchange 2007" -or $version -eq "Exchange 2010")
				{
					#START - Exchange 2007/2010 Health Checks
					
					Write-Host "Roles:" $roles.ServerRole
					$serverObj | Add-Member NoteProperty -Name "Roles" -Value $roles.ServerRole -Force
					
					$IsEdge = $roles.IsEdgeServer		
					$IsHub = $roles.IsHubTransportServer
					$IsCAS = $roles.IsClientAccessServer
					$IsMB = $roles.IsMailboxServer

					#START - General Server Health Check
					#Skipping Edge Transports for the general health check, as firewalls usually get
					#in the way. If you want to include then, remove this If.
					if ($IsEdge -ne $true)
					{
							#Service health is an array due to how multi-role servers return Test-ServiceHealth status
							try {
								$servicehealth = @(Test-ServiceHealth $server -ErrorAction Stop)
							}
							catch {
								$serverObj | Add-Member NoteProperty -Name "Warning Details" -Value ($($serverObj."Warning Details") + $string4) -Force
								Write-Host -ForegroundColor $warn $string4
							}
							
							if ($servicehealth)
							{
								foreach($s in $servicehealth)
								{
									switch ($s.Role)
									{
										"Client Access Server Role" { $roleservices = "CA Services" }
										"Hub Transport Server Role" { $roleservices = "HT Services" }
										"Mailbox Server Role" { $roleservices = "MB Services" }
										"Unified Messaging Server Role" { $roleservices = "UM Services" }
									}
									
									Write-Host $s.Role "Services: " -NoNewline;
									
									switch ($s.RequiredServicesRunning)
									{
										$true { $svchealth = "Pass"; Write-Host -ForegroundColor $pass "Pass" }
										$false {$svchealth = "Fail"; Write-Host -ForegroundColor $fail "Fail"; $serverObj | Add-Member NoteProperty -Name "Error Details" -Value ($($serverObj."Error Details") + $string5) -Force }
									}
									$serverObj | Add-Member NoteProperty -Name $roleservices -Value $svchealth -Force
								}
							}
					}
					#END - General Server Health Check

					#START - Hub Transport Server Check
					if ($IsHub)
					{
						$q = $null
						Write-Host "Total Queue: " -NoNewline; 
						try {
							$q = Get-Queue -server $server -ErrorAction Stop
						}
						catch {
							$serverObj | Add-Member NoteProperty -Name "Warning Details" -Value ($($serverObj."Warning Details") + $string6) -Force
							Write-Host -ForegroundColor $warn $string6
							Write-Warning $_.Exception.Message
						}
						
						if ($q)
						{
							$qcount = $q | Measure-Object MessageCount -Sum
							[int]$qlength = $qcount.sum
							if ($qlength -le $transportqueuewarn)
							{
								Write-Host -ForegroundColor $pass $qlength
								$serverObj | Add-Member NoteProperty -Name "Transport Queue" -Value "Pass" -Force
							}
							elseif ($qlength -gt $transportqueuewarn -and $qlength -lt $transportqueuehigh)
							{
								Write-Host -ForegroundColor $warn $qlength
								$serverObj | Add-Member NoteProperty -Name "Transport Queue" -Value "Warn" -Force
							}
							else
							{
								Write-Host -ForegroundColor $fail $qlength
								$serverObj | Add-Member NoteProperty -Name "Transport Queue" -Value "Fail" -Force
							}
						}
						else
						{
							$serverObj | Add-Member NoteProperty -Name "Transport Queue" -Value "Unknown" -Force
						}
					}
					#END - Hub Transport Server Check

					#START - Mailbox Server Check
					if ($IsMB)
					{
						#Get the PF and MB databases
						[array]$pfdbs = @(Get-PublicFolderDatabase -server $server -status -WarningAction SilentlyContinue)
						[array]$mbdbs = @(Get-MailboxDatabase -server $server -status | Where {$_.Recovery -ne $true})
						[array]$activedbs = @(Get-MailboxDatabase -status | Where {$_.MountedOnServer -eq ($server.fqdn)})
						
						#START - Database Mount Check
						
						#Check public folder databases
						if ($pfdbs.count -gt 0)
						{
							Write-Host "Public Folder databases mounted: " -NoNewline;
							[string]$pfdbstatus = "Pass"
							[array]$alertdbs = @()
							foreach ($db in $pfdbs)
							{
								if (($db.mounted) -ne $true)
								{
									$pfdbstatus = "Fail"
									$alertdbs += $db.name
								}
							}

							$serverObj | Add-Member NoteProperty -Name "PF DBs Mounted" -Value $pfdbstatus -Force
							
							if ($alertdbs.count -eq 0)
							{
								Write-Host -ForegroundColor $pass $pfdbstatus
							}
							else
							{
								Write-Host -ForegroundColor $fail $pfdbstatus
								$serverObj | Add-Member NoteProperty -Name "Error Details" -Value ($($serverObj."Error Details") + $string7) -Force
								Write-Host "Offline databases:"
								foreach ($al in $alertdbs)
								{
									Write-Host -ForegroundColor $fail `t$al
								}
							}
						}
						
						#Check mailbox databases
						if ($mbdbs.count -gt 0)
						{
							[string]$mbdbstatus = "Pass"
							[array]$alertdbs = @()

							Write-Host "Mailbox databases mounted: " -NoNewline;
							foreach ($db in $mbdbs)
							{
								if (($db.mounted) -ne $true)
								{
									$mbdbstatus = "Fail"
									$alertdbs += $db.name
								}
							}

							$serverObj | Add-Member NoteProperty -Name "MB DBs Mounted" -Value $mbdbstatus -Force							
							
							if ($alertdbs.count -eq 0)
							{
								Write-Host -ForegroundColor $pass $mbdbstatus
							}
							else
							{
								$serverObj | Add-Member NoteProperty -Name "Error Details" -Value ($($serverObj."Error Details") + $string9) -Force
								Write-Host -ForegroundColor $fail $mbdbstatus
								Write-Host "Offline databases: "
								foreach ($al in $alertdbs)
								{
									Write-Host -ForegroundColor $fail `t$al
								}
							}
						}
						
						#END - Database Mount Check
						
						#START - MAPI Connectivity Test
						if ($activedbs.count -gt 0 -or $pfdbs.count -gt 0)
						{
							[string]$mbdbstatus = "Pass"
							[array]$alertdbs = @()
							Write-Host "MAPI connectivity: " -NoNewline;
							foreach ($db in $mbdbs)
							{
								$mapistatus = Test-MapiConnectivity -Database $db -PerConnectionTimeout $mapitimeout
								if (($mapistatus.Result.Value) -ne "Success")
								{
									$mbdbstatus = "Fail"
									$alertdbs += $db.name
								}
							}

							$serverObj | Add-Member NoteProperty -Name "MAPI Test" -Value $mbdbstatus -Force
							
							if ($alertdbs.count -eq 0)
							{
								Write-Host -ForegroundColor $pass $mbdbstatus
							}
							else
							{
								$serverObj | Add-Member NoteProperty -Name "Error Details" -Value ($($serverObj."Error Details") + $string10) -Force
								Write-Host -ForegroundColor $fail $mbdbstatus
								Write-Host "MAPI failed to: "
								foreach ($al in $alertdbs)
								{
									Write-Host -ForegroundColor $fail `t$al
								}
							}
						}
						#END - MAPI Connectivity Test
						
						#START - Mail Flow Test
						if ($activedbs.count -gt 0 -or $version -eq "Exchange 2007")
						{
						
							$flow = $null
							$testmailflowresult = $null
							
							Write-Host "Mail flow test: " -NoNewline;
							try
							{
								$flow = Test-Mailflow $server -ErrorAction Stop
							}
							catch
							{
								$testmailflowresult = $_.Exception.Message
							}
							
							if ($flow)
							{
								$testmailflowresult = $flow.testmailflowresult
							}

							if ($testmailflowresult -eq "Success")
							{
								Write-Host -ForegroundColor $pass $testmailflowresult
								$serverObj | Add-Member NoteProperty -Name "Mail Flow Test" -Value "Pass" -Force
							}
							else
							{
								$serverObj | Add-Member NoteProperty -Name "Error Details" -Value ($($serverObj."Error Details") + $string11) -Force
								Write-Host -ForegroundColor $fail $testmailflowresult
								$serverObj | Add-Member NoteProperty -Name "Mail Flow Test" -Value "Fail" -Force
							}
						}
						else
						{
							Write-Host "Mail flow test: No active mailbox databases"
						}
						#END - Mail Flow Test
					}
					#END - Mailbox Server Check

				}
				#END - Exchange 2007/2010 Health Checks
				$report = $report + $serverObj
			}
			else
			{
				#Server is not up
				Write-Host -ForegroundColor $warn $string1
				$serverObj | Add-Member NoteProperty -Name "Error Details" -Value ($($serverObj."Error Details") + $string1) -Force
				$serverObj | Add-Member NoteProperty -Name "Ping" -Value "Fail" -Force
				$report = $report + $serverObj
			}
		}
		else
		{
			Write-Host -ForegroundColor $Fail "Fail"
			Write-Host -ForegroundColor $warn $string13
			$serverObj | Add-Member NoteProperty -Name "Error Details" -Value ($($serverObj."Error Details") + $string13) -Force
			$serverObj | Add-Member NoteProperty -Name "DNS" -Value "Fail" -Force
			$report = $report + $serverObj
		}
	}	
}


#Generate the report
if ($reportmode -or $sendemail)
{
	#Get report generation timestamp
	$reportime = Get-Date

	#Generate report summary
	$summaryreport = $report | select Server,"Error Details","Warning Details" | Where {$_."Error Details" -ne "" -or $_."Warning Details" -ne ""}

	#Create HTML Report
	#Common HTML head and styles
	$htmlhead="<html>
				<style>
				BODY{font-family: Arial; font-size: 8pt;}
				H1{font-size: 16px;}
				H2{font-size: 14px;}
				H3{font-size: 12px;}
				TABLE{border: 1px solid black; border-collapse: collapse; font-size: 8pt;}
				TH{border: 1px solid black; background: #dddddd; padding: 5px; color: #000000;}
				TD{border: 1px solid black; padding: 5px; }
				td.pass{background: #7FFF00;}
				td.warn{background: #FFE600;}
				td.fail{background: #FF0000; color: #ffffff;}
				</style>
				<body>
				<h1 align=""center"">Exchange Server Health Check Report</h1>
				<h3 align=""center"">Generated: $reportime</h3>"

	if ($summaryreport)
	{
		$summaryhtml = "<h3>Exchange Server Health Check Summary</h3>
						<p>The following errors and warnings were detected.</p>
						<p>
						<table>
						<tr>
						<th>Server</th>
						<th>Errors</th>
						<th>Warnings</th>
						</tr>"
		foreach ($reportline in $summaryreport)
		{
			$htmltablerow = "<tr>"
						$htmltablerow = $htmltablerow + "<td>$($reportline.server)</td>"
						$htmltablerow = $htmltablerow + "<td>$($reportline."Error Details")</td>"
						$htmltablerow = $htmltablerow + "<td>$($reportline."Warning Details")</td>"
						
						$summaryhtml = $summaryhtml + $htmltablerow
		}
		$summaryhtml = $summaryhtml + "</table></p>"
	}
	else
	{
		$summaryhtml = "<h3>Exchange Server Health Check Summary</h3>
						<p>No Exchange server health alerts or warnings.</p>"
	}

	if ($report)
	{
		#Exchange 2007/2010 Report Table Header
		$htmltableheader = "<h3>Exchange Server 2007/2010 Health</h3>
							<p>
							<table>
							<tr>
							<th>Server</th>
							<th>Site</th>
							<th>Roles</th>
							<th>Version</th>
							<th>DNS</th>
							<th>Ping</th>
							<th>Uptime (hrs)</th>
							<th>CA Services</th>
							<th>HT Services</th>
							<th>MB Services</th>
							<th>UM Services</th>
							<th>Transport Queue</th>
							<th>PF DBs Mounted</th>
							<th>MB DBs Mounted</th>
							<th>MAPI Test</th>
							<th>Mail Flow Test</th>
							</tr>"

		#Exchange 2007/2010 Report Table
		$htmltable = $htmltable + $htmltableheader					
							
		foreach ($reportline in $report)
		{
			$htmltablerow = "<tr>"
			$htmltablerow = $htmltablerow + "<td>$($reportline.server)</td>"
			$htmltablerow = $htmltablerow + "<td>$($reportline.site)</td>"
			$htmltablerow = $htmltablerow + "<td>$($reportline.roles)</td>"
			$htmltablerow = $htmltablerow + "<td>$($reportline.version)</td>"					
							
			switch ($($reportline.dns))
			{
				"Pass" {$htmltablerow = $htmltablerow + "<td class=""pass"">$($reportline.dns)</td>"}
				"Fail" {$htmltablerow = $htmltablerow + "<td class=""fail"">$($reportline.dns)</td>"}
			}
							
			switch ($($reportline.ping))
			{
				"Pass" {$htmltablerow = $htmltablerow + "<td class=""pass"">$($reportline.ping)</td>"}
				"Fail" {$htmltablerow = $htmltablerow + "<td class=""fail"">$($reportline.ping)</td>"}
			}
			
			if ($($reportline."uptime (hrs)") -eq "Access Denied")
			{
				$htmltablerow = $htmltablerow + "<td class=""warn"">Access Denied</td>"		
			}
			else
			{
				$hours = [int]$($reportline."uptime (hrs)")
				if ($hours -le 24)
				{
					$htmltablerow = $htmltablerow + "<td class=""warn"">$hours</td>"
				}
				else
				{
					$htmltablerow = $htmltablerow + "<td class=""pass"">$hours</td>"
				}
			}

			switch ($($reportline."CA Services"))
			{
				"Pass" {$htmltablerow = $htmltablerow + "<td class=""pass"">$($reportline."CA Services")</td>"}
				"Warn" {$htmltablerow = $htmltablerow + "<td class=""warn"">$($reportline."CA Services")</td>"}
				"Access Denied" {$htmltablerow = $htmltablerow + "<td class=""warn"">$($reportline."CA Services")</td>"}
				"Fail" {$htmltablerow = $htmltablerow + "<td class=""fail"">$($reportline."CA Services")</td>"}
				default {$htmltablerow = $htmltablerow + "<td>$($reportline."CA Services")</td>"}
			}
			
			switch ($($reportline."HT Services"))
			{
				"Pass" {$htmltablerow = $htmltablerow + "<td class=""pass"">$($reportline."HT Services")</td>"}
				"Warn" {$htmltablerow = $htmltablerow + "<td class=""warn"">$($reportline."HT Services")</td>"}
				"Access Denied" {$htmltablerow = $htmltablerow + "<td class=""warn"">$($reportline."HT Services")</td>"}
				"Fail" {$htmltablerow = $htmltablerow + "<td class=""fail"">$($reportline."HT Services")</td>"}
				default {$htmltablerow = $htmltablerow + "<td>$($reportline."HT Services")</td>"}
			}
			
			switch ($($reportline."MB Services"))
			{
				"Pass" {$htmltablerow = $htmltablerow + "<td class=""pass"">$($reportline."MB Services")</td>"}
				"Warn" {$htmltablerow = $htmltablerow + "<td class=""warn"">$($reportline."MB Services")</td>"}
				"Access Denied" {$htmltablerow = $htmltablerow + "<td class=""warn"">$($reportline."MB Services")</td>"}
				"Fail" {$htmltablerow = $htmltablerow + "<td class=""fail"">$($reportline."MB Services")</td>"}
				default {$htmltablerow = $htmltablerow + "<td>$($reportline."MB Services")</td>"}
			}
			
			switch ($($reportline."UM Services"))
			{
				"Pass" {$htmltablerow = $htmltablerow + "<td class=""pass"">$($reportline."UM Services")</td>"}
				"Warn" {$htmltablerow = $htmltablerow + "<td class=""warn"">$($reportline."UM Services")</td>"}
				"Access Denied" {$htmltablerow = $htmltablerow + "<td class=""warn"">$($reportline."UM Services")</td>"}
				"Fail" {$htmltablerow = $htmltablerow + "<td class=""fail"">$($reportline."UM Services")</td>"}
				default {$htmltablerow = $htmltablerow + "<td>$($reportline."UM Services")</td>"}
			}
							
			switch ($($reportline."Transport Queue"))
			{
				"Pass" {$htmltablerow = $htmltablerow + "<td class=""pass"">$($reportline."Transport Queue")</td>"}
				"Warn" {$htmltablerow = $htmltablerow + "<td class=""warn"">$($reportline."Transport Queue")</td>"}
				"Fail" {$htmltablerow = $htmltablerow + "<td class=""fail"">$($reportline."Transport Queue")</td>"}
				"Unknown" {$htmltablerow = $htmltablerow + "<td class=""warn"">$($reportline."Transport Queue")</td>"}
				default {$htmltablerow = $htmltablerow + "<td >$($reportline."Transport Queue")</td>"}
			}

			switch ($($reportline."PF DBs Mounted"))
			{
				"Pass" {$htmltablerow = $htmltablerow + "<td class=""pass"">$($reportline."PF DBs Mounted")</td>"}
				"Fail" {$htmltablerow = $htmltablerow + "<td class=""fail"">$($reportline."PF DBs Mounted")</td>"}
				default {$htmltablerow = $htmltablerow + "<td>$($reportline."PF DBs Mounted")</td>"}
			}

			switch ($($reportline."MB DBs Mounted"))
			{
				"Pass" {$htmltablerow = $htmltablerow + "<td class=""pass"">$($reportline."MB DBs Mounted")</td>"}
				"Fail" {$htmltablerow = $htmltablerow + "<td class=""fail"">$($reportline."MB DBs Mounted")</td>"}
				default {$htmltablerow = $htmltablerow + "<td>$($reportline."MB DBs Mounted")</td>"}
			}

			switch ($($reportline."MAPI Test"))
			{
				"Pass" {$htmltablerow = $htmltablerow + "<td class=""pass"">$($reportline."MAPI Test")</td>"}
				"Fail" {$htmltablerow = $htmltablerow + "<td class=""fail"">$($reportline."MAPI Test")</td>"}
				default {$htmltablerow = $htmltablerow + "<td>$($reportline."MAPI Test")</td>"}
			}
			
			switch ($($reportline."Mail Flow Test"))
			{
				"Pass" {$htmltablerow = $htmltablerow + "<td class=""pass"">$($reportline."Mail Flow Test")</td>"}
				"Fail" {$htmltablerow = $htmltablerow + "<td class=""fail"">$($reportline."Mail Flow Test")</td>"}
				default {$htmltablerow = $htmltablerow + "<td>$($reportline."Mail Flow Test")</td>"}
			}

			$htmltablerow = $htmltablerow + "</tr>"
			
			$htmltable = $htmltable + $htmltablerow
		}
		$htmltable = $htmltable + "</table></p>"
	}
	
	$htmltail = "</body>
				</html>"
				

	$htmlreport = $htmlhead + $summaryhtml + $htmltable + $htmltail
	
	if ($reportmode -or $reportfile)
	{
		$htmlreport | Out-File $reportfile
	}

	if ($sendemail)
	{
		#Get ready to send email message
		$message = New-Object System.Net.Mail.MailMessage $smtpfrom, $smtpto
		$message.Subject = $messageSubject
		$message.IsBodyHTML = $true
		$message.Body = $htmlreport

		#Send email message
		$smtp = New-Object Net.Mail.SmtpClient($smtpServer)
		$smtp.Send($message)
	}
}

