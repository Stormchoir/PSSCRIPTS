﻿#created by Gary Jackson
#Script designed to easily disable a user account and remove security groups.

Add-Pssnapin Microsoft.Exchange.Management.PowerShell.E2010
add-pssnapin -name "Quest.ActiveRoles.ADManagement"

#Prompt for Username 
$username = read-host -prompt "Please enter the username of the user to be disabled."
disable-QADUser $username
Set-QADUser -identity $username -Fax ""

#Lists group memberships
Write-Host -foregroundcolor green "The user is currently a member of the following groups:"
Write-Host ""
Get-QADMemberOf $username
Write-Host ""

#Request membership removal
$action = read-host -prompt "Would you like to remove all of this user's group memberships?"
if ($action -eq "yes") { 
Remove-QADMemberOf $username -RemoveAll
Write-Host -foregroundcolor green "The account has been disabled and all group memberships have been removed"
}
if ($action -eq "no") { 
Write-Host -foregroundcolor green "The account has been disabled but still retain their groups."
}
#Disable Spigot Account:
Read-Host "Stop here and disable the users Spigot account then press Enter to continue"

#Request mailbox permissions
$actionmbx = read-host -prompt "Lastly, would you like to grant someone access to this disabled user's mailbox?"

if ($actionmbx -eq "yes") { 
$user = read-host -prompt "Which user would you like to grant the access?"
Add-MailboxPermission $username -user $user -AccessRights FullAccess
Write-Host -foregroundcolor green "The mailbox access has been granted."
}
if ($actionmbx -eq "no") { 
Write-Host -foregroundcolor green "No Mailbox permissions have been granted."
}
#Display group memberships
write-Host -foregroundcolor green "User group memberships:"
Get-QADMemberof $username


