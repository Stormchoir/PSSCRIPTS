#Collect Username Details
$firstname = read-host -prompt "Enter First Name"
$initial = $firstname.Substring(0,1).tolower()
$lastname = read-host -prompt "Enter Last Name"
$trust =  read-host -prompt "Will this user be in the corporate domain? Type yes."
$tmpusername= $initial+$lastname.tolower()
#Test to see if username exists in AD
get-qaduser -identity $tmpusername -LDAPFilter "(sAMAccountName=$tmpusername)"
If ($tmpusername -eq $Null) {$username= $initial+$lastname.tolower()| Write-Host "User name is: " $username}
Else {$username= $firstname+$lastname.tolower()| write-host "User name is:" $username}

if ($trust -eq "yes") { 
$domain = "@proassurance.com"
$attrib = " "
}