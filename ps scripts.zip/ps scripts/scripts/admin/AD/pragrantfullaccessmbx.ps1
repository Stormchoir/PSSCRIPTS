﻿Add-Pssnapin Microsoft.Exchange.Management.PowerShell.E2010
add-pssnapin -name "Quest.ActiveRoles.ADManagement"
$user = read-host -prompt "Which user needs full mailbox and Send on Behalf Permission?"
$mailbox = read-host -prompt "Which mailbox would you like to grant this permission?"
Add-MailboxPermission $mailbox -user $user -AccessRights FullAccess
Get-Mailbox $mailbox | set-mailbox -GrantSendOnBehalfto @{Add="$user"}
Write-Host ""
Write-Host $user "now has full access to the "$mailbox "mailbox."
