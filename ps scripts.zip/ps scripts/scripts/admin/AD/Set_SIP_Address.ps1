$SIP = "SIP:agalle@proassurance.com"
Set-QADUser -identity agalle -OA @{proxyAddresses = ($SIP);'msRTCSIP-PrimaryUserAddress' = ($sip)}