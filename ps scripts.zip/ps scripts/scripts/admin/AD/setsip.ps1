# 1. Get username
$user = Read-Host -Prompt 'Input user name'

# 2. Get users email addresss
$email = Get-ADUser $user -Properties mail | Select-Object -ExpandProperty mail
Write-Host "Your email is '$email'"

# 3. Set users msRTCSIP-PrimaryUserAddress as their email
$msrtpua = "sip:" + $email 

Write-Host $msrtpua

Set-ADuser $user -Replace @{'msRTCSIP-PrimaryUserAddress'= $msrtpua}