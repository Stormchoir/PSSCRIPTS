﻿#created by Gary Jackson
#Script designed to easily create new mailboxes and user accounts

Add-Pssnapin Microsoft.Exchange.Management.PowerShell.E2010
add-pssnapin -name "Quest.ActiveRoles.ADManagement"

#Prompt for Username and Password
$firstname = read-host -prompt "Enter First Name"
$initial = $firstname.Substring(0,1).tolower()
$lastname = read-host -prompt "Enter Last Name"
$trust =  read-host -prompt "Will this user be in the corporate domain? Type yes."
$name=$lastname+", "+$firstname
$username= $initial+$lastname.tolower()
$displayname=$lastname+", "+$firstname
$officialname = read-host -prompt "What is the users official name?"
$title = read-host -prompt "What is the user's title?"
$password = read-host -assecurestring -prompt "Please enter a Password"
$logonscript = read-host "Enter the logon script to be used"
$startdate = read-host "Please enter the start date. (i.e. 04/18/2001)"
$department = read-host "Enter the department name."
$office = read-host "Please enter the office for the new user."
$laptop = read-host "Will this user be given a laptop?"
# Determine UPN suffix
if ($trust -eq "yes") { 
$domain = "@proassurance.com"
$attrib = " "
}


$upn=$username+$domain

#Pick Mailbox Database and write mailbox database value to variable
Write-Host ""
Write-Host -foregroundcolor Green "Please Pick a Mailbox Database"
Write-Host ""
Write-Host "1 - DB01 - Corporate/HCPL/PICA except Okemos"
Write-Host ""
Write-Host "2 - DB02 - Medmarc & Eastern"
Write-Host ""
Write-Host "3 - DB03 - Okemos"
Write-Host ""
Write-Host "4 - DB04 - Okemos"
Write-Host ""
$mailnumber = read-host -prompt "Please Choose a number"

if ($mailnumber -eq "1") { 
$maildatabase = "db01"
}

if ($mailnumber -eq "2") { 
$maildatabase = "db02"
}

if ($mailnumber -eq "3") { 
$maildatabase = "db03"
}

if ($mailnumber -eq "4") { 
$maildatabase = "db04"
}

#Choose department for AD account

Write-Host ""
Write-Host -foregroundcolor Green "Select the proper department in Birmingham for the new user."
Write-Host ""
Write-Host "1  - PICA Administration"
Write-Host "2  - PICA Audit"
Write-Host "3  - PICA Claims"
Write-Host "4  - PICA Committee Member"
Write-Host "5  - PCIA Executive"
Write-Host "6  - PICA Finance"
Write-Host "7  - PICA Information Systems"
Write-Host "8  - PICA Marketing"
Write-Host "9  - PICA Operations"
Write-Host "10  - PICA Regulatory"
Write-Host "11  - PICA Underwriting"
Write-Host ""
$ounumber = read-host -prompt "Please Choose a number"

if ($ounumber -eq "1") { 
$ou = "corporate.local/PICA/Administration"
}
if ($ounumber -eq "2") { 
$ou = "corporate.local/PICA/Audit"
}
if ($ounumber -eq "3") { 
$ou = "corporate.local/PICA/Claims"
}
if ($ounumber -eq "4") { 
$ou = "corporate.local/PICA/Committee Members"
}
if ($ounumber -eq "5") { 
$ou = "corporate.local/PICA/Executives"
}
if ($ounumber -eq "6") { 
$ou = "corporate.local/PICA/Finance"
}
if ($ounumber -eq "7") { 
$ou = "corporate.local/PICA/Information Systems"
}
if ($ounumber -eq "8") { 
$ou = "corporate.local/PICA/Marketing"
}
if ($ounumber -eq "9") { 
$ou = "corporate.local/PICA/Operations"
}
if ($ounumber -eq "10") { 
$ou = "corporate.local/PICA/Regulatory"
}
if ($ounumber -eq "11") { 
$ou = "corporate.local/PICA/Underwriting"
}


#Create Mailbox and AD Account

New-Mailbox -name $name -userprincipalname $upn -Alias $username -OrganizationalUnit $ou -FirstName $firstname -LastName $LastName -Password $password -ResetPasswordOnNextLogon $true -Database $maildatabase -DisplayName $displayname
Write-Host ""
Write-Host -foregroundcolor Blue "Mailbox Created"
Write-Host ""
Start-Sleep -s 10

#Set AD Property Information
Connect-QADService -Service pro-bhm-dc1.corporate.local
Set-QADUser -Identity $upn -LogonScript $logonscript
Set-QADUser -Identity $username -OA @{"msRTCSIP-PrimaryUserAddress" = 'sip:' + $username + '@proassurance.com'}
Set-QADUser -Identity $username -OA @{"Proxyaddresses=" = 'sip:' + $username + '@proassurance.com'}
Set-QADUser -Identity $upn -ObjectAttributes @{empDateOfHire=get-date $startdate" 10:01:01 AM"}
Set-QADUser -Identity $upn -objectAttributes @{extensionAttribute1=$Officialname}
Write-Host ""
Write-Host -foregroundcolor Blue "Logon Script set as: " $logonscript
Write-Host -foregroundcolor Green "Official name set as: " $officialname

#Set Address Information

if ($office -eq "Franklin") { 
Set-QADUser -Identity $upn -StreetAddress "3000 Meridian Blvd Suite 400"
Set-QADUser -Identity $upn -co "United States"
Set-QADUser -Identity $upn -CountryCode 615
Set-QADUser -Identity $upn -c US
Set-QADUser -Identity $upn -StateOrProvince TN
Set-QADUser -Identity $upn -Office Franklin
Set-QADUser -Identity $upn -City Franklin
Set-QADUser -Identity $upn -PostalCode 37067
Set-QADUser -Identity $upn -Title $title
Set-QADUser -Identity $upn -Company "PICA"
Set-QADUser -Identity $upn -Department $department
Set-QADUser -Identity $upn -Description $department

if ($office -eq "Birmingham") { 
Set-QADUser -Identity $upn -StreetAddress "100 Brookwood Place, Suite 500"
Set-QADUser -Identity $upn -co "United States"
Set-QADUser -Identity $upn -CountryCode 840
Set-QADUser -Identity $upn -c US
Set-QADUser -Identity $upn -StateOrProvince AL
Set-QADUser -Identity $upn -PostOfficeBox "P.O. Box 590009"
Set-QADUser -Identity $upn -Office Birmingham
Set-QADUser -Identity $upn -City Birmingham
Set-QADUser -Identity $upn -PostalCode 35209
Set-QADUser -Identity $upn -Title $title
Set-QADUser -Identity $upn -Company "ProAssurance Corporation"
Set-QADUser -Identity $upn -Department $department
Set-QADUser -Identity $upn -Description $department
}
if ($office -eq "Okemos") {
Set-QADUser -Identity $upn -StreetAddress "2600 Professionals Dr."
Set-QADUser -Identity $upn -co "United States"
Set-QADUser -Identity $upn -CountryCode 840
Set-QADUser -Identity $upn -c US
Set-QADUser -Identity $upn -StateOrProvince MI
Set-QADUser -Identity $upn -PostOfficeBox "P.O. Box 150"
Set-QADUser -Identity $upn -Office Okemos
Set-QADUser -Identity $upn -City Okemos
Set-QADUser -Identity $upn -PostalCode 48864
Set-QADUser -Identity $upn -Title $title
Set-QADUser -Identity $upn -Company "ProAssurance Corporation"
Set-QADUser -Identity $upn -Department $department
Set-QADUser -Identity $upn -Description $department
}
if ($office -eq "Austin") {
Set-QADUser -Identity $upn -StreetAddress "1221 South Mopax Expressway Suite 200"
Set-QADUser -Identity $upn -co "United States"
Set-QADUser -Identity $upn -CountryCode 840
Set-QADUser -Identity $upn -c US
Set-QADUser -Identity $upn -StateOrProvince TX
Set-QADUser -Identity $upn -PostOfficeBox "P.O. Box 150"
Set-QADUser -Identity $upn -Office Austin
Set-QADUser -Identity $upn -City Austin
Set-QADUser -Identity $upn -PostalCode 78746
Set-QADUser -Identity $upn -Title $title
Set-QADUser -Identity $upn -Company "ProAssurance Corporation"
Set-QADUser -Identity $upn -Department $department
Set-QADUser -Identity $upn -Description $department
}
if ($office -eq "Las Vegas") {
Set-QADUser -Identity $upn -StreetAddress "6859 S. Eastern Ave., Ste. 103"
Set-QADUser -Identity $upn -co "United States"
Set-QADUser -Identity $upn -CountryCode 840
Set-QADUser -Identity $upn -c US
Set-QADUser -Identity $upn -StateOrProvince NV
Set-QADUser -Identity $upn -Office Nevada
Set-QADUser -Identity $upn -City "Las Vegas"
Set-QADUser -Identity $upn -PostalCode "89119-0003"
Set-QADUser -Identity $upn -Title $title
Set-QADUser -Identity $upn -Company "ProAssurance Corporation"
Set-QADUser -Identity $upn -Department $department
Set-QADUser -Identity $upn -Description $department
}
if ($office -eq "Indianapolis") {
Set-QADUser -Identity $upn -StreetAddress "8425 Woodfield Crossing Blvd., Suite 300"
Set-QADUser -Identity $upn -co "United States"
Set-QADUser -Identity $upn -CountryCode 840
Set-QADUser -Identity $upn -c US
Set-QADUser -Identity $upn -StateOrProvince IN
Set-QADUser -Identity $upn -Office Indianapolis
Set-QADUser -Identity $upn -City "Indianapolis"
Set-QADUser -Identity $upn -PostalCode "46240"
Set-QADUser -Identity $upn -Title $title
Set-QADUser -Identity $upn -Company "ProAssurance Corporation"
Set-QADUser -Identity $upn -Department $department
Set-QADUser -Identity $upn -Description $department
}

#Set proper group memberships

if ($ounumber -eq "1") { 

Add-QADGroupMember -Identity "FW - HTTP/HTTPS Access" -Member $username

}
if ($ounumber -eq "2") { 

Add-QADGroupMember -Identity "FW - HTTP/HTTPS Access" -Member $username

}
if ($ounumber -eq "3") { 

Add-QADGroupMember -Identity "FW - HTTP/HTTPS Access" -Member $username

}
if ($ounumber -eq "4") { 

Add-QADGroupMember -Identity "FW - HTTP/HTTPS Access" -Member $username

}
if ($ounumber -eq "5") { 
Add-QADGroupMember -Identity "FW - HTTP/HTTPS Access" -Member $username

}
if ($ounumber -eq "6") { 
Add-QADGroupMember -Identity "FW - HTTP/HTTPS Access" -Member $username

}
if ($ounumber -eq "7") { 
Add-QADGroupMember -Identity "FW HTTP/HTTPS Access" -Member $username

}

if ($ounumber -eq "8") { 
Add-QADGroupMember -Identity "FW - HTTP/HTTPS Access" -Member $username
}

if ($ounumber -eq "9") { 
Add-QADGroupMember -Identity "FW - HTTP/HTTPS Access" -Member $username
}

if ($ounumber -eq "10") { 
Add-QADGroupMember -Identity "FW - HTTP/HTTPS Access" -Member $username

}
if ($ounumber -eq "11") { 
Add-QADGroupMember -Identity "FW - HTTP/HTTPS Access" -Member $username
}

if ($laptop -eq "yes") {
Add-QADGroupMember -Identity ADM_LAPTOP_USERS -Member $username
}

#Configure Mailbox Properties
Set-CasMailbox -ActiveSyncEnabled $false -PopEnabled $false -ImapEnabled $false -Identity $username

#Output Summary
Write-Host ""
Write-Host -foregroundcolor Green "User Summary"
Write-Host ""
Write-Host "Username: " $username
Write-Host "Password: " $password
Write-Host "Mailbox Creation: yes"
Write-Host "Removed unnecessary mailbox features: yes"
Write-Host "Group Memberships: " Get-QADMemberOf $username | select Name
Write-Host "Alias: " $username
Write-Host "Profile Login Script: " (Get-QADUser -Identity $upn | select LogonScript)
Write-Host "Home Folder Creation:"
$adm = Get-QADMemberOf $upn | where {$_.Name -like 'ADM_BHM*'} | select name | fw
Write-Host "ADM Group: " Get-QADMemberOf $upn | where {$_.Name -like 'ADM_BHM*'} | select name | ft -HideTableHeaders
Write-Host "Display Name: " $displayname
Write-Host "UPN: " $upn
Write-Host "Title: " $title
Write-Host "Extension: "
Write-Host "Department: " $department 
Write-Host "Mailbox Database: " $maildatabase
Write-Host "OU = " $ou
Write-Host "Address: Yes"
Write-Host ""
write-host "Make sure company field is filled out correctly."
write-host "Make sure users SIP access is correctly configured.""  MSRTCSIP-PrimaryUserAddress"
Write-Host "Make sure Official Name on extensionAttribute1 is set correctly."
Write-Host "Make sure SIP address was added to Proxyaddresses."

Start-Sleep -s 60
