# Bind to user object in AD.
$User =  [ADSI]"LDAP://cn=Test User,ou=PICA,dc=Corporate,dc=local"
# Expire password immediately.
$User.pwdLastSet = 0
# Save change in AD.
$User.SetInfo()