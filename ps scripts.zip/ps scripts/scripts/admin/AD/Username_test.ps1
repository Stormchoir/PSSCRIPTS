#Collect Username Details
$firstname = read-host -prompt "Enter First Name"
$initial = $firstname.Substring(0,1).tolower()
$lastname = read-host -prompt "Enter Last Name"


#$trust =  read-host -prompt "Will this user be in the corporate domain? Type yes."
#if ($trust -eq "yes") 
#{ 
#$domain = "@proassurance.com"
#$attrib = " "
#}

$tmpusername= $initial+$lastname.tolower()

Do
{
	 Try
	 {
		 # Attempt to retrieve information on the user.
         Get-QADUser -LDAPFilter "(sAMAccountName=$tmpusername)"
         # The user exists.
		 $username = $firstname+$lastname.tolower()
         $Exit = 1
	 } 
	Catch
	{
		 # User does not exist
		 $username = $initial+$lastname.tolower()
		 $Exit = 1
	}

}
While ($exit -eq 0)



#Test to see if username exists in AD

#$username = get-qaduser -LDAPFilter "(sAMAccountName=$tmpusername)"

#If ($username -eq $Null) {$username = $initial+$lastname.tolower()} 
#Else {$username= $firstname+$lastname.tolower()}
Write-Host "User name is: " $username

