$accountName = Read-Host "Enter account name"
$newPassword = Read-Host -AsSecureString "Enter new password"
Get-QADUser -SamAccountName $accountName | Set-QADUser -UserPassword $newPassword