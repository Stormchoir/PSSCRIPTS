﻿#created by Gary Jackson
#Script designed to easily create new mailboxes and user accounts

Add-Pssnapin Microsoft.Exchange.Management.PowerShell.E2010
add-pssnapin -name "Quest.ActiveRoles.ADManagement"

#Prompt for Username and Password
$firstname = read-host -prompt "Enter First Name"
$initial = $firstname.Substring(0,1).tolower()
$lastname = read-host -prompt "Enter Last Name"
$trust =  read-host -prompt "Will this user be in the corporate domain? Type yes."
$name=$lastname+", "+$firstname
$username= $initial+$lastname.tolower()
$displayname=$lastname+", "+$firstname
$officialname = read-host -prompt "What is the users official name?"
$title = read-host -prompt "What is the user's title?"
$password = read-host -assecurestring -prompt "Please enter a Password"
$logonscript = read-host "Enter the logon script to be used"
$startdate = read-host "Please enter the start date. (i.e. 04/18/2001)"
$department = read-host "Enter the department name."
$office = read-host "Please enter the office for the new user."
$laptop = read-host "Will this user be given a laptop?"
# Determine UPN suffix
if ($trust -eq "yes") { 
$domain = "@proassurance.com"
$attrib = " "
}


$upn=$username+$domain

#Pick Mailbox Databse and write mailbox databse vaule to variable
Write-Host ""
Write-Host -foregroundcolor Green "Please Pick a Mailbox Database"
Write-Host ""
Write-Host "1 - DB01 - Corporate/HCPL/PICA except Okemos"
Write-Host ""
Write-Host "2 - DB02 - Medmarc & Eastern"
Write-Host ""
Write-Host "3 - DB03 - Okemos"
Write-Host ""
Write-Host "4 - DB04 - Okemos"
Write-Host ""
$mailnumber = read-host -prompt "Please Choose a number"

if ($mailnumber -eq "1") { 
$maildatabase = "db01"
}

if ($mailnumber -eq "2") { 
$maildatabase = "db02"
}

if ($mailnumber -eq "3") { 
$maildatabase = "db03"
}

if ($mailnumber -eq "4") { 
$maildatabase = "db04"
}

#Choose department for AD account

Write-Host ""
Write-Host -foregroundcolor Green "Select the proper department in Birmingham for the new user."
Write-Host ""
Write-Host "1  - Bham Accounting"
Write-Host "2  - Bham Actuary"
Write-Host "3  - Bham Administration"
Write-Host "4  - Bham Agency"
Write-Host "5  - Bham Claims"
Write-Host "6  - Bham Communications"
Write-Host "7  - Bham Company Services"
Write-Host "8  - Bham Human Resources"
Write-Host "9  - Bham Information Systems"
Write-Host "10 - Bham Investments"
Write-Host "11 - Bham Legal"
Write-Host "12 - Bham OBGYN Risk Alliance"
Write-Host "13 - Bham Reception"
Write-Host "14 - Bham Red Mountain"
Write-Host "15 - Bham Risk Management"
Write-Host "16 - OKE Sales and Marketing"
Write-Host "17 - Bham Underwriting"
Write-Host "18 - Nonhuman account"
Write-Host "19 - Bham Claims Service Center"
Write-Host "20 - Bham UW Service Center"
Write-Host "21 - Oke Claims Service Center"
Write-Host "22 - Oke UW Service Center"
Write-Host "23 - Oke Risk Management"
Write-Host "24 - Aus Underwriting"
Write-Host "25 - Vegas"
Write-Host "26 - Indianapolis Claims"
Write-Host "27 - Indianapolis Underwriting"
Write-Host "28 - Indianapolis Sales & Marketing"
Write-Host "29  - Bham Audit"
Write-Host ""
$ounumber = read-host -prompt "Please Choose a number"

if ($ounumber -eq "1") { 
$ou = "corporate.local/Enterprise Admins/MAI/Offices Win7/Users Win7/Birmingham/Accounting"
}
if ($ounumber -eq "2") { 
$ou = "corporate.local/Enterprise Admins/MAI/Offices Win7/Users Win7/Birmingham/Actuary"
}
if ($ounumber -eq "3") { 
$ou = "corporate.local/Enterprise Admins/MAI/Offices Win7/Users Win7/Birmingham/Administration"
}
if ($ounumber -eq "4") { 
$ou = "corporate.local/Enterprise Admins/MAI/Offices Win7/Users Win7/Birmingham/Agency"
}
if ($ounumber -eq "5") { 
$ou = "corporate.local/Enterprise Admins/MAI/Offices Win7/Users Win7/Birmingham/Claims"
}
if ($ounumber -eq "6") { 
$ou = "corporate.local/Enterprise Admins/MAI/Offices Win7/Users Win7/Birmingham/Communications"
}
if ($ounumber -eq "7") { 
$ou = "corporate.local/Enterprise Admins/MAI/Offices Win7/Users Win7/Birmingham/Company Services"
}
if ($ounumber -eq "8") { 
$ou = "corporate.local/Enterprise Admins/MAI/Offices Win7/Users Win7/Birmingham/Human Resources"
}
if ($ounumber -eq "9") { 
$ou = "corporate.local/Enterprise Admins/MAI/Offices Win7/Users Win7/Birmingham/Information Systems"
}
if ($ounumber -eq "10") { 
$ou = "corporate.local/Enterprise Admins/MAI/Offices Win7/Users Win7/Birmingham/Investments"
}
if ($ounumber -eq "11") { 
$ou = "corporate.local/Enterprise Admins/MAI/Offices Win7/Users Win7/Birmingham/Legal"
}
if ($ounumber -eq "12") { 
$ou = "corporate.local/Enterprise Admins/MAI/Offices Win7/Users Win7/Birmingham/OBGYN Risk Alliance"
}
if ($ounumber -eq "13") { 
$ou = "corporate.local/Enterprise Admins/MAI/Offices Win7/Users Win7/Birmingham/Reception"
}
if ($ounumber -eq "14") { 
$ou = "corporate.local/Enterprise Admins/MAI/Offices Win7/Users Win7/Birmingham/Red Mountain"
}
if ($ounumber -eq "15") { 
$ou = "corporate.local/Enterprise Admins/MAI/Offices Win7/Users Win7/Birmingham/Risk Management"
}
if ($ounumber -eq "16") { 
$ou = "corporate.local/Enterprise Admins/MAI/Offices Win7/Users Win7/Okemos/Sales and Marketing"
}
if ($ounumber -eq "17") { 
$ou = "corporate.local/Enterprise Admins/MAI/Offices Win7/Users Win7/Birmingham/Underwriting"
}
if ($ounumber -eq "18") { 
$ou = "corporate.local/Recipients"
}
if ($ounumber -eq "19") { 
$ou = "corporate.local/Enterprise Admins/MAI/Offices Win7/Users Win7/Birmingham/Claims"
}
if ($ounumber -eq "20") { 
$ou = "corporate.local/Enterprise Admins/MAI/Offices Win7/Users Win7/Birmingham/Underwriting"
}
if ($ounumber -eq "21") { 
$ou = "corporate.local/Enterprise Admins/MAI/Offices Win7/Users Win7/Okemos/Claims"
}
if ($ounumber -eq "22") { 
$ou = "corporate.local/Enterprise Admins/MAI/Offices Win7/Users Win7/Okemos/Underwriting"
}
if ($ounumber -eq "23") { 
$ou = "corporate.local/Enterprise Admins/MAI/Offices Win7/Users Win7/Okemos/Risk Management"
}
if ($ounumber -eq "24") { 
$ou = "corporate.local/Enterprise Admins/MAI/Offices Win7/Users Win7/Austin/Underwriting"
}
if ($ounumber -eq "25") { 
$ou = "corporate.local/Enterprise Admins/MAI/Offices Win7/Users Win7/Las Vegas"
}
if ($ounumber -eq "26") { 
$ou = "corporate.local/Enterprise Admins/MAI/Offices Win7/Users Win7/Indianapolis/Claims"
}
if ($ounumber -eq "27") { 
$ou = "corporate.local/Enterprise Admins/MAI/Offices Win7/Users Win7/Indianapolis/Underwriting"
}
if ($ounumber -eq "28") { 
$ou = "corporate.local/Enterprise Admins/MAI/Offices Win7/Users Win7/Indianapolis/Other"
}
if ($ounumber -eq "29") { 
$ou = "corporate.local/Enterprise Admins/MAI/Offices Win7/Users Win7/Birmingham/Audit"
}

#Create Mailbox and AD Account

New-Mailbox -name $name -userprincipalname $upn -Alias $username -OrganizationalUnit $ou -FirstName $firstname -LastName $LastName -Password $password -ResetPasswordOnNextLogon $true -Database $maildatabase -DisplayName $displayname
Write-Host ""
Write-Host -foregroundcolor Blue "Mailbox Created"
Write-Host ""
Start-Sleep -s 10

#Set AD Property Information
Connect-QADService -Service bhm-dc2.corporate.local
Set-QADUser -Identity $upn -LogonScript $logonscript
Set-QADUser -Identity $username -OA @{"msRTCSIP-PrimaryUserAddress" = 'sip:' + $username + '@proassurance.com'}
Set-QADUser -Identity $username -OA @{"proxyAddresses" = 'sip:' + $username + '@proassurance.com'}
Set-QADUser -Identity $upn -ObjectAttributes @{empDateOfHire=get-date $startdate" 10:01:01 AM"}
Set-QADUser -Identity $upn -objectAttributes @{extensionAttribute1=$Officialname}
Write-Host ""
Write-Host -foregroundcolor Blue "Logon Script set as: " $logonscript
Write-Host -foregroundcolor Green "Official name set as: " $officialname

#Set Address Information

if ($office -eq "Birmingham") { 
Set-QADUser -Identity $upn -StreetAddress "100 Brookwood Place, Suite 500"
Set-QADUser -Identity $upn -country "United States"
Set-QADUser -Identity $upn -countryCode 840
Set-QADUser -Identity $upn -c US
Set-QADUser -Identity $upn -StateOrProvince AL
Set-QADUser -Identity $upn -PostOfficeBox "P.O. Box 590009"
Set-QADUser -Identity $upn -Office Birmingham
Set-QADUser -Identity $upn -City Birmingham
Set-QADUser -Identity $upn -PostalCode 35209
Set-QADUser -Identity $upn -Title $title
Set-QADUser -Identity $upn -Company "ProAssurance Corporation"
Set-QADUser -Identity $upn -Department $department
Set-QADUser -Identity $upn -Description $department
}
if ($office -eq "Okemos") {
Set-QADUser -Identity $upn -StreetAddress "2600 Professionals Dr."
Set-QADUser -Identity $upn -country "United States"
Set-QADUser -Identity $upn -countryCode 840
Set-QADUser -Identity $upn -c US
Set-QADUser -Identity $upn -StateOrProvince MI
Set-QADUser -Identity $upn -PostOfficeBox "P.O. Box 150"
Set-QADUser -Identity $upn -Office Okemos
Set-QADUser -Identity $upn -City Okemos
Set-QADUser -Identity $upn -PostalCode 48864
Set-QADUser -Identity $upn -Title $title
Set-QADUser -Identity $upn -Company "HCPL"
Set-QADUser -Identity $upn -Department $department
Set-QADUser -Identity $upn -Description $department
}
if ($office -eq "Austin") {
Set-QADUser -Identity $upn -StreetAddress "1221 South Mopax Expressway Suite 200"
Set-QADUser -Identity $upn -country "United States"
Set-QADUser -Identity $upn -countryCode 840
Set-QADUser -Identity $upn -c US
Set-QADUser -Identity $upn -StateOrProvince TX
Set-QADUser -Identity $upn -PostOfficeBox "P.O. Box 150"
Set-QADUser -Identity $upn -Office Austin
Set-QADUser -Identity $upn -City Austin
Set-QADUser -Identity $upn -PostalCode 78746
Set-QADUser -Identity $upn -Title $title
Set-QADUser -Identity $upn -Company "ProAssurance Corporation"
Set-QADUser -Identity $upn -Department $department
Set-QADUser -Identity $upn -Description $department
}
if ($office -eq "Las Vegas") {
Set-QADUser -Identity $upn -StreetAddress "6859 S. Eastern Ave., Ste. 103"
Set-QADUser -Identity $upn -country "United States"
Set-QADUser -Identity $upn -countryCode 840
Set-QADUser -Identity $upn -c US
Set-QADUser -Identity $upn -StateOrProvince NV
Set-QADUser -Identity $upn -Office Nevada
Set-QADUser -Identity $upn -City "Las Vegas"
Set-QADUser -Identity $upn -PostalCode "89119-0003"
Set-QADUser -Identity $upn -Title $title
Set-QADUser -Identity $upn -Company "ProAssurance Corporation"
Set-QADUser -Identity $upn -Department $department
Set-QADUser -Identity $upn -Description $department
}
if ($office -eq "Indianapolis") {
Set-QADUser -Identity $upn -StreetAddress "8425 Woodfield Crossing Blvd., Suite 300"
Set-QADUser -Identity $upn -country "United States"
Set-QADUser -Identity $upn -countryCode 840
Set-QADUser -Identity $upn -c US
Set-QADUser -Identity $upn -StateOrProvince IN
Set-QADUser -Identity $upn -Office Indianapolis
Set-QADUser -Identity $upn -City "Indianapolis"
Set-QADUser -Identity $upn -PostalCode "46240"
Set-QADUser -Identity $upn -Title $title
Set-QADUser -Identity $upn -Company "ProAssurance Corporation"
Set-QADUser -Identity $upn -Department $department
Set-QADUser -Identity $upn -Description $department
}

#Set proper group memberships

if ($ounumber -eq "1") { 
Add-QADGroupMember -Identity ADM_BHM_ACCOUNTING -Member $username
Add-QADGroupMember -Identity "Finance Accounting" -Member $username
Add-QADGroupMember -Identity "FW - HTTP/HTTPS Access" -Member $username
Add-QADGroupMember -Identity "Accounting" -Member $username
Add-QADGroupMember -Identity "Birmingham Office" -Member $username
Add-QADGroupMember -Identity "ProAssurance Finance and Accounting" -Member $username

}
if ($ounumber -eq "2") { 
Add-QADGroupMember -Identity ADM_BHM_ACTUARY -Member $username
Add-QADGroupMember -Identity Actuarial -Member $username
Add-QADGroupMember -Identity "FW - HTTP/HTTPS Access" -Member $username
Add-QADGroupMember -Identity "AM Best Users" -Member $username
Add-QADGroupMember -Identity "Business Records - Long Term" -Member $username
Add-QADGroupMember -Identity "CededFactorAdmin" -Member $username
Add-QADGroupMember -Identity "Claims Reconciliation" -Member $username
Add-QADGroupMember -Identity "Competitors Filings Write Access" -Member $username
Add-QADGroupMember -Identity "Expert Witness" -Member $username
Add-QADGroupMember -Identity "Expert Witness Test" -Member $username
Add-QADGroupMember -Identity "Freedom Users" -Member $username
Add-QADGroupMember -Identity "HCRusers" -Member $username
Add-QADGroupMember -Identity "hospmco" -Member $username
Add-QADGroupMember -Identity "Infor Users" -Member $username
Add-QADGroupMember -Identity "Multiline Inquiry" -Member $username
Add-QADGroupMember -Identity "proassurance_compliance_manuals_rw" -Member $username
Add-QADGroupMember -Identity "ProAssurance-Employees" -Member $username
}
if ($ounumber -eq "3") { 
Add-QADGroupMember -Identity ADM_BHM_ADMINISTRATION -Member $username
Add-QADGroupMember -Identity Administration -Member $username
Add-QADGroupMember -Identity "FW - HTTP/HTTPS Access" -Member $username
Add-QADGroupMember -Identity "Birmingham Office" -Member $username
}
if ($ounumber -eq "4") { 
Add-QADGroupMember -Identity ADM_BHM_AGENCY -Member $username
Add-QADGroupMember -Identity Agency -Member $username
Add-QADGroupMember -Identity "FW - HTTP/HTTPS Access" -Member $username
Add-QADGroupMember -Identity "Birmingham Office" -Member $username
}
if ($ounumber -eq "5") { 
Add-QADGroupMember -Identity ADM_BHM_CLAIMS -Member $username
Add-QADGroupMember -Identity "Birmingham Office" -Member $username
Add-QADGroupMember -Identity "Birmingham Claims/Litigation" -Member $username
Add-QADGroupMember -Identity "FW - HTTP/HTTPS Access" -Member $username
Add-QADGroupMember -Identity "Alabama Trial Log Distribution" -Member $username
Add-QADGroupMember -Identity "Birmingham Claims/Litigation" -Member $username
Add-QADGroupMember -Identity "Settlement/Verdict Distribution" -Member $username

}
if ($ounumber -eq "6") { 
Add-QADGroupMember -Identity ADM_BHM_COMMUNICATIONS -Member $username
Add-QADGroupMember -Identity "Birmingham Office" -Member $username
Add-QADGroupMember -Identity "Loss Prevention Services" -Member $username
Add-QADGroupMember -Identity "FW - HTTP/HTTPS Access" -Member $username
Add-QADGroupMember -Identity "Corporate Communications" -Member $username
}
if ($ounumber -eq "7") { 
Add-QADGroupMember -Identity "ADM_BHM_COMPANYSERVICES" -Member $username
Add-QADGroupMember -Identity "Birmingham Office" -Member $username
Add-QADGroupMember -Identity "Birmingham Company Services" -Member $username
Add-QADGroupMember -Identity "FW HTTP/HTTPS Access" -Member $username
Add-QADGroupMember -Identity "Company Services" -Member $username
}
if ($ounumber -eq "8") { 
Add-QADGroupMember -Identity ADM_BHM_PERSONNEL -Member $username
Add-QADGroupMember -Identity "Birmingham Office" -Member $username
Add-QADGroupMember -Identity Personnel -Member $username
Add-QADGroupMember -Identity "FW - HTTP/HTTPS Access" -Member $username
}
if ($ounumber -eq "9") { 
Add-QADGroupMember -Identity ADM_BHM_INFORMATIONSYSTEMS -Member $username
Add-QADGroupMember -Identity "Birmingham Office" -Member $username
Add-QADGroupMember -Identity "Information Systems" -Member $username
Add-QADGroupMember -Identity "FW - HTTP/HTTPS Access" -Member $username
}
if ($ounumber -eq "10") { 
Add-QADGroupMember -Identity ADM_BHM_INVESTMENTS -Member $username
Add-QADGroupMember -Identity "Birmingham Office" -Member $username
Add-QADGroupMember -Identity "FW - HTTP/HTTPS Access" -Member $username
Add-QADGroupMember -Identity Investments -Member $username
}
if ($ounumber -eq "11") { 
Add-QADGroupMember -Identity ADM_BHM_LEGAL -Member $username
Add-QADGroupMember -Identity "Birmingham Office" -Member $username
Add-QADGroupMember -Identity Legal -Member $username
Add-QADGroupMember -Identity "FW - HTTP/HTTPS Access" -Member $username
}
if ($ounumber -eq "12") { 
Add-QADGroupMember -Identity ADM_BHM_OBGYNRISKALLIANCE -Member $username
Add-QADGroupMember -Identity "Birmingham Office" -Member $username
Add-QADGroupMember -Identity "OBGYN Risk Alliance" -Member $username
Add-QADGroupMember -Identity "FW - HTTP/HTTPS Access" -Member $username
}
if ($ounumber -eq "13") { 
Add-QADGroupMember -Identity ADM_BHM_UNDERWRITING -Member $username
Add-QADGroupMember -Identity "Birmingham Office" -Member $username
Add-QADGroupMember -Identity "Birmingham Underwriting" -Member $username
Add-QADGroupMember -Identity "FW - HTTP/HTTPS Access" -Member $username
Add-QADGroupMember -Identity "Receptionists - Company-Wide" -Member $username
Add-QADGroupMember -Identity Underwriting -Member $username
}
if ($ounumber -eq "14") { 
Add-QADGroupMember -Identity ADM_BHM_REDMOUNTAIN -Member $username
Add-QADGroupMember -Identity "Birmingham Office" -Member $username
Add-QADGroupMember -Identity "Birmingham Underwriting" -Member $username
Add-QADGroupMember -Identity "FW - HTTP/HTTPS Access" -Member $username
}
if ($ounumber -eq "15") { 
Add-QADGroupMember -Identity ADM_BHM_RISKMANAGEMENT -Member $username
Add-QADGroupMember -Identity "Risk Management" -Member $username
Add-QADGroupMember -Identity "FW - HTTP/HTTPS Access" -Member $username
Add-QADGroupMember -Identity "Birmingham Office" -Member $username
Add-QADGroupMember -Identity Risk-Management -Member $username
}
if ($ounumber -eq "16") { 
Add-QADGroupMember -Identity ADM_OKE_BUSINESSDEVELOPMENT -Member $username
Add-QADGroupMember -Identity "Okemos" -Member $username
Add-QADGroupMember -Identity "FW - HTTP/HTTPS Access" -Member $
Add-QADGroupMember -Identity "Michigan Sales and Marketing" -Member $username
Add-QADGroupMember -Identity "okemos_business-development_rw" -Member $username
}
if ($ounumber -eq "17") { 
Add-QADGroupMember -Identity ADM_BHM_UNDERWRITING -Member $username
Add-QADGroupMember -Identity "Birmingham Underwriting" -Member $username
Add-QADGroupMember -Identity "FW - HTTP/HTTPS Access" -Member $username
Add-QADGroupMember -Identity Underwriting -Member $username
}
if ($ounumber -eq "19") { 
Add-QADGroupMember -Identity ADM_BHM_SERVICE_CENTER_CLAIMS -Member $username
Add-QADGroupMember -Identity "FW - HTTP/HTTPS Access" -Member $username
Add-QADGroupMember -Identity "Birmingham Claims/Litigation" -Member $username
Add-QADGroupMember -Identity "Service Center - Birmingham Claims" -Member $username
}
if ($ounumber -eq "20") { 
Add-QADGroupMember -Identity ADM_BHM_SERVICE_CENTER_UNDERWRITING -Member $username
Add-QADGroupMember -Identity "Birmingham Underwriting" -Member $username
Add-QADGroupMember -Identity "FW - HTTP/HTTPS Access" -Member $username
Add-QADGroupMember -Identity Underwriting -Member $username
Add-QADGroupMember -Identity "Service Center - Birmingham Underwriting" -Member $username
}
if ($ounumber -eq "21") { 
Add-QADGroupMember -Identity ADM_OKE_SERVICE_CENTER_Claims -Member $username
Add-QADGroupMember -Identity "Okemos Claims" -Member $username
Add-QADGroupMember -Identity "FW - HTTP/HTTPS Access" -Member $username
Add-QADGroupMember -Identity Okemos -Member $username
Add-QADGroupMember -Identity "Service Center - Okemos Claims" -Member $username
}
if ($ounumber -eq "22") { 
Add-QADGroupMember -Identity ADM_OKE_SERVICE_CENTER_UNDERWRITING -Member $username
Add-QADGroupMember -Identity "FW - HTTP/HTTPS Access" -Member $username
Add-QADGroupMember -Identity Okemos -Member $username
Add-QADGroupMember -Identity "Service Center - Okemos Underwriting" -Member $username
}
if ($ounumber -eq "23") { 
Add-QADGroupMember -Identity ADM_OKE_RISKMANAGEMENT -Member $username
Add-QADGroupMember -Identity "Okemos Risk Management" -Member $username
Add-QADGroupMember -Identity "FW - HTTP/HTTPS Access" -Member $username
Add-QADGroupMember -Identity Okemos -Member $username
Add-QADGroupMember -Identity "Risk Management - Northern Region" -Member $username
}
if ($ounumber -eq "24") { 
Add-QADGroupMember -Identity ADM_AUS_UNDERWRITING -Member $username
Add-QADGroupMember -Identity "Austin Underwriting" -Member $username
Add-QADGroupMember -Identity "FW - HTTP/HTTPS Access" -Member $username
Add-QADGroupMember -Identity Austin -Member $username
}
if ($ounumber -eq "25") { 
Add-QADGroupMember -Identity ADM_VEG_USERS -Member $username
Add-QADGroupMember -Identity "Las Vegas Claims" -Member $username
Add-QADGroupMember -Identity "Las Vegas Office Distribution Group" -Member $username
Add-QADGroupMember -Identity "Las Vegas Security Group" -Member $username
Add-QADGroupMember -Identity "FW - HTTP/HTTPS Access" -Member $username
}
if ($ounumber -eq "26") { 
Add-QADGroupMember -Identity ADM_IND_CLAIMS -Member $username
Add-QADGroupMember -Identity "Indiana Claims" -Member $username
Add-QADGroupMember -Identity "FW - HTTP/HTTPS Access" -Member $username
Add-QADGroupMember -Identity Indiana -Member $username
}
if ($ounumber -eq "27") { 
Add-QADGroupMember -Identity ADM_IND_UNDERWRITING -Member $username
Add-QADGroupMember -Identity "Indiana Underwriting" -Member $username
Add-QADGroupMember -Identity "FW - HTTP/HTTPS Access" -Member $username
Add-QADGroupMember -Identity Indiana -Member $username
}
if ($ounumber -eq "28") { 
Add-QADGroupMember -Identity ADM_IND_UNDERWRITING -Member $username
Add-QADGroupMember -Identity "Indiana Underwriting" -Member $username
Add-QADGroupMember -Identity "FW - HTTP/HTTPS Access" -Member $username
Add-QADGroupMember -Identity Indiana -Member $username
}
if ($ounumber -eq "29") { 
Add-QADGroupMember -Identity ADM_BHM_AUDIT -Member $username
Add-QADGroupMember -Identity "Birmingham Office" -Member $username
Add-QADGroupMember -Identity "FW - HTTP/HTTPS Access" -Member $username
Add-QADGroupMember -Identity "Internal Audit" -Member $username
}
if ($laptop -eq "yes") {
Add-QADGroupMember -Identity ADM_LAPTOP_USERS -Member $username
Add-QADGroupMember -Identity "FW - GlobalProtect Birmingham" -Member $username
}

#Configure Mailbox Properties
Set-CasMailbox -ActiveSyncEnabled $false -PopEnabled $false -ImapEnabled $false -Identity $username

#Create H: drive
$homefolder = $username
$path = "\\corporate\proassurance\home\"
$newFolderFull = $path + $homefolder
New-Item $newFolderFull -ItemType Directory

#Set home folder permissions

$Acl = (Get-Item $newFolderFull).GetAccessControl('Access')
$AccessRule = New-Object System.Security.AccessControl.FileSystemAccessRule($Username, 'Modify','ContainerInherit,ObjectInherit', 'None', 'Allow')
$Acl.SetAccessRule($AccessRule)
Set-Acl -path $newFolderFull -AclObject $Acl

#Output Summary
Write-Host ""
Write-Host -foregroundcolor Green "User Summary"
Write-Host ""
Write-Host "Username: " $username
Write-Host "Password: " $password
Write-Host "Mailbox Creation: yes"
Write-Host "Removed unnecessary mailbox features: yes"
Write-Host "Group Memberships: " Get-QADMemberOf $username | select Name
Write-Host "Alias: " $username
Write-Host "Profile Login Script: " (Get-QADUser -Identity $upn | select LogonScript)
Write-Host "Home Folder Creation:"
$adm = Get-QADMemberOf $upn | where {$_.Name -like 'ADM_BHM*'} | select name | fw
Write-Host "ADM Group: " Get-QADMemberOf $upn | where {$_.Name -like 'ADM_BHM*'} | select name | ft -HideTableHeaders
Write-Host "Display Name: " $displayname
Write-Host "UPN: " $upn
Write-Host "Title: " $title
Write-Host "Extension: "
Write-Host "Department: " $department 
Write-Host "Mailbox Database: " $maildatabase
Write-Host "OU = " $ou
Write-Host "Address: Yes"
Write-Host ""
Write-Host "Send email to new user group"
Write-Host "Send credentials to users supervisor.  "
write-host "Make sure company field is filled out correctly."
write-host "Make sure users SIP access is correctly configured.""  MSRTCSIP-PrimaryUserAddress"
Write-Host "Make sure Official Name on extensionAttribute1 is set correctly."
Write-Host "Make sure SIP address was added to Proxyaddresses."

Start-Sleep -s 60
