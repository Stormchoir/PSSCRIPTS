﻿#Script designed to easily create new mailboxes and user accounts


#Set and modify AD properties
Import-Module ActiveDirectory
#add exchange cmdlets
add-pssnapin *Exchange*

#Prompt for Username and Password
$firstname = read-host -prompt "Enter First Name"
$initial = $firstname.Substring(0,1).tolower()
$lastname = read-host -prompt "Enter Last Name"
$trust =  read-host -prompt "Will this user be in the corporate domain? Type yes."
$name=$lastname+", "+$firstname
$username= $initial+$lastname.tolower()
$displayname=$lastname+", "+$firstname
$officialname = read-host -prompt "What is the users official name?"
$title = read-host -prompt "What is the user's title?"
$password = read-host -assecurestring -prompt "Please enter a Password"
$logonscript = "global_12.vbs"
$startdate = read-host "Please enter the start date. (i.e. 04/18/2001)"
$department = read-host "Enter the department name."
$departmentfull=$office+" "+$department
$Company = read-host -prompt "What is the company name (HCPL/Corporate/PICA/Medmarc)"
$office = read-host "Please enter the office for the new user."
$laptop = read-host "Will this user be given a laptop?"
# Determine UPN suffix
if ($trust -eq "yes") { 
$domain = "@proassurance.com"
$attrib = " "
}


$upn=$username+$domain

#Pick Mailbox Databse and write mailbox databse vaule to variable
Write-Host ""
Write-Host -foregroundcolor Green "Please Pick a Mailbox Database"
Write-Host ""
Write-Host "1 - DB01 - Corporate/HCPL/PICA except Okemos"
Write-Host ""
Write-Host "2 - DB02 - Medmarc & Eastern"
Write-Host ""
Write-Host "3 - DB03 - Okemos"
Write-Host ""
Write-Host "4 - DB04 - Okemos"
Write-Host ""
$mailnumber = read-host -prompt "Please Choose a number"

if ($mailnumber -eq "1") { 
$maildatabase = "db01"
}

if ($mailnumber -eq "2") { 
$maildatabase = "db02"
}

if ($mailnumber -eq "3") { 
$maildatabase = "db03"
}

if ($mailnumber -eq "4") { 
$maildatabase = "db04"
}

#*******************************************************************************************AD Account data************************************************************************************************************************


#Set OU for user account
$departmentfull = $office + " " + $department
write-host -foregroundcolor Green $departmentfull
#import-csv "\\corporate\birmingham\information systems\OBData\ou.csv" | where-object {$_.Departmentfull -eq $departmentfull}
import-csv "\\corporate\birmingham\information systems\OBData\ou.csv" | Where-object {$_.Departmentfull -eq $departmentfull}
$ou -eq $_.OU
write-host -foregroundcolor Green $ou

#Create Mailbox and AD Account

New-Mailbox -name $name -userprincipalname $upn -Alias $username -OrganizationalUnit $ou -FirstName $firstname -LastName $LastName -Password $password -ResetPasswordOnNextLogon $true -Database $maildatabase -DisplayName $displayname
Write-Host ""
Write-Host -foregroundcolor Blue "Mailbox Created"
Write-Host ""
Start-Sleep -s 5

#Set AD Property Information
#Connect-ADService -Service corporate.local
Set-ADUser -Identity $username -scriptpath $logonscript
#Set-ADUser -Identity $username -OA @{"msRTCSIP-PrimaryUserAddress" = 'sip:' + $username + '@proassurance.com'}
#Set-ADUser -Identity $username -OA @{"proxyAddresses" = 'sip:' + $username + '@proassurance.com'}
#Set-ADUser -Identity $username -ObjectAttributes @{empDateOfHire=get-date $startdate" 10:01:01 AM"}
Set-ADUser -Identity $username -Add @{extensionAttribute1 = "$Officialname"}
Write-Host ""
Write-Host -foregroundcolor Blue "Logon Script set as: " $logonscript
Write-Host -foregroundcolor Green "Official name set as: " $officialname
Set-ADUser -Identity $username -Title $title
Set-ADUser -Identity $username -Department $department
Set-ADUser -Identity $username -Description $department

#Set sip address
$email = Get-ADUser $username -Properties mail | Select-Object -ExpandProperty mail
Write-Host "Your email is '$email'"

$msrtpua = "sip:" + $email

Set-ADuser $username -Replace @{'msRTCSIP-PrimaryUserAddress'= $msrtpua}
Set-ADuser $username -Add @{proxyAddresses= $msrtpua}

#Set Address Information
import-csv "\\corporate\birmingham\information systems\OBData\addresses.csv" | where-object {$_.office -eq $Office}
#$Address = $_.StreetAddress
#$City = $_.City
#$State = $_.StateorProvence
#$zipcode = $_.PostalCode
#$Country = $_.Country
Set-ADUser -Identity $username -Add @{StreetAddress="$_.StreetAddress"}
Set-ADUser -Identity $username -City $_.City
Set-ADUser -Identity $username -StateorProvence $_.StateorProvence
Set-ADUser -Identity $username -zipcode $_.PostalCode
Set-ADUser -Identity $username -Country $_.Country
Set-ADUser -Identity $username -Office $office
Set-ADUser -Identity $username -Company $Company

#Configure Mailbox Properties
Set-CasMailbox -ActiveSyncEnabled $false -PopEnabled $false -ImapEnabled $false -Identity $username

#Assign group memberships
import-csv "\\corporate\birmingham\information systems\OBData\Groups.csv" | where-object {$_.groupfull -eq $groupfull}
$group1 = $_.group1
$group2 = $_.group2
$group3 = $_.group3
$group4 = $_.group4
$group5 = $_.group5
$group6 = $_.group6
$group7 = $_.group7
$group8 = $_.group8
$group9 = $_.group9
$group10 = $_.group10
$group11 = $_.group11
$group12 = $_.group12
$group13 = $_.group13
$group14 = $_.group14
$group15 = $_.group15
$group16 = $_.group16
$group17 = $_.group17
$group18 = $_.group18
$group19 = $_.group19
$group20 = $_.group20

Add-ADGroupMember -Identity $group1 -Member $username
Add-ADGroupMember -Identity $group2 -Member $username
Add-ADGroupMember -Identity $group3 -Member $username
Add-ADGroupMember -Identity $group4 -Member $username
Add-ADGroupMember -Identity $group5 -Member $username
Add-ADGroupMember -Identity $group6 -Member $username
Add-ADGroupMember -Identity $group7 -Member $username
Add-ADGroupMember -Identity $group8 -Member $username
Add-ADGroupMember -Identity $group9 -Member $username
Add-ADGroupMember -Identity $group10 -Member $username
Add-ADGroupMember -Identity $group11 -Member $username
Add-ADGroupMember -Identity $group12 -Member $username
Add-ADGroupMember -Identity $group13 -Member $username
Add-ADGroupMember -Identity $group14 -Member $username
Add-ADGroupMember -Identity $group15 -Member $username
Add-ADGroupMember -Identity $group16 -Member $username
Add-ADGroupMember -Identity $group17 -Member $username
Add-ADGroupMember -Identity $group18 -Member $username
Add-ADGroupMember -Identity $group19 -Member $username
Add-ADGroupMember -Identity $group20 -Member $username

#Create home folder
$homefolder = $username
$path = "\\corporate\proassurance\home\"
$newFolderFull = $path + $homefolder
New-Item $newFolderFull -ItemType Directory

#Set home folder permissions

$Acl = (Get-Item $newFolderFull).GetAccessControl('Access')
$AccessRule = New-Object System.Security.AccessControl.FileSystemAccessRule($Username, 'Modify','ContainerInherit,ObjectInherit', 'None', 'Allow')
$Acl.SetAccessRule($AccessRule)
Set-Acl -path $newFolderFull -AclObject $Acl

#Output Summary
Write-Host ""
Write-Host -foregroundcolor Green "User Summary"
Write-Host ""
Write-Host "Username: " $username
Write-Host "Password: " $password
Write-Host "Mailbox Creation: yes"
Write-Host "Removed unnecessary mailbox features: yes"
Write-Host "Group Memberships: " Get-ADMemberOf $username | select Name
Write-Host "Alias: " $username
Write-Host "Profile Login Script: " (Get-ADUser -Identity $username | select LogonScript)
Write-Host "Home Folder Creation:"
$adm = Get-ADMemberOf $username | where {$_.Name -like 'ADM_BHM*'} | select name | fw
Write-Host "ADM Group: " Get-ADMemberOf $username | where {$_.Name -like 'ADM_BHM*'} | select name | ft -HideTableHeaders
Write-Host "Display Name: " $displayname
Write-Host "UPN: " $upn
Write-Host "Title: " $title
Write-Host "Extension: "
Write-Host "Department: " $department 
Write-Host "Mailbox Database: " $maildatabase
Write-Host "OU = " $ou
Write-Host "Address: Yes"
Write-Host ""
Write-Host "Send email to new user group"
Write-Host "Send credentials to users supervisor.  "
write-host "Make sure company field is filled out correctly."
write-host "Make sure users SIP access is correctly configured.""  MSRTCSIP-PrimaryUserAddress"
Write-Host "Make sure Official Name on extensionAttribute1 is set correctly."
Write-Host "Make sure SIP address was added to Proxyaddresses."

Start-Sleep -s 60
