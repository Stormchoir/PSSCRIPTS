﻿#created by Gary Jackson
#Script designed to easily disable a user account and remove security groups.

Add-Pssnapin Microsoft.Exchange.Management.PowerShell.E2010
add-pssnapin -name "Quest.ActiveRoles.ADManagement"

#Prompt for Username 
$username = read-host -prompt "Please enter the username of the user to be deleted from the system."
Remove-QADObject $username
Write-Host -foregroundcolor green "The user's account has been deleted."



