#Create H: drive
$username = "gbromley"
$homefolder = "acltest"
$path = "\\corporate\proassurance\home\"
$newFolderFull = $path + $homefolder
New-Item $newFolderFull -ItemType Directory

#Set home folder permissions

$Acl = (Get-Item $newFolderFull).GetAccessControl('Access')
$AccessRule = New-Object System.Security.AccessControl.FileSystemAccessRule($Username, 'Modify','ContainerInherit,ObjectInherit', 'None', 'Allow')
$Acl.SetAccessRule($AccessRule)
Set-Acl -path $newFolderFull -AclObject $Acl