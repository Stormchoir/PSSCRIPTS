﻿#created by Mark Billington
#Script designed to easily create new mailboxes and user accounts. hurrah!
#NO VALIDATION IS CURRENTLY INCORPORATED, SCRIPT WILL FAIL IF USER ALREADY EXISTS

Add-PSSnapin -Name Quest.ActiveRoles.ADManagement

#Prompt for Username and Password
$firstname = read-host -prompt "Enter First Name"
$lastname = read-host -prompt "Enter Last Name"
$trust =  read-host -prompt "Domain1, Domain2 or Domain3"
$name=$lastname+" "+$firstname
$username=$firstname+"."+$lastname
$displayname=$name+" ("+$trust+")"
$password = read-host -assecurestring -prompt "Please enter a Password"


# Determine UPN suffix
if ($trust -eq "Domain1") { 
$domain = "@domain1.uk"
$attrib = " "
}
if ($trust -eq "Domain2") {
$domain = "@domain2.uk"
$attrib = "Attrib1"
}
if ($trust -eq "Domain3") {
$domain = "@domain3.uk"
$attrib = "Attrib2"
}

$upn=$username+$domain

#Pick Mailbox Databse and write mailbox databse vaule to variable
Write-Host ""
Write-Host -foregroundcolor Green "Please Pick a Mailbox Database"
Write-Host ""
Write-Host "0 - VIP User"
Write-Host "1 - StandardUsersA-C"
Write-Host "2 - StandardUsersD-F"
Write-Host "3 - StandardUsersG-I"
Write-Host "4 - StandardUsersJ-L"
Write-Host "5 - StandardUsersM-O"
Write-Host "6 - StandardUsersP-R"
Write-Host "7 - StandardUsersS-U"
Write-Host "8 - StandardUsersV-W"
Write-Host "9 - StandardUsersX-Z"
Write-Host ""
$mailnumber = read-host -prompt "Please Choose a number"

if ($mailnumber -eq "0") { 
$maildatabase = "MAIL\TCSUsers\VIPUsers"
}
if ($mailnumber -eq "1") { 
$maildatabase = "MAIL\StandardUsersA-C\StandardUsersA-C"
}
if ($mailnumber -eq "2") { 
$maildatabase = "MAIL\StandardUsersD-F\StandardUsersD-F"
}
if ($mailnumber -eq "3") { 
$maildatabase = "MAIL\StandardUsersG-I\StandardUsersG-I"
}
if ($mailnumber -eq "4") { 
$maildatabase = "MAIL\StandardUsersJ-L\StandardUsersJ-L"
}
if ($mailnumber -eq "5") { 
$maildatabase = "MAIL\StandardUsersM-O\StandardUsersM-O"
}
if ($mailnumber -eq "6") { 
$maildatabase = "MAIL\StandardUsersP-R\StandardUsersP-R"
}
if ($mailnumber -eq "7") { 
$maildatabase = "MAIL\StandardUsersS-U\StandardUsersS-U"
}
if ($mailnumber -eq "8") { 
$maildatabase = "MAIL\StandardUsersV-W\StandardUsersV-W"
}
if ($mailnumber -eq "9") { 
$maildatabase = "MAIL\StandardUsersX-Z\StandardUsersX-Z"
}


#Choose OU for AD account

Write-Host ""
Write-Host -foregroundcolor Green "Please Pick an OU for User Account"
Write-Host ""
Write-Host "1 - OU1"
Write-Host "2 - OU2"
Write-Host "3 - OU3"
Write-Host "4 - OU4"
Write-Host ""
$ounumber = read-host -prompt "Please Choose a number"

if ($ounumber -eq "1") { 
$ou = "DOMAIN/OU1"
$profilepath = "\\DATA-SERVER\Userprofiles$\"+$username
}
if ($ounumber -eq "2") { 
$ou = "DOMAIN/OU2"
}
if ($ounumber -eq "3") { 
$ou = "DOMAIN/OU3"
}
if ($ounumber -eq "4") { 
$ou = "DOMAIN/OU4"
}

#Create Mailbox and AD Account

New-Mailbox -DomainController DC1.DOMAIN -name $name -userprincipalname $upn -Alias $username -OrganizationalUnit $ou -FirstName $firstname -LastName $LastName -Password $password -ResetPasswordOnNextLogon $true -Database $maildatabase -DisplayName $displayname
Write-Host ""
Write-Host -foregroundcolor Blue "Mailbox Created"
Set-Mailbox -DomainController DOMAIN -Identity $upn -CustomAttribute10 $attrib
Write-Host ""
Write-Host -foregroundcolor Blue "Custom Attribute10 value added: " $attrib
Start-Sleep -s 10
Connect-QADService -Service DC1.DOMAIN
Set-QADUser -Identity $upn -ProfilePath $profilepath
Write-Host ""
Write-Host -foregroundcolor Blue "Profile Path set as: " $profilepath
if ($trust -eq "Domain1") { 
Add-QADGroupMember -Identity "Domain1 Common Security Group" -Member $username
}
if ($ounumber -eq "1") { 
Add-QADGroupMember -Identity "OU1 common security group" -Member $username
}


#Output Summery
Write-Host ""
Write-Host -foregroundcolor Green "User Summery"
Write-Host ""
Write-Host "Username= " $username
Write-Host "Alias = " $name
Write-Host "Display Name = " $displayname
Write-Host "UPN = " $upn
Write-Host "Mailbox Database = " $maildatabase
Write-Host "Custom Attribute = " $attrib
Write-Host "OU = " $ou
Write-Host ""
Start-Sleep -s 60
