$addressFile = "\\corporate\birmingham\information systems\OBData\addresses.csv"
$office = "Birmingham"
Import-Csv $addressFile|? Office -eq $office | Foreach-Object {
    foreach ($property in $_.PSObject.Properties)
    {
        Write-Host $property.Name, $property.Value
    } 
}
