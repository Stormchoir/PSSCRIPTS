$User=[System.Security.Principal.WindowsIdentity]::GetCurrent()
$User.Groups | ForEach-Object { $_.Translate([System.Security.Principal.NTAccount]).Value } | Sort-Object
