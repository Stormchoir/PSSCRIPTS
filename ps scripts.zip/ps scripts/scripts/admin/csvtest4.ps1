﻿$addressFile = "\\corporate\birmingham\information systems\OBData\addresses.csv"
$office = "Okemos"
$username='gtest@proassurance.com'

Import-Csv $addressFile |`
    Where-object {{$_.office -eq $office}
	$_.streetaddress -eq "$streetaddress"
	$_.city -eq "$city"
	$_.stateorprovince -eq "$state"
	$_.postalcode -eq "$zipcode"	
    }
