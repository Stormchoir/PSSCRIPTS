$addresscsv = import-csv "\\corporate\birmingham\information systems\OBData\addresses.csv"
$addresscsv | where-object {$_.office -eq "Okemos"
$_.StreetAddress=$Street
$_.City=$City
$_.StateorProvence=$State
$_.PostalCode=$Zipcode
$_.Country=$Country
}
write-host $Country