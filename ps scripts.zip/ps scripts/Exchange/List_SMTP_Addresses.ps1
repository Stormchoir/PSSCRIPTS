# -------------------------------------------------------------------------------
# Script: Get-AllEmailAddresses.ps1
# Author: Chris Brown http://www.flamingkeys.com/
# Date: 25/07/2011 00:03
# Keywords: Exchange, Email, SMTP
# comments:
#
# Versioning
# 25/07/2011  CJB  Initial Script
#
# -------------------------------------------------------------------------------
 
# Import the E2010 modules if available, otherwise import 2007's.
if (Get-PSSnapin Microsoft.Exchange.Management.PowerShell.E2010 -Registered -ErrorAction SilentlyContinue) {
    # Found 2010, add it
    Add-PSSnapin Microsoft.Exchange.Management.PowerShell.E2010
} else {
    # Add 2007
    Add-PSSnapin -Name Microsoft.Exchange.Management.PowerShell.Admin
}
 
# Create an object to hold the results
$addresses = @()
# Get every mailbox in the Exchange Organisation
$Mailboxes = Get-Mailbox -ResultSize Unlimited
 
# Recurse through the mailboxes
ForEach ($mbx in $Mailboxes) {
    # Recurse through every address assigned to the mailbox
    Foreach ($address in $mbx.EmailAddresses) {
        # If it starts with "SMTP:" then it's an email address. Record it
        if ($address.ToString().ToLower().StartsWith("smtp:")) {
            # This is an email address. Add it to the list
            $obj = "" | Select-Object Alias,EmailAddress
            $obj.Alias = $mbx.Alias
            $obj.EmailAddress = $address.ToString().SubString(5)
            $addresses += $obj
        }
    }
}
# Export the final object to a csv in the working directory
$addresses | Export-Csv addresses.csv -NoTypeInformation
# Open the csv with the default handler
Invoke-Item addresses.csv
