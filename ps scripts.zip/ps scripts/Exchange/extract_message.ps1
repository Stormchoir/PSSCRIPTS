Get-Message | where{$_.subject -like " ProAssurance / MAI / ProNational Xfer log : pull_cases"} | Export-Message | AssembleMessage c:\printin
g.eml