# Copyright (c) 2008 Microsoft Corporation. All rights reserved.  
# 
# THIS CODE IS MADE AVAILABLE AS IS, WITHOUT WARRANTY OF ANY KIND. THE ENTIRE RISK
# OF THE USE OR THE RESULTS FROM THE USE OF THIS CODE REMAINS WITH THE USER. 
#
# This script is used by Exchange Management Console only to aid filter out based on some conditions.
#    

$global:ConfirmPreference = "None"

# Get logon user identity
# 
# For the case of multi-domain topology which has the same prefix for the domain name, such as abc.com and abc.cn,
# userInfo.Identity.Name is not unique since it only contains the short domain name, for example abc\administrator.
# 
# So EMC uses the unique security identifier userInfo.WindowsIdentity.User to identify the user when the WindowsIdentity is available.
function global:Get-LogonUserIdentity ()
{
	$senderInfo = (Get-Variable PSSenderInfo).Value
    if (($senderInfo -eq $null) -or ($senderInfo.UserInfo -eq $null))
    {
        throw 'Could not retrieve the information of the user making the call'
    }

    $sid = [Microsoft.Exchange.Configuration.Authorization.ExchangeAuthorizationPlugin]::GetExecutingUserSecurityIdentifier($senderInfo.UserInfo, $senderInfo.ConnectionString) 
	
	$sid.ToString()
}

# Get logon user
function global:Get-LogonUser ()
{
	BEGIN
	{
		set-variable VerbosePreference -value SilentlyContinue
	}	
	PROCESS 
	{
		Set-ADServerSettings -ViewEntireForest:$true
		Get-User (Get-LogonUserIdentity)
	}
}

# Get ManagementRoleAssignment for logon user
function global:Get-ManagementRoleAssignmentForLogonUser ()
{
	BEGIN
	{
		set-variable VerbosePreference -value SilentlyContinue
	}	
	PROCESS 
	{
		Set-ADServerSettings -ViewEntireForest:$true
		Get-ManagementRoleAssignment -RoleAssignee (Get-LogonUserIdentity)
	}
}

# Get ManagementRole for logon user
function global:Get-ManagementRoleForLogonUser ()
{
	BEGIN
	{
		set-variable VerbosePreference -value SilentlyContinue
	}	
	PROCESS 
	{
		Set-ADServerSettings -ViewEntireForest:$true
		foreach ($o in Get-ManagementRoleAssignment -RoleAssignee (Get-LogonUserIdentity))
		{
			$o.Role | Get-ManagementRole
		}
	}
}

# Get ManagementScope for logon user
function global:Get-ManagementScopeForLogonUser ()
{
	BEGIN
	{
		set-variable VerbosePreference -value SilentlyContinue
	}
	PROCESS 
	{
		Set-ADServerSettings -ViewEntireForest:$true
		
		$scopes = @{}
		foreach ($o in Get-ManagementRoleAssignment -RoleAssignee (Get-LogonUserIdentity))
		{
			If ($o.CustomRecipientWriteScope -ne $null -and !$scopes.ContainsKey($o.CustomRecipientWriteScope))
			{
				$scopes.add($o.CustomRecipientWriteScope, $null)
				$o.CustomRecipientWriteScope | Get-ManagementScope -ErrorAction SilentlyContinue
			}

			If ($o.CustomConfigWriteScope -ne $null -and !$scopes.ContainsKey($o.CustomConfigWriteScope ))
			{
				$scopes.add($o.CustomConfigWriteScope , $null)
				$o.CustomConfigWriteScope | Get-ManagementScope -ErrorAction SilentlyContinue
			}
		}
	}
}

# Get Exclusive ManagementScope for logon user
function global:Get-ExclusiveManagementScopeForLogonUser ()
{
	BEGIN
	{
		set-variable VerbosePreference -value Continue
	}	
	PROCESS 
	{
		Get-ManagementScope -Exclusive:$true
	}
}

# Get ADServerSettings for logon user
# The reason to write this wrapper is that we cannot public the Get-ADServerSettings to any user
# without a role assignment, otherwise it won't pass the check during setting Rbac Scope in task.cs.
function global:Get-ADServerSettingsForLogonUser ()
{
	BEGIN
	{
		set-variable VerbosePreference -value SilentlyContinue
	}	
	PROCESS 
	{
		Get-ADServerSettings
	}
}


# Set ADServerSettings for logon user
# The reason to write this wrapper is that we cannot public the Get-ADServerSettings to any user
# without a role assignment, otherwise it won't pass the check during setting Rbac Scope in task.cs.
function global:Set-ADServerSettingsForLogonUser ([object]$RunspaceServerSettings)
{
	BEGIN
	{
		set-variable VerbosePreference -value SilentlyContinue
	}	
	PROCESS 
	{
		Set-ADServerSettings -RunspaceServerSettings $RunspaceServerSettings
	}
}

# Filter out object which NameProperty equals an input SearchText
function global:Filter-PropertyStringContains ([string]$Property, [string]$SearchText)
{
	BEGIN
	{
		set-variable VerbosePreference -value Continue
	}	
	PROCESS 
	{
		:connectScope do
		{	
			$_ | where-object {$_.$Property.ToString().ToUpper().Contains($SearchText.ToUpper())} 		
		}
		while ($false) #connectScope
	}
}

# Filter out object wich $Property not contains $SearchText
function global:Filter-PropertyStringNotContains ([string]$Property, [string]$SearchText)
{
	BEGIN
	{
		set-variable VerbosePreference -value Continue
	}	
	PROCESS 
	{
		:connectScope do
		{	
			$_ | where-object {$_.$Property.ToString().ToUpper().Contains($SearchText.ToUpper()) -eq $false} 		
		}
		while ($false) #connectScope
	}
}

# Sort the pipeline objects with specified property
function global:Sort-Objects ([string]$Property)
{
	BEGIN
	{
		set-variable VerbosePreference -value Continue
	}	
	PROCESS 
	{
		:connectScope do
		{	
			$_ | Sort-Object -Property $Property
		}
		while ($false) #connectScope
	}
}

# Equal to
function global:Filter-PropertyEqualTo ([string]$Property, [object]$Value=$null)
{
	BEGIN
	{
		set-variable VerbosePreference -value Continue
	}	
	PROCESS 
	{
		:connectScope do
		{	
			$_ | where-object {$_.$Property -eq $Value} 		
		}
		while ($false) #connectScope
	}
}

# Not Equal to
function global:Filter-PropertyNotEqualTo ([string]$Property, [object]$Value=$null)
{
	BEGIN
	{
		set-variable VerbosePreference -value Continue
	}	
	PROCESS 
	{
		:connectScope do
		{	
			$_ | where-object {$_.$Property -ne $Value} 		
		}
		while ($false) #connectScope
	}
}

# Equal or Greater Than
function global:Filter-PropertyEqualOrGreaterThan ([string]$Property, [object]$Value=$null)
{
	BEGIN
	{
		set-variable VerbosePreference -value Continue
	}	
	PROCESS 
	{
		:connectScope do
		{	
			$_ | where-object {$_.$Property -ge $Value} 		
		}
		while ($false) #connectScope
	}
}

# Filter out recipients without primary smtp address
function global:Filter-Recipient ()
{
	BEGIN
	{
		set-variable VerbosePreference -value Continue
	}	
	PROCESS 
	{
		:connectScope do
		{	
			$_ | where-object {$_.PrimarySmtpAddress.Length -ne 0} 		
		}
		while ($false) #connectScope
	}
}

# Resolve a bunch of objects 
function global:Filter-PropertyInObjects ([string]$ResolveProperty, [string[]]$inputObjects = $null)
{
	BEGIN
	{
		set-variable VerbosePreference -value Continue
	}	
	PROCESS 
	{
		:connectScope do
		{	
			if ($inputObjects -eq $null)
			{
				return
			}
			
			if ($inputObjects -contains $_.$ResolveProperty)
			{
				$_
			}
		}
		while ($false) #connectScope
	}
}

# Will be removed with Delegation Feature
function global:Filter-Delegation ()
{
	BEGIN
	{
		set-variable VerbosePreference -value Continue
	}	
	PROCESS 
	{
		:connectScope do
		{
			# All Delegation feature will be cut soon.
			$_ 
		}
		while ($false) #connectScope
	}
}

# Filter mailboxes which version equal or greater than the specific
function global:Filter-Mailbox ([object]$Value=$null)
{
	BEGIN
	{
		set-variable VerbosePreference -value Continue
	}	
	PROCESS 
	{
		:connectScope do
		{	
			$_ | where-object {$_.ExchangeVersion.ToInt64() -ge $Value} 		
		}
		while ($false) #connectScope
	}
}

# Specific Filter for DatabaseMaster Picker to get all Databases or Master of its DatabaseCopies
function global:Filter-DatabaseMasterServer ()
{
	BEGIN
	{
		set-variable VerbosePreference -value Continue
	}	
	PROCESS 
	{
		:connectScope do
		{				
			foreach ($copy in $_.DatabaseCopies)
			{
				$copy.HostServerName | Get-ExchangeServer
			}

		}
		while ($false) #connectScope
	}
}

# Specific Filter for ServersInSameDag Picker to get servers in the same DAG as $dagMemberServer
function global:Filter-ServersInSameDag ([string]$dagMemberServer)
{
	BEGIN
	{
		set-variable VerbosePreference -value Continue
	}	
	PROCESS 
	{
		:connectScope do
		{		
			if ($_.Servers -Contains $dagMemberServer)
			{
				foreach ($server in $_.Servers)
				{
					if ($server -ne $dagMemberServer)
					{
						$server | Get-ExchangeServer
					}
				}
			}
		}
		while ($false) #connectScope
	}
}

# Get all PublicFolder Installed Exchange Server
function global:Filter-PublicFolderInstalledExchangeServer ([int]$minVersion = 8, [string]$excludeServer = $null)
{
	BEGIN
	{
		set-variable VerbosePreference -value Continue
	}	
	PROCESS 
	{
		:connectScope do
		{	
			if ($_.Server -eq $excludeServer)
			{
				return
			}
			else
			{
				$_.Server | Get-ExchangeServer | where-object {$_.AdminDisplayVersion.Major -ge $minVersion} 		
			}
		}
		while ($false) #connectScope
	}
}

# Filter for ExchangeCertificate picker
function global:Filter-ExchangeCertificate ([object]$isSelfSigned, [object]$hasKeyIdentifier, [object]$privateKeyExportable, [object]$status)
{
    BEGIN
    {
        set-variable VerbosePreference -value Continue
    }
    PROCESS
    {
        :connectScope do
        {
            if (($status -eq $null -or $_.Status -eq $status) -and ($isSelfSigned -eq $null -or $_.IsSelfSigned -eq $isSelfSigned) -and ($hasKeyIdentifier -eq $null -or [string]::IsNullOrEmpty($_.KeyIdentifier) -ne $hasKeyIdentifier) -and ($privateKeyExportable -eq $null -or $_.PrivateKeyExportable -eq $privateKeyExportable))
            {
                $_
            }
        }
        while ($false) #connectScope
    }
}

# A generic ExchangeServer Filter for all ExchangeServer Pickers
function global:Filter-ExchangeServer ([int]$minVersion = 8, [int]$maxVersion = 2147483647, [string[]]$serverRoles, [switch]$includeLegacyServer, [switch]$backendServerOnly, [string[]]$excludedServers, [Microsoft.Exchange.Data.ExchangeBuild]$exactVersion)
{
	BEGIN
	{
		set-variable VerbosePreference -value Continue
	}	
	PROCESS 
	{
		:connectScope do
		{	
			if ($excludedServers -contains $_.Identity)
			{
				return
			}
			
			if ($includeLegacyServer -and $_.AdminDisplayVersion.Major -lt 8)
			{
				# only return backend server
				if ($backenServerOnly -and ($_.ExchangeLegacyServerRole -ne 0))
				{
					return
				}
				
				$_
			}
			else
			{
				$targetServerRole = $false
				foreach($role in $serverRoles)
				{
					if ($_.ServerRole -like '*'+$role+'*')
					{
						$targetServerRole = $true
					}
				}
			
				if ($targetServerRole -and $_.AdminDisplayVersion.Major -ge $minVersion -and $_.AdminDisplayVersion.Major -le $maxVersion)
				{
					if ($exactVersion -ne $null)
					{
						if (($_.AdminDisplayVersion.Major -eq $exactVersion.Major) -and ($_.AdminDisplayVersion.Minor -eq $exactVersion.Minor) -and ($_.AdminDisplayVersion.Build -eq $exactVersion.Build))
						{
							$_
						}
					}
					else
					{
						$_
					}
				}
			}
		}
		while ($false) #connectScope
	}
}
# SIG # Begin signature block
# MIIdsAYJKoZIhvcNAQcCoIIdoTCCHZ0CAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQULbZM91bgPH+uwSOWYDXwxYVv
# r86gghhqMIIE2jCCA8KgAwIBAgITMwAAAQdjpRkqESfl2QAAAAABBzANBgkqhkiG
# 9w0BAQUFADB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEw
# HwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwHhcNMTgwODIzMjAyMDI2
# WhcNMTkxMTIzMjAyMDI2WjCByjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAldBMRAw
# DgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24x
# LTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJhdGlvbnMgTGltaXRlZDEm
# MCQGA1UECxMdVGhhbGVzIFRTUyBFU046QUI0MS00QjI3LUYwMjYxJTAjBgNVBAMT
# HE1pY3Jvc29mdCBUaW1lLVN0YW1wIHNlcnZpY2UwggEiMA0GCSqGSIb3DQEBAQUA
# A4IBDwAwggEKAoIBAQCx4jFPYPLORcJ9TE+rvtOh7IQ4/db/zAzVBmzhKIcvrg0l
# fI61buwA3740F66FFMqxZgMedFov74GNlZ/7y6eIiy1pVdQown+yA+EnB8lEVvKE
# H0J1xReHlQAJr11l/zzjHux30VkA/BBOLfe9uZ+CLAP8F1Wt/aZAkTuxC4rdYSJt
# WGcTyiSyR50fPLtEZqyihPi7g/dJB7R4BCCL/pO7trsI/AA98LSHcOydoGmO852f
# KgtAEV0NbZyVphn+c/5H3qPHcifpB/D47n43wUXkjgrqLlgqdm1Op8fuTNlrHoRV
# 1NBfB8v/zK7RrYP4oVEztN29akvlxUzl062e/oGLAgMBAAGjggEJMIIBBTAdBgNV
# HQ4EFgQUj3Lnp1uB5EjhiEY9QThjCuJYBoowHwYDVR0jBBgwFoAUIzT42VJGcArt
# QPt2+7MrsMM1sw8wVAYDVR0fBE0wSzBJoEegRYZDaHR0cDovL2NybC5taWNyb3Nv
# ZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljcm9zb2Z0VGltZVN0YW1wUENBLmNy
# bDBYBggrBgEFBQcBAQRMMEowSAYIKwYBBQUHMAKGPGh0dHA6Ly93d3cubWljcm9z
# b2Z0LmNvbS9wa2kvY2VydHMvTWljcm9zb2Z0VGltZVN0YW1wUENBLmNydDATBgNV
# HSUEDDAKBggrBgEFBQcDCDANBgkqhkiG9w0BAQUFAAOCAQEAVTCQ9vD8tkOVyPlU
# Na4Y3EfCkpzjliJMKA0uaRy2igxvK4KWoIUTMi4l+fgiVU6ugnn9/meg+COBw2M6
# XmX/+2j57RQgYXcTK5McXlszt3tzvSp2age1sOKPNtfzdxzUgDl1Sh4a8KZf82nJ
# 5mbWe41sVDIHSCSUftMZG+3a8w98HIp7J/upmmpD+K4n/uaYB+UmIWVusJkD9Afv
# IrJAjXWCIYxbIjKnzOMy5JMCoZYGY5npi7u99/Ku/WvsJWtjRC2UxZvMSA5B2YEv
# xvFpKv9qCzbmv/C9fbyhEFO2aLoKpwx97B7PxC50Y9dVtPg6TRWOEeGEopv24YLw
# sBIGlDCCBf8wggPnoAMCAQICEzMAAAEDXiUcmR+jHrgAAAAAAQMwDQYJKoZIhvcN
# AQELBQAwfjELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYG
# A1UEAxMfTWljcm9zb2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMTAeFw0xODA3MTIy
# MDA4NDhaFw0xOTA3MjYyMDA4NDhaMHQxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpX
# YXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQg
# Q29ycG9yYXRpb24xHjAcBgNVBAMTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjCCASIw
# DQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBANGUdjbmhqs2/mn5RnyLiFDLkHB/
# sFWpJB1+OecFnw+se5eyznMK+9SbJFwWtTndG34zbBH8OybzmKpdU2uqw+wTuNLv
# z1d/zGXLr00uMrFWK040B4n+aSG9PkT73hKdhb98doZ9crF2m2HmimRMRs621TqM
# d5N3ZyGctloGXkeG9TzRCcoNPc2y6aFQeNGEiOIBPCL8r5YIzF2ZwO3rpVqYkvXI
# QE5qc6/e43R6019Gl7ziZyh3mazBDjEWjwAPAf5LXlQPysRlPwrjo0bb9iwDOhm+
# aAUWnOZ/NL+nh41lOSbJY9Tvxd29Jf79KPQ0hnmsKtVfMJE75BRq67HKBCMCAwEA
# AaOCAX4wggF6MB8GA1UdJQQYMBYGCisGAQQBgjdMCAEGCCsGAQUFBwMDMB0GA1Ud
# DgQWBBRHvsDL4aY//WXWOPIDXbevd/dA/zBQBgNVHREESTBHpEUwQzEpMCcGA1UE
# CxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMgUHVlcnRvIFJpY28xFjAUBgNVBAUTDTIz
# MDAxMis0Mzc5NjUwHwYDVR0jBBgwFoAUSG5k5VAF04KqFzc3IrVtqMp1ApUwVAYD
# VR0fBE0wSzBJoEegRYZDaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9j
# cmwvTWljQ29kU2lnUENBMjAxMV8yMDExLTA3LTA4LmNybDBhBggrBgEFBQcBAQRV
# MFMwUQYIKwYBBQUHMAKGRWh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMv
# Y2VydHMvTWljQ29kU2lnUENBMjAxMV8yMDExLTA3LTA4LmNydDAMBgNVHRMBAf8E
# AjAAMA0GCSqGSIb3DQEBCwUAA4ICAQCf9clTDT8NJuyiRNgN0Z9jlgZLPx5cxTOj
# pMNsrx/AAbrrZeyeMxAPp6xb1L2QYRfnMefDJrSs9SfTSJOGiP4SNZFkItFrLTuo
# LBWUKdI3luY1/wzOyAYWFp4kseI5+W4OeNgMG7YpYCd2NCSb3bmXdcsBO62CEhYi
# gIkVhLuYUCCwFyaGSa/OfUUVQzSWz4FcGCzUk/Jnq+JzyD2jzfwyHmAc6bAbMPss
# uwculoSTRShUXM2W/aDbgdi2MMpDsfNIwLJGHF1edipYn9Tu8vT6SEy1YYuwjEHp
# qridkPT/akIPuT7pDuyU/I2Au3jjI6d4W7JtH/lZwX220TnJeeCDHGAK2j2w0e02
# v0UH6Rs2buU9OwUDp9SnJRKP5najE7NFWkMxgtrYhK65sB919fYdfVERNyfotTWE
# cfdXqq76iXHJmNKeWmR2vozDfRVqkfEU9PLZNTG423L6tHXIiJtqv5hFx2ay1//O
# kpB15OvmhtLIG9snwFuVb0lvWF1pKt5TS/joynv2bBX5AxkPEYWqT5q/qlfdYMb1
# cSD0UaiayunR6zRHPXX6IuxVP2oZOWsQ6Vo/jvQjeDCy8qY4yzWNqphZJEC4Omek
# B1+g/tg7SRP7DOHtC22DUM7wfz7g2QjojCFKQcLe645b7gPDHW5u5lQ1ZmdyfBrq
# UvYixHI/rjCCBgcwggPvoAMCAQICCmEWaDQAAAAAABwwDQYJKoZIhvcNAQEFBQAw
# XzETMBEGCgmSJomT8ixkARkWA2NvbTEZMBcGCgmSJomT8ixkARkWCW1pY3Jvc29m
# dDEtMCsGA1UEAxMkTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# MB4XDTA3MDQwMzEyNTMwOVoXDTIxMDQwMzEzMDMwOVowdzELMAkGA1UEBhMCVVMx
# EzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoT
# FU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEhMB8GA1UEAxMYTWljcm9zb2Z0IFRpbWUt
# U3RhbXAgUENBMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAn6Fssd/b
# SJIqfGsuGeG94uPFmVEjUK3O3RhOJA/u0afRTK10MCAR6wfVVJUVSZQbQpKumFww
# JtoAa+h7veyJBw/3DgSY8InMH8szJIed8vRnHCz8e+eIHernTqOhwSNTyo36Rc8J
# 0F6v0LBCBKL5pmyTZ9co3EZTsIbQ5ShGLieshk9VUgzkAyz7apCQMG6H81kwnfp+
# 1pez6CGXfvjSE/MIt1NtUrRFkJ9IAEpHZhEnKWaol+TTBoFKovmEpxFHFAmCn4Tt
# VXj+AZodUAiFABAwRu233iNGu8QtVJ+vHnhBMXfMm987g5OhYQK1HQ2x/PebsgHO
# IktU//kFw8IgCwIDAQABo4IBqzCCAacwDwYDVR0TAQH/BAUwAwEB/zAdBgNVHQ4E
# FgQUIzT42VJGcArtQPt2+7MrsMM1sw8wCwYDVR0PBAQDAgGGMBAGCSsGAQQBgjcV
# AQQDAgEAMIGYBgNVHSMEgZAwgY2AFA6sgmBAVieX5SUT/CrhClOVWeSkoWOkYTBf
# MRMwEQYKCZImiZPyLGQBGRYDY29tMRkwFwYKCZImiZPyLGQBGRYJbWljcm9zb2Z0
# MS0wKwYDVQQDEyRNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHmC
# EHmtFqFKoKWtTHNY9AcTLmUwUAYDVR0fBEkwRzBFoEOgQYY/aHR0cDovL2NybC5t
# aWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvbWljcm9zb2Z0cm9vdGNlcnQu
# Y3JsMFQGCCsGAQUFBwEBBEgwRjBEBggrBgEFBQcwAoY4aHR0cDovL3d3dy5taWNy
# b3NvZnQuY29tL3BraS9jZXJ0cy9NaWNyb3NvZnRSb290Q2VydC5jcnQwEwYDVR0l
# BAwwCgYIKwYBBQUHAwgwDQYJKoZIhvcNAQEFBQADggIBABCXisNcA0Q23em0rXfb
# znlRTQGxLnRxW20ME6vOvnuPuC7UEqKMbWK4VwLLTiATUJndekDiV7uvWJoc4R0B
# hqy7ePKL0Ow7Ae7ivo8KBciNSOLwUxXdT6uS5OeNatWAweaU8gYvhQPpkSokInD7
# 9vzkeJkuDfcH4nC8GE6djmsKcpW4oTmcZy3FUQ7qYlw/FpiLID/iBxoy+cwxSnYx
# PStyC8jqcD3/hQoT38IKYY7w17gX606Lf8U1K16jv+u8fQtCe9RTciHuMMq7eGVc
# WwEXChQO0toUmPU8uWZYsy0v5/mFhsxRVuidcJRsrDlM1PZ5v6oYemIp76KbKTQG
# dxpiyT0ebR+C8AvHLLvPQ7Pl+ex9teOkqHQ1uE7FcSMSJnYLPFKMcVpGQxS8s7Ow
# TWfIn0L/gHkhgJ4VMGboQhJeGsieIiHQQ+kr6bv0SMws1NgygEwmKkgkX1rqVu+m
# 3pmdyjpvvYEndAYR7nYhv5uCwSdUtrFqPYmhdmG0bqETpr+qR/ASb/2KMmyy/t9R
# yIwjyWa9nR2HEmQCPS2vWY+45CHltbDKY7R4VAXUQS5QrJSwpXirs6CWdRrZkocT
# dSIvMqgIbqBbjCW/oO+EyiHW6x5PyZruSeD3AWVviQt9yGnI5m7qp5fOMSn/DsVb
# XNhNG6HY+i+ePy5VFmvJE6P9MIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCBLAwggSsAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAAEDXiUcmR+jHrgAAAAAAQMwCQYFKw4DAhoFAKCB
# xDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgorBgEEAYI3AgELMQ4wDAYK
# KwYBBAGCNwIBFTAjBgkqhkiG9w0BCQQxFgQUsV6DANbm8KBVIpq/0XKrlfCO27sw
# ZAYKKwYBBAGCNwIBDDFWMFSgLIAqAEMAbwBuAHMAbwBsAGUASQBuAGkAdABpAGEA
# bABpAHoAZQAuAHAAcwAxoSSAImh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9leGNo
# YW5nZSAwDQYJKoZIhvcNAQEBBQAEggEATO/K2nKoxljGXqThGSO/w4Tw0NSB/I0G
# LwwNvjd5pbA11wrRTd9NnRDGzQsXST5SBkd26Uv8zmj7Tn/Zhtp5nkynq1mjHsoz
# sSpIury+Uy91hWQQTto+oAP9afcHAKuBcU5TIkPFCiizQgN5dbhrU9ywQQLLWY/1
# 3Cuk/gJi3PI5DxvQBNDHlq0VYOurcnYc9AQP/pnAd+jLAtXu7o9oGXt6Yvwi0IHe
# w4oRzyCW/ONtqfHrB7XY5R/Z2wA95Dq3X17p5WaeO83+GSjnhHV+/e5nR6RcUF6k
# b8IQnoEQ12ILZ6nxUBRfXaSq+Kh7Nkvu3OIFi5qRet9r2ePcvcoeuqGCAigwggIk
# BgkqhkiG9w0BCQYxggIVMIICEQIBATCBjjB3MQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMSEwHwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQ
# Q0ECEzMAAAEHY6UZKhEn5dkAAAAAAQcwCQYFKw4DAhoFAKBdMBgGCSqGSIb3DQEJ
# AzELBgkqhkiG9w0BBwEwHAYJKoZIhvcNAQkFMQ8XDTE5MDIwMjIyMDIxMVowIwYJ
# KoZIhvcNAQkEMRYEFKmP0vhAREQt4EswFAZ5hRjVdxpFMA0GCSqGSIb3DQEBBQUA
# BIIBAFUz7PEThgXqvWebMgn+h1gAIn5JdszoBXcm05B71FtfXjr4K1/Mhyr+2AMk
# CtnIyANhRO9na1lv9V+ERxlMIMu4qoTsbyGSlDv+TQOuxytP5LbBN2SDXUJjYkb8
# LpNZ9fXB+oRPUVT5dlJlIWHa42rb64lRtucEORHQvbNBeVSKbxZbb5wUS7RyYNdb
# rCHZi/qgqMyK3jWBxmJ3q+RoPrAkIsOW9YoXfXp/F3mEt9+4foSnNDAzczF+LbPn
# D3pgmGsaESB2wvjplT6upTVi77/2sTFXRwMEdDapVrly3+y63WMkEboC8XlBl5Vk
# wqrvqGhKXEfRixVKdYPb/Ajchqw=
# SIG # End signature block
