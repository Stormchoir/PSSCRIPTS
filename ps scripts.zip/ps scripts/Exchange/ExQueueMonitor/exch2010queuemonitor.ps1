﻿# Script:    Exch2010QueueMonitor.ps1 
# Purpose:  This script can be set as a scheduled task to run every 30minutes and will monitor all exchange 2010 queue's. If a threshold of 10 is met an  
#            output file with the queue details will be e-mailed to all intended admins listed in the e-mail settings 
# Comments: Lines 27, 31-35 should be populated with your own e-mail settings 
# Notes:     
#            - tested with Exchange 2010 SP1 
#            - The log report output file will be created under "c:\temp\qu.txt" 
 
#$s = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri http://pro-bhm-exch1/PowerShell/ -Authentication Kerberos 
#Import-PSSession $s 
 
Add-PSSnapin Microsoft.Exchange.Management.PowerShell.E2010 
. $env:ExchangeInstallPath\bin\RemoteExchange.ps1 
Connect-ExchangeServer -auto 
 
$filename = “c:\temp\qu.txt” 
Start-Sleep -s 10 
if (Get-ExchangeServer | Where { $_.isHubTransportServer -eq $true } | get-queue | Where-Object { $_.MessageCount -gt 100 }) 
 
{ 
 
Get-ExchangeServer | Where { $_.isHubTransportServer -eq $true } | get-queue | Where-Object { $_.MessageCount -gt 100} | Format-Table -Wrap -AutoSize | out-file -filepath c:\temp\qu.txt 
Start-Sleep -s 10 
 
$smtpServer = "mail.proassurance.com"
$msg = new-object Net.Mail.MailMessage 
$att = new-object Net.Mail.Attachment($filename) 
$smtp = new-object Net.Mail.SmtpClient($smtpServer) 
$msg.From = “transport@proassurance.com” 
$msg.To.Add("exchangeadmin@proassurance.com") 
#$msg.To.Add("gjackson@proassurance.com") 
#$msg.To.Add("gbromley@proassurance.com") 
#$msg.To.Add("admin4@mycompany.com") 
$msg.Subject = “Attention Exchange Admin:  A Queue on pro-bhm-exch1 has reached 100.” 
$msg.Body = “Please see attached queue log file for queue information.  Please run get-queue from the shell or open the queue viewer in the Exchange Toolbox (on one of the 2016 servers) and restart the transport service if queue is hung. If the it's part of Shadow Redundancy, then it is "ok" but watch it to make sure it doesn't grow out of control and is not going down.  Thanks.” 
$msg.Attachments.Add($att) 
$smtp.Send($msg) 
 
}