﻿#Title: New user onboarding script

#Set-ExecutionPolicy bypass


#Purpose: Creation of user accounts across all lines of business.
#Currently supports Corp, HCPL, and Medmarc.
#
#Author: Greg Bromley
#
#Setup:
#1. Install active directory powershell module.

param(
	[string]$FirstName='',
	[string]$PreferredName='',
	[string]$MiddleName='',
	[string]$LastName='',
    [string]$UserName='',
    [string]$HireType='',
    [string]$JobTitle='',
	[string]$LineOfBusiness='',
	[string]$Office='',
	[string]$Department='',
	[string]$Laptop=''
)

#$firstname = "Sam"
#$preferredName = "Sam"
#$lastname = "Test"
#$username = "SamTest"
#$hireType = "Full Time Employee"
#$jobtitle = "Test User Account"
#$lineofbusiness = "Corporate"
#$office = "Okemos"
#$department = "Claims"
#$laptop = "yes"
# Import the necessary modules

#Add-PSSnapin *Exchange*

#$PSVersionTable.PSVersion

#Establish a session with Exchange
$Session = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri http://mail.proassurance.com:81/PowerShell/ -Authentication Kerberos 
Import-PSSession $session -AllowClobber 
Import-Module ActiveDirectory -DisableNameChecking

# we take data from 3 CSV files to build overall profile for users to import into AD
try {
     $OfficeLocationCSV = Import-Csv "\\corporate.local\appdata\temp\onboarding\addresses.csv" -ErrorAction Stop
     $ADOUCSV = Import-Csv "\\corporate.local\appdata\onboarding\ADOUCSV.csv" -ErrorAction Stop
     $ExchmailboxDB = Import-Csv "\\corporate.local\appdata\onboarding\mailboxdb.csv" -ErrorAction Stop
}
catch {
        write-host $_.exception.itemname -ForegroundColor Red
        Write-Host $_.exception.message -Foregroundcolor Yellow
    }

# this is the user-specific data we'll be using to create the new account
#$CSVData = Import-Csv "\\corporate.local\birmingham\information systems\obdata\NewUserImport.csv"

#Start foreach loop
#ForEach ( $Line in $CSVData ) {
    
    #Pull Office Info from refrence sheet
    $OfficeInfo = $OfficeLocationCSV | Where-Object { $_.office -eq $Office }
    
    #Pull OU Info from reference sheet
    $ouinfo = $adoucsv | Where-Object { ($_.office -eq $Office) -and ($_.Department -eq $Department) -and ($_.LineOfBusiness -eq $LineofBusiness)}

    if (!$ouinfo)
    {
        $ouinfo = $adoucsv | Where-Object { ($_.office -eq "Default") -and ($_.Department -eq "Default") -and ($_.LineOfBusiness -eq $LineofBusiness)}
    }

    #Pull mailbox database from reference sheet
    $maildatabase = $ExchmailboxDB | Where-Object { ($_.Office -eq $Office) } -ErrorAction Stop
        
    #Define account attributes
    $Displayname = $LastName+", "+$PreferredName
    $Name = $LastName+", "+$PreferredName
    $username = $UserName.tolower()
    $upn = $username+'@proassurance.com'
    $Password = 'qWbQ?FR!*3X!'
    $password = convertTo-SecureString $Password -AsPlainText -Force
    $laptop = $Laptop
    $hireType = $HireType
    $lineOfBusiness = $LineOfBusiness
   
    #Create mailbox and user account
    #New-Mailbox -name $Name -userprincipalname $upn -Alias $username -OrganizationalUnit $ouinfo.ou -FirstName $PreferredName -LastName $LastName -Password $Password -ResetPasswordOnNextLogon $true -Database $maildatabase.MailDB -DisplayName $displayname -ErrorAction Stop
    #New-Mailbox -name $Name -userprincipalname $upn -Alias $username -OrganizationalUnit $ouinfo.ou -FirstName $PreferredName -LastName $LastName -Password $Password -ResetPasswordOnNextLogon $true -Database $maildatabase.MailDB -DisplayName $displayname -ErrorAction Stop
    try {
       New-Mailbox -name $Name -userprincipalname $upn -Alias $username -OrganizationalUnit $ouinfo.ou -FirstName $PreferredName -LastName $LastName -Password $Password -ResetPasswordOnNextLogon $true -Database $maildatabase.MailDB -DisplayName $displayname -ErrorAction Stop
    }
    catch {
        write-host $_.exception.itemname -ForegroundColor Red
        Write-Host $_.exception.message -Foregroundcolor Yellow
    }
    
    Start-Sleep -s 60

    #Set user account properties
    Try{
    Set-ADUser -identity $username -Street $officeinfo.StreetAddress -City $officeinfo.City -State $OfficeInfo.StateorProvence -Postalcode $officeinfo.PostalCode -Title $JobTitle -Description $Department -Office $Office -Department ($Department+" "+$lineOfBusiness+" "+$Office) -Company $lineOfBusiness -erroraction stop
    Set-ADUser -identity $username -Add @{ProxyAddresses="SIP:"+$upn} -erroraction stop
    Set-ADUser -identity $username -Add @{'msRTCSIP-PrimaryUserAddress' = "SIP:"+$upn} -erroraction stop
    if (!$MiddleName -or $MiddleName -eq "")
    {
        Set-ADUser -identity $username -Add @{'ExtensionAttribute1' = $LastName+", "+$FirstName} -erroraction stop
    }
    else {
        Set-ADUser -identity $username -Add @{'ExtensionAttribute1' = $LastName+", "+$FirstName+" "+$MiddleName} -erroraction stop
        Set-ADUser -identity $username -Add @{'middleName' = $MiddleName} -erroraction stop
    }

    if($lineOfBusiness -eq 'Corporate' -or $lineOfBusiness -eq 'HCPL')
    {
        Set-ADUser -identity $username -ScriptPath "global_12.vbs" -erroraction stop
    }
    }
    Catch {
            write-host $_.exception.itemname -ForegroundColor Red
            Write-Host $_.exception.message -Foregroundcolor Yellow
    }
    

    #### Begin Group Memberships
    Try{
    Add-ADGroupMember -identity ('DUO Users') -members $username -ErrorAction stop
    Add-ADGroupMember -identity ('FW - HTTP_HTTPS Access') -members $username -ErrorAction stop

    if ($hireType -eq 'Employee') {
        Add-ADGroupMember -identity ('Security Awareness-1917428525') -members $username -ErrorAction stop    
    }
    elseif ($hireType -eq 'Contractor' -or $hireType -eq 'Temp') {
        Add-ADGroupMember -identity ('Security Awareness - Contractors-1-1529746647') -members $username  -ErrorAction stop   
    }

    if ($laptop -eq 'Yes') {
        Add-ADGroupMember -identity ('ADM_LAPTOP_USERS') -members $username -ErrorAction stop
        
        if ($Office -eq 'Chantilly') {
            Add-ADGroupMember -identity ('FW - GlobalProtect Chantilly') -members $username -ErrorAction stop
        }
        elseif ($Office -eq 'Franklin') {
            Add-ADGroupMember -identity ('FW - GlobalProtect Franklin') -members $username -ErrorAction stop
        }
        elseif ($Office -eq 'Lancaster') {
            Add-ADGroupMember -identity ('FW - GlobalProtect Lancaster') -members $username -ErrorAction stop
        }
        else {
            Add-ADGroupMember -identity ('FW - GlobalProtect Birmingham') -members $username -ErrorAction stop
        }
    }
    
    if ($lineOfBusiness -eq 'Corporate' -or $lineOfBusiness -eq 'HCPL')
    {
        $ADMGroup = 'ADM_'+$OfficeInfo.Abbreviation+'_'+$Department.replace(' ','')
        $ADMGroup = $ADMGroup.replace('ISCorporate','INFORMATIONSYSTEMS')

        Add-ADGroupMember -identity ($ADMGroup) -members $username -ErrorAction stop
    }
    }
      Catch {
            write-host $_.exception.itemname -ForegroundColor Red
            Write-Host $_.exception.message -Foregroundcolor Yellow
    }
    

    #### End Group Memberships

    #Configure Mailbox Properties
    Set-CasMailbox -ActiveSyncEnabled $false -PopEnabled $false -ImapEnabled $false -Identity $username

#Create home directory
$homefolder = $username

if($lineOfBusiness -eq 'Corporate' -or $lineOfBusiness -eq 'HCPL')
{
    $path = "\\corporate.local\proassurance\home\"
}
elseif($lineOfBusiness -eq 'Medmarc')
{
    $path = "\\corporate.local\medmarc\home\"
}
elseif($lineOfBusiness -eq 'PICA')
{
    $path = "\\onyx\users\"
}
Try
{
$newFolderFull = $path + $homefolder
New-Item $newFolderFull -ItemType Directory -ErrorAction stop
}
Catch
{
    write-host $_.exception.itemname -ForegroundColor Red
    Write-Host $_.exception.message -Foregroundcolor Yellow
    }



#Set home folder permissions
Try
{
$Acl = (Get-Item $newFolderFull).GetAccessControl('Access')
$AccessRule = New-Object System.Security.AccessControl.FileSystemAccessRule($Username, 'Modify','ContainerInherit,ObjectInherit', 'None', 'Allow')
$Acl.SetAccessRule($AccessRule)
Set-Acl -path $newFolderFull -AclObject $Acl -ErrorAction stop
}
Catch
{
    write-host $_.exception.itemname -ForegroundColor Red
    Write-Host $_.exception.message -Foregroundcolor Yellow
    }


Start-Sleep -s 60

###############################################
#Output Summary
###############################################

   

Write-Host ""
Write-Host -foregroundcolor Green "User Summary"

### Begin Testing
#Import-Module ActiveDirectory
#Add-PSSnapin *Exchange*
#$username = 'cssmith'
### End Testing

$usrobj = Get-ADUser -Identity $username -Properties *
$usrbox = Get-Mailbox -identity $username
$usrgrps = Get-ADPrincipalGroupMembership $username | select-object Name

#Write-Host "Password: " $password

Write-Host "Preferred Name: " $usrObj.givenName
Write-Host "Middle Name: " $usrObj.middleName
Write-Host "Last Name: " $usrObj.surName
Write-Host "Description: " $usrObj.description
Write-Host "Office: " $usrObj.office
Write-Host "Username: " $usrobj.samAccountName
Write-Host "Company: " $usrobj.company
Write-Host "Profile Login Script: " $usrobj.scriptPath
Write-Host "Display Name: " $usrobj.displayName
Write-Host "UPN: " $usrobj.userPrincipalName
Write-Host "ProxyAddresses: " $usrobj.proxyAddresses
Write-Host "msRTCSIP-PrimaryUserAddress: " $usrobj."msRTCSIP-PrimaryUserAddress"
Write-Host "extensionAttribute1: " $usrobj.extensionAttribute1
Write-Host "Title: " $usrobj.title
Write-Host "Department: " $usrobj.department
Write-Host "Canonical Name: " $usrobj.canonicalName
Write-Host "Street: " $usrobj.streetAddress
Write-Host "City: " $usrobj.city
Write-Host "State: " $usrobj.state
Write-Host "Postal Code: " $usrobj.postalCode
###hold for future Write-Host "Extension: " ###

if($usrbox.alias -eq $username) { Write-Host "Mailbox Created: Yes" } else { Write-Host "Mailbox Created: No" }
Write-Host "Mailbox Database: " $usrbox.database

Write-Host "Group Memberships: " $usrgrps | select-object Name | Format-List

Write-Host "Home Folder Creation:" $newFolderFull

Write-Host ""
Write-Host "Send email to new user group"
Write-Host "Send credentials to users supervisor.  "
write-host "Make sure company field is filled out correctly."
write-host "Make sure users SIP access is correctly configured.""  MSRTCSIP-PrimaryUserAddress"
Write-Host "Make sure Official Name on extensionAttribute1 is set correctly."
Write-Host "Make sure SIP address was added to Proxyaddresses."

##################################################################
#Send Summary to file
##################################################################
#Create the summary file for logging purposes.

$summaryfile = "\\corporate.local\appdata\onboarding\Output\" + $username + $(((get-date).ToLocalTime()).ToString("yyyyMMddThhmmss")) + "_Summary.txt"
$summaryreport | New-Item -ItemType file -path $summaryfile


"Preferred Name: " + $usrObj.givenName | out-file $summaryfile -Append
"Middle Name: " + $usrObj.middleName | out-file $summaryfile -Append
"Last Name: " + $usrObj.surName | out-file $summaryfile -Append
"Description: " + $usrObj.description | out-file $summaryfile -Append
"Office: " + $usrObj.office | out-file $summaryfile -Append
"Username: " + $usrobj.samAccountName | out-file $summaryfile -Append
"Company: " + $usrobj.company | out-file $summaryfile -Append
"Profile Login Script: " + $usrobj.scriptPath | out-file $summaryfile -Append
"Display Name: " + $usrobj.displayName | out-file $summaryfile -Append
"UPN: " + $usrobj.userPrincipalName | out-file $summaryfile -Append
"ProxyAddresses: " + $usrobj.proxyAddresses | out-file $summaryfile -Append
"msRTCSIP-PrimaryUserAddress: " + $usrobj."msRTCSIP-PrimaryUserAddress" | out-file $summaryfile -Append
"extensionAttribute1: " + $usrobj.extensionAttribute1 | out-file $summaryfile -Append
"Title: " + $usrobj.title | out-file $summaryfile -Append
"Department: " + $usrobj.department | out-file $summaryfile -Append
"Canonical Name: " + $usrobj.canonicalName | out-file $summaryfile -Append
"Street: " + $usrobj.streetAddress | out-file $summaryfile -Append
"City: " + $usrobj.city | out-file $summaryfile -Append
"State: " + $usrobj.state | out-file $summaryfile -Append
"Postal Code: " + $usrobj.postalCode | out-file $summaryfile -Append
###hold for future "Extension: " ###

if($usrbox.alias -eq $username) { "Mailbox Created: Yes" | out-file $summaryfile -Append } else { "Mailbox Created: No" | out-file $summaryfile -Append }
"Mailbox Database: " + $usrbox.database | out-file $summaryfile -Append

"Group Memberships: " + $usrgrps.Name | out-file $summaryfile -Append

"Home Folder Creation:" + $newFolderFull  | out-file $summaryfile -Append

 "Send email to new user group" | out-file $summaryfile -Append
 "Send credentials to users supervisor.  " | out-file $summaryfile -Append
 "Make sure company field is filled out correctly." | out-file $summaryfile -Append
 "Make sure users SIP access is correctly configured.""  MSRTCSIP-PrimaryUserAddress" | out-file $summaryfile -Append
 "Make sure Official Name on extensionAttribute1 is set correctly." | out-file $summaryfile -Append
 "Make sure SIP address was added to Proxyaddresses." | out-file $summaryfile -Append


#    }
remove-pssession $Session