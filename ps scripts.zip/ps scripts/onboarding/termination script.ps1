﻿#Import necessary modules
import-module activedirectory
asnp *exchange*
#Collect the username of the terminated employee by manual entry.
$username = read-host "username of terminated user account"
$manager = read-host "Username of email recipient if different from the manager"
if (-not ([string]::IsNullOrEmpty($manager))){
$manager=(get-aduser (get-aduser $username -Properties manager).manager).samaccountName
}
#Fetch the primary smtp address of the terminated user.
$primarymailbox=Get-ADUser -Identity $username -Properties ProxyAddresses | select -ExpandProperty ProxyAddresses | ? {$_ -clike "SMTP:*"}
#Delete the terminated users' mailbox.
#$usernameDN = get-aduser -identity strunec | ft distinguishedname
Get-ADUser -identity $username | Remove-ADObject -recursive
#Reassign email address for terminated user to the user that has rights to the archive in Exchange EAC.
set-aduser -Identity $manager -Add @{proxyAddresses = $primarymailbox.tolower()}